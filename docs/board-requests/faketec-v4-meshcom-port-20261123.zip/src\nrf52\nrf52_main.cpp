// (C) 2023 OE1KBC Kurt Baumann, OE1KFR Rainer 
//
// 20230326: Version 4.00: START

#include "configuration.h"
#include "uptime_min.h"   // wrap-safe 16-bit uptime minutes (NBR stamps)
#include "capture_functions.h"

#include <Arduino.h>
#include "instrument.h"
#include "track_warning.h" // TRK-01: Warnhinweis bei aktivem Track
#include <maxhop.h>         // CS-01: plausibility of the persisted text hop limit
#include <SPI.h>

#include <debugconf.h>
#include <time.h>
#include <nrf52_functions.h>
#include <nrf52_radio.h>
#include <settings_sanitize.h> // #1132: resolve_tx_power sentinel normalization
#include <extudp_functions.h>

#include <TinyGPSPlus.h>

// MeshCom nrf52 functions
#include <RAK13800_W5100S.h>
#include <WisBlock-API.h>

#include <nrf_eth.h>
#include <nrf_soc.h>   // ETH-04 F3: sd_rand_application_*
#include <nrf_sdm.h>   // sd_softdevice_is_enabled

#include "onebutton_functions.h"

#include <SX126x-RAK4630.h>


#if defined(HAS_TFT) || defined(HAS_TFT_114)
#include "tft_display_functions.h"
#endif

bool bDEEP_SLEEP = false;

#ifdef HAS_TFT_114
#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_ST7789.h> // Hardware-specific library for ST7789

/*
Wiring an ST7789 (SPI):
VCC: 3.3V
GND: Ground
SCL/SCK: SPI Clock Pin
SDA/MOSI: SPI MOSI Pin
RES/RST: Digital IO (Reset)
DC: Digital IO (Data/Command)
CS: Digital IO (Optional, if not present, the display is always active) 
*/

SPIClass SPI_TFT(NRF_SPIM3, PIN_SPI1_MISO, PIN_SPI1_SCK, PIN_SPI1_MOSI);
Adafruit_ST7789 tft1 = Adafruit_ST7789(&SPI_TFT, PIN_TFT_CS, PIN_TFT_DC, PIN_TFT_RST);


#endif

#include "Adafruit_LPS2X.h"
#include "Adafruit_SHTC3.h"

#if defined(ENABLE_GPS)
#include "gps_functions.h"
#endif

#include <OneButton.h>
#include <malloc.h>
OneButton btn;

// nRF52 heap monitoring using Adafruit framework APIs (debug.h)
// dbgHeapTotal() = __HeapLimit - __HeapBase (linker symbols)
// dbgHeapUsed()  = mallinfo().uordblks (allocated bytes)
extern int dbgHeapTotal(void);
extern int dbgHeapUsed(void);

// D1-10 loop scheduler: no longer `static` -- loop_actions_nrf52.cpp's
// loopAction_heapMon() (the old heapMonTimer body, moved verbatim) needs to
// reach these from another translation unit now. Internal-linkage-only
// helpers otherwise; this does not change what they compute.
uint32_t nrf52_getFreeHeap(void)
{
    return (uint32_t)(dbgHeapTotal() - dbgHeapUsed());
}

// Largest contiguous free block Ă˘â‚¬â€ť binary search probe (fragmentation indicator)
uint32_t nrf52_getMaxFreeBlock(void)
{
    uint32_t lo = 0, hi = nrf52_getFreeHeap();
    while (lo + 64 < hi) {
        uint32_t mid = (lo + hi) / 2;
        void *p = malloc(mid);
        if (p) { free(p); lo = mid; }
        else   { hi = mid; }
    }
    return lo;
}

// Min-free watermark since boot
uint32_t nrf52_heapMinFree = UINT32_MAX;
uint32_t nrf52_heapFree = UINT32_MAX;

// Ethernet Object
NrfETH neth;

// flag to indicate one second 
unsigned long retransmit_timer = 0;

// flag to update NTP Time
unsigned long updateTimeClient = 0;

// resend Ping Timer
unsigned long resendPing = 0;

// timers
uint32_t dhcp_timer = 0;         // dhcp refresh timer

// convBuffer moved to nrf52/udp_drain_nrf52.cpp with its only user (U2 carve)

// ETH Prototypes
void sendUDP();                                      // UDP tx routine
void sendHeartbeat();


// MeshCom Common (esp32/nrf52) functions
#include <lora_setchip.h>
#include <loop_functions.h>
#include <loop_functions_extern.h>
#include "loop_scheduler.h" // D1-10: shared loop scheduler (see there)
#if defined(ENABLE_MSGSTORE)
#include "msgstore_api.h"
#include "msgstore_settings.h"
#endif
#include <regex_functions.h>
#include "onrx_stats.h" // OR-STAT
#include "rx_silence.h" // RX-silence tracker
#include "setlog_lines.h"
#include "dedup_functions.h"
#include "nbr_matrix.h"    // --nbrdebug: nbrLogSnapshot()/nbrMatrix fuer den 15-Minuten-Takt
#include <command_functions.h>
#include <aprs_functions.h>
#include <batt_functions.h>
#include <lora_functions.h>
#include "rm_runtime.h" // RM-05 (#1189): rmInit(), rmDrain()
#include "blocked_calls.h" // BLK-01: blockListLoad()
#include "txring_functions.h" // BP-02: txRingDepth() declaration
#include <udp_functions.h>
#include <web_functions/web_functions.h>
#include <phone_commands.h>
#include <mh_phone.h>
#include <topo_ui.h>
#include <clock.h>

#include <bmx280.h>
#include "bmp390.h"
#include "aht20.h"
#include "bme680.h"
#include "mcu811.h"
#include "io_functions.h"
#include "ina226_functions.h"
#include "rtc_functions.h"
#include "rtc_offset.h"    // RTC-1..3: UTC<->Knotenzeit, Refresh-Gate (test_rtc_offset)
#include "softser_functions.h"
#include "telemetry_app.h"   // periodic T# source: own telemetry or soft-serial app

#include <onewire_functions.h>

#include "printfdeb_functions.h"

#include <SparkFun_u-blox_GNSS_Arduino_Library.h>
SFE_UBLOX_GNSS myGPS;

// UBLOX Modul auf Factory-Set zurÄ‚Ä˝ck setzen
// derzeit nur im esp32_gps realisiert
// nrf52 fehlt diese Funktion noch
// Diese Variablen werden durch das Command --gps reset gesetzt und solten im GPS Modul abgehandelt werden
int state = 0; // only for gps reset
bool bMitHardReset = false;  // only for gps reset

String strTime;
String strDate;

/*
    RAK4631 PIN DEFINITIONS

    static const uint8_t WB_IO1 = 17;	   // SLOT_A SLOT_B
    static const uint8_t WB_IO2 = 34;	   // SLOT_A SLOT_B
    static const uint8_t WB_IO3 = 21;	   // SLOT_C
    static const uint8_t WB_IO4 = 4;	   // SLOT_C
    static const uint8_t WB_IO5 = 9;	   // SLOT_D
    static const uint8_t WB_IO6 = 10;	   // SLOT_D
    static const uint8_t WB_SW1 = 33;	   // IO_SLOT
    static const uint8_t WB_A0 = 5;		   // IO_SLOT
    static const uint8_t WB_A1 = 31;	   // IO_SLOT
    static const uint8_t WB_I2C1_SDA = 13; // SENSOR_SLOT IO_SLOT
    static const uint8_t WB_I2C1_SCL = 14; // SENSOR_SLOT IO_SLOT
    static const uint8_t WB_I2C2_SDA = 24; // IO_SLOT
    static const uint8_t WB_I2C2_SCL = 25; // IO_SLOT
    static const uint8_t WB_SPI_CS = 26;   // IO_SLOT
    static const uint8_t WB_SPI_CLK = 3;   // IO_SLOT
    static const uint8_t WB_SPI_MISO = 29; // IO_SLOT
    static const uint8_t WB_SPI_MOSI = 30; // IO_SLOT

    SPI
    static const uint8_t SS = 26;
    static const uint8_t MOSI = PIN_SPI_MOSI;
    static const uint8_t MISO = PIN_SPI_MISO;
    static const uint8_t SCK = PIN_SPI_SCK;

    // QSPI Pins
    #define PIN_QSPI_SCK 3	// 19
    #define PIN_QSPI_CS 26	// 17
    #define PIN_QSPI_IO0 30 // 20
    #define PIN_QSPI_IO1 29 // 21
    #define PIN_QSPI_IO2 28 // 22
    #define PIN_QSPI_IO3 2	// 23

    @note RAK5005-O GPIO mapping to RAK4631 GPIO ports
   RAK5005-O <->  nRF52840
   IO1       <->  P0.17 (Arduino GPIO number 17)
   IO2       <->  P1.02 (Arduino GPIO number 34)
   IO3       <->  P0.21 (Arduino GPIO number 21)
   IO4       <->  P0.04 (Arduino GPIO number 4)
   IO5       <->  P0.09 (Arduino GPIO number 9)
   IO6       <->  P0.10 (Arduino GPIO number 10)
   SW1       <->  P0.01 (Arduino GPIO number 1)
   A0        <->  P0.04/AIN2 (Arduino Analog A2
   A1        <->  P0.31/AIN7 (Arduino Analog A7
   SPI_CS    <->  P0.26 (Arduino GPIO number 26)

    */

/*
Sync Word Setting in MeshCom
    MeshCom Syc Word is 0x2b

    Output of the LoRa Sync Word Register 0x0740 in MeshCom:

    Set radio: power level=22
    Sync Word 1st byte = 24
    Sync Word 2nd byte = b4

    In our Library it gets set at sx126x.h / radio.cpp
    Define: sx126x.h line 109:
    #define LORA_MAC_PUBLIC_SYNCWORD 0x242b

    Radio.SetCustomSyncWord(0x242b); needs to be called, so syncword gets new set in radio.cpp
    Method
*/

//NVIC_SystemReset(); resets the device

asm(".global _scanf_float");
asm(".global _printf_float");

// LoRa Events and Buffers
static RadioEvents_t RadioEvents;

// flag to indicate if we are after receiving
unsigned long iReceiveTimeOutTime = 0;

// RX-silence diagnostics. The radio callbacks run in the LORA / timer task and only publish
// a timestamp; the tracker itself, the chip reads and the prints stay in the loop task.
static RxSilenceTracker g_rxs;
static volatile uint32_t g_rxs_ev_ms = 0;      // time of the latest RX event (OnRxDone/OnRxError/header)
static volatile uint32_t g_rxs_ev_seq = 0;     // bumped per event
static volatile int16_t  g_rxs_ev_rssi = 0;    // of the latest OnRxDone
static volatile int8_t   g_rxs_ev_snr = 0;
static volatile bool     g_rxs_ev_has_q = false; // latest event was an OnRxDone (rssi/snr valid)
static uint32_t g_rxs_cad_busy = 0, g_rxs_cad_scans = 0, g_rxs_restarts = 0;

static void rxsNoteEvent(bool has_q, int16_t rssi, int8_t snr)
{
    g_rxs_ev_rssi = rssi;
    g_rxs_ev_snr = snr;
    g_rxs_ev_has_q = has_q;
    g_rxs_ev_ms = millis();
    g_rxs_ev_seq = g_rxs_ev_seq + 1;
}
static void rxsOnRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr)
{
    rxsNoteEvent(true, rssi, snr);
    OnRxDone(payload, size, rssi, snr);
}
static void rxsOnRxError(void)
{
    rxsNoteEvent(false, 0, 0);
    OnRxError();
}
static void rxsOnHeaderDetect(void)
{
    rxsNoteEvent(false, 0, 0);
    OnHeaderDetect();
}

// Boot counters for --info (read from command_functions.cpp, loop task): silences, longest s, total s.
void rxSilenceGetStats(uint32_t *silences, uint32_t *longest_s, uint32_t *total_s)
{
    uint32_t now = millis();
    *silences = g_rxs.silences;
    *longest_s = g_rxs.longestNow(now);
    *total_s = g_rxs.totalNow(now);
}

// CSMA/CA async CAD state
std::atomic<bool> cad_done_flag{false};
std::atomic<bool> cad_channel_busy{false};
std::atomic<bool> cad_in_progress{false};
std::atomic<bool> cad_double_check{false};
unsigned long cad_start_time = 0;

bool g_meshcom_initialized;
bool init_flash_done=false;

// FreeRTOS queue of raw BLE payloads, filled by bleuart_rx_callback() in
// nrf52_ble.cpp (BLE task context) and drained below in nrf52loop() so
// readPhoneCommand()/commandAction()/save_settings() run in the Main Loop
// task instead of inline in the BLE callback (CONC-14). Struct layout must
// stay in sync with the definition in nrf52_ble.cpp.
struct BleQueueItem {
    uint8_t data[MAX_MSG_LEN_PHONE];
    size_t length;
};
extern QueueHandle_t bleQueue;

bool bPosFirst = true;
bool bHeyFirst = true;
// DR-16: own first-flag for the telemetry gate below, scoped to that gate
// only. Previously shared bHeyFirst with the trickle-HEY gate a few lines
// above; the hey gate always runs first each pass and clears bHeyFirst, so
// by the time the telemetry gate below checked it, it was already false --
// the first telemetry frame missed its own "first pass" condition and had
// to wait out the full akt_timer instead (~15s at boot, since iNextTelemetry
// < 5 shortens akt_timer to 15s). ESP32 never had this bug: it already uses
// a separate bTeleFirst (esp32_main.cpp:236, 3500). bAllStarted and
// extra_hey_time are ESP32-only concepts (network-readiness state machine /
// softser grace) and are deliberately NOT ported here -- see docs/BACKLOG.md
// DR-16.
bool bTeleFirst = true;

// Queue for sending config jsons to phone
uint8_t iPhoneState = 0;
bool config_to_phone_prepare = false;
bool conffin_sent = false;
unsigned long config_to_phone_prepare_timer = 0;
unsigned long config_to_phone_datetime_timer = 0;
const uint8_t json_configs_cnt = 9;
const char config_cmds[json_configs_cnt][20] = {"--info", "--seset", "--wifiset", "--nodeset", "--wx", "--pos", "--aprsset", "--io", "--tel"};
uint8_t config_cmds_index = 0;

/**
 * BLE Spec
 * Messages to and from the phone need to have flag if it is a Text, Pos Msg or it is a configuration
 * Text/Pos flag: 0x40
 * Config Flag: 0x80
 * 
 * Config Message Parameters: Callsign, Lat, Lon, altitude
 * Text/Pos Msg Format:
 * LENGTH 2B - FLAG 1B - MSG xB
 * Config Format:
 * LENGTH 2B - FLAG 1B - LENCALL 1B - Callsign - LAT 4B(Float) - LON 4B(Float) - ALT 4B(INT)
 * 
 * Hello Message from Phone is: "XXaaYYzz"
 * Config of this device is sent to phone after hello msg from phone
*/

// Textmessage buffer from phone, hasMsgFromPhone flag indicates new message
extern char textbuff_phone [MAX_MSG_LEN_PHONE];
extern uint8_t txt_msg_len_phone;

extern bool ble_busy_flag;    // flag to signal bluetooth uart is active

//variables and helper functions
uint8_t err_cnt_udp_tx = 0;    // counter on errors sending message via UDP


// TinyGPS
TinyGPSPlus tinyGPSPlus;

int direction_S_N = 0;  //0--S, 1--N
int direction_E_W = 0;  //0--E, 1--W

#if defined(ENABLE_RAK_GPS)
unsigned int getGPS(void);
void SetupUBLOX();
#endif

// TEMP/HUM
Adafruit_SHTC3 shtc3 = Adafruit_SHTC3();

void getTEMP(void);

Adafruit_LPS22 g_lps22hb;

void getPRESSURE(void);

// BME680
#if defined(ENABLE_BMX680)
unsigned long bme680_timer = millis();
int delay_bme680 = 0;
#endif


#define POWER_ENABLE   WB_IO2

#define LEFT_BUTTON    WB_IO3
#define MIDDLE_BUTTON  WB_IO5
#define RIGHT_BUTTON   WB_IO6

uint8_t gKeyNum = 0; // which button is pressed
int iGPSCount=0;

// left button interrupt handle function
void interruptHandle1()
{
  if(gKeyNum == 0)
  {
    gKeyNum = 1;
  }
}

// middle button interrupt handle function
void interruptHandle2()
{
  if(gKeyNum == 0)
  {
    gKeyNum = 2;
  }
}

// right button interrupt handle function
void interruptHandle3()
{
  if(gKeyNum == 0)
  {
    gKeyNum = 3;
  }
}

#if not defined(BOARD_HELTEC_T114) and not defined(BOARD_T_ECHO)
#include <U8g2lib.h>

//extern U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2;
extern U8G2 *u8g2;
extern U8G2 u8g2_1;
extern U8G2 u8g2_2;
#endif

// Prototypes
void blinkLED();                                     // blink GREEN
void blinkLED2();                                    // blink BLUE
void blinkLED2();                                    // blink RED

// checkSerialCommand() now lives in its own TU (C3 carve-out)
#include "serial_command.h"
// gatewayService_*() likewise (C4 carve-out)
#include "gateway_service.h"
#include "gw_reg_runtime.h"


#if defined(ENABLE_RTC)
static uint32_t rtc_refresh_timer = 0;   // letzter RTC-Schreibzugriff (0 = nie), rtcRefreshDue()
#endif
unsigned long gps_refresh_timer = 0;
unsigned long mcp_refresh_timer = 0;
unsigned long softser_refresh_timer = 0;

// Client basic variables
uint8_t dmac[6];

/** Set the device name, max length is 10 characters */
    char g_ble_dev_name[10] = "MC";

void getMacAddr(uint8_t *dmac)
{
    const uint8_t *src = (const uint8_t *)NRF_FICR->DEVICEADDR;
    dmac[5] = src[0];
    dmac[4] = src[1];
    dmac[3] = src[2];
    dmac[2] = src[3];
    dmac[1] = src[4];
    dmac[0] = src[5]; // | 0xc0; // MSB high two bits get set elsewhere in the bluetooth stack
}

void OnCadDone(bool channelActivityDetected)
{
    // RACE-05 fix: atomic flag update under critical section
    taskENTER_CRITICAL();
    cad_channel_busy = channelActivityDetected;
    cad_done_flag.store(true, std::memory_order_release);
    taskEXIT_CRITICAL();
}

void RadioInit()
{
    Radio.Init(&RadioEvents);
}

// ETH-04 F3: Arduino random() is unseeded on nRF52, so the DHCP xid (and every
// other random() user) repeated after each reboot. Seed once from the hardware RNG:
// via the SoftDevice when it is enabled (NRF_RNG is owned by it then), else direct.
static void seedRandomFromHw()
{
    uint8_t buf[4] = {0, 0, 0, 0};
    const char *src = "fallback";
    bool ok = false;

    uint8_t sd_en = 0;
    sd_softdevice_is_enabled(&sd_en);
    if (sd_en)
    {
        for (int i = 0; i < 20 && !ok; i++)
        {
            uint8_t avail = 0;
            sd_rand_application_bytes_available_get(&avail);
            if (avail >= sizeof(buf) &&
                sd_rand_application_vector_get(buf, sizeof(buf)) == NRF_SUCCESS)
                ok = true;
            else
                delay(1);
        }
        if (ok)
            src = "sd";
    }
    else
    {
        NRF_RNG->EVENTS_VALRDY = 0;
        NRF_RNG->TASKS_START = 1;
        for (size_t i = 0; i < sizeof(buf); i++)
        {
            uint32_t t0 = millis();
            while (!NRF_RNG->EVENTS_VALRDY && (uint32_t)(millis() - t0) < 50)
                ;
            if (!NRF_RNG->EVENTS_VALRDY)
                break;
            buf[i] = (uint8_t)NRF_RNG->VALUE;
            NRF_RNG->EVENTS_VALRDY = 0;
            if (i == sizeof(buf) - 1)
                ok = true;
        }
        NRF_RNG->TASKS_STOP = 1;
        if (ok)
            src = "hw";
    }

    uint32_t seed;
    if (ok)
        memcpy(&seed, buf, sizeof(seed));
    else
        seed = millis() ^ (micros() << 7) ^ NRF_FICR->DEVICEADDR[0];   // last resort

    randomSeed(seed);
    Serial.printf("[ETH];event;rng_seed;src;%s\n", src);
}

///////////////////////////////////////////
void nrf52setup()
{
#if defined NRF52_SERIES || defined ESP32
	// Create the task event semaphore
	g_task_sem = xSemaphoreCreateBinary();
	// Initialize semaphore
	xSemaphoreGive(g_task_sem);
#endif

#if defined(HAS_TFT_114)
    pinMode(PIN_TFT_VDD_CTL, OUTPUT);
    pinMode(PIN_TFT_LEDA_CTL, OUTPUT);
    digitalWrite(PIN_TFT_VDD_CTL, TFT_LEDA_ENABLE);  // TFT VDD
    digitalWrite(PIN_TFT_LEDA_CTL, TFT_VDD_ENABLE); // TFT LEDA

    digitalWrite(LORA_NRSET, HIGH);   // LORA

    SPI_TFT.begin();

    tft1.init(TFT_WIDTH, TFT_HEIGHT);                  // ST7789 240x135
    tft1.setRotation(TFT_ROTATION);
    tft1.setSPISpeed(SPI_FREQUENCY);

    char cvers1[22];
    snprintf(cvers1, sizeof(cvers1), "  FW %s/%-1.1s <%s>", SOURCE_VERSION, SOURCE_VERSION_SUB, getCountry(meshcom_settings.node_country).c_str());
    String  version1 = cvers1;
    displayTFT(" MeshCom 4.0 ", version1, "@BY ICSSW.ORG", "  OE1KBC, OE1KFR",  "  ...starting now", 5000);

#endif

     // LEDs
    #if not defined(BOARD_HELTEC_T114)
        // LED-15: pinMode(OUTPUT) latches LOW, which lights an active-low LED: write the off level at once
        pinMode(LED_GREEN, OUTPUT);
        digitalWrite(LED_GREEN, !LED_STATE_ON);
        #ifndef BOARD_RAK4630
        pinMode(LED_RED, OUTPUT);
        digitalWrite(LED_RED, !LED_STATE_ON);
        #endif
        pinMode(LED_BLUE, OUTPUT);
        digitalWrite(LED_BLUE, !LED_STATE_ON);
    #endif
    #if defined(BOARD_LED) && defined(BOARD_HELTEC_T114)
        // T114 skips the block above; its BOARD_LED pad is set up here (LED-07/15)
        pinMode(BOARD_LED, OUTPUT);
        digitalWrite(BOARD_LED, boardLedLevel(false, BOARD_LED_ACTIVE_LOW));
    #endif

    //  Initialize the Serial Port for debug output
    time_t timeout = millis();
    Serial.begin(MONITOR_SPEED);
    while (!Serial)
    {
        if ((millis() - timeout) < 2000)
        {
            delay(100);
        }
        else
        {
            break;
        }
    }

    Serial.println("=====================================");
    Serial.println("[INIT] START CLIENT");
    nrf52_heapMinFree = nrf52_getFreeHeap();
    nrf52_heapFree = nrf52_heapMinFree;
    Serial.printf("%s;[HEAP];%lu;%lu;%lu;(init)\n", getTimeString().c_str(),
        (unsigned long)nrf52_getFreeHeap(),
        (unsigned long)nrf52_heapMinFree,
        (unsigned long)nrf52_getMaxFreeBlock());

    // init nach Reboot
    init_loop_function();

    // clear the buffers
    for (int i = 0; i < uint8_t(sizeof(RcvBuffer)); i++)
    {
        RcvBuffer[i] = 0x00;
    }

    for(int ib=0; ib<MAX_RING; ib++)
    {
        memset(own_msg_id[ib], 0x00, 5);
    }

    //clear ringbuffer
    for(int i=0; i<MAX_RING; i++)
    {
        memset(ringBufferLoraRX[i], 0, 4);
    }

    // MeshCom 5 (docs/meshcom5-campaign.md Welle 4): Topologie ersetzt die
    // alte MHeard-Init; topoUiBoot() ist ein No-Op ausser auf T-Deck/T-Deck
    // Pro (SD-Sicherung dort passt in tdeck_main.cpp).
    topoUiBoot();

	// Initialize battery reading
	init_batt();

	// Get LoRa parameter
	init_flash();

    bool bClear = false;
    if(meshcom_settings.node_cleanflash == 1)
        bClear = true;

    // Geloescht wird nur bei echter Layout-Aenderung, nicht bei jedem neuen
    // Build-Datum. Siehe configuration_global.h.
    if(!flashLayoutCompatible(meshcom_settings.node_fversion) || bClear)
    {
        Serial.printf("[INIT]...FLASH cleared, Settings-Layout %i -> %i\n",
                      meshcom_settings.node_fversion, FLASH_STRUCT_VERSION);

        flash_reset();
    }
    else
    {
        Serial.printf("[INIT]...FLASH layout %i ok, build %i\n",
                      meshcom_settings.node_fversion, FLASH_VERSION);
    }

    if(bClear)
        init_flash();

    meshcom_settings.node_fversion = FLASH_STRUCT_VERSION;
    meshcom_settings.node_mversion = MODUL_HARDWARE;
    meshcom_settings.node_cleanflash = 0;
    snprintf(meshcom_settings.node_fwversion, sizeof(meshcom_settings.node_fwversion), "%-4.4s%-1.1s", SOURCE_VERSION, SOURCE_VERSION_SUB);
    gwRegBoot();

#if defined(ENABLE_MSGSTORE)
    // S3: store node -- glue first (installs the MsgStoreEnv), then the persisted
    // --store/--storecall/--storetime/--storeslots/--storenotice settings.
    msgstoreGlueInit();
    msgstoreSettingsLoad();
#endif

    // BLK-01: call blocklist from flash/NVS (independent of ENABLE_MSGSTORE).
    blockListLoad();

    // RM-05 (#1189): remote-management state (high-water mark from its own flash file), after the
    // settings load so node_call/node_passwd are final.
    rmInit();

    // "-0" und "-01" sind nicht die kanonische Schreibweise der SSID. Was aus
    // dem Flash kommt, wird deshalb einmal beim Start geradegezogen -- das
    // save_settings() darunter schreibt es ohnehin. Ein Rufzeichen ohne SSID
    // bleibt, wie es ist. Die Werkseinstellung bleibt unberuehrt, sie soll weiter als
    // "noch nicht konfiguriert" erkennbar sein.
    if(!isNodeUnconfigured(meshcom_settings.node_call))
    {
        String sOwnCall = meshcom_settings.node_call;

        if(normalizeOwnCall(sOwnCall) && strcmp(sOwnCall.c_str(), meshcom_settings.node_call) != 0)
        {
            Serial.printf("[INIT]...Call <%s> -> <%s> (SSID kanonisch)\n", meshcom_settings.node_call, sOwnCall.c_str());

            snprintf(meshcom_settings.node_call, sizeof(meshcom_settings.node_call), "%s", sOwnCall.c_str());
            snprintf(meshcom_settings.node_short, sizeof(meshcom_settings.node_short), "%s", convertCallToShort(meshcom_settings.node_call).c_str());
        }
    }
    
    save_settings();

    meshcom_settings.node_date_hour = 0;
    meshcom_settings.node_date_minute = 0;
    meshcom_settings.node_date_second = 0;
    meshcom_settings.node_date_hundredths = 0;

    meshcom_settings.node_date_year = 0;
    meshcom_settings.node_date_month = 0;
    meshcom_settings.node_date_day = 0;

    bDisplayVolt = meshcom_settings.node_sset & 0x0001;
    bDisplayOff = meshcom_settings.node_sset & 0x0002;
    bPosDisplay = meshcom_settings.node_sset & 0x0004;
    bDEBUG = meshcom_settings.node_sset & 0x0008;
    bButtonCheck = meshcom_settings.node_sset & 0x0010;
    bDisplayTrack = meshcom_settings.node_sset & 0x0020;
    bGPSON =  meshcom_settings.node_sset & 0x0040;
    bBMPON =  meshcom_settings.node_sset & 0x0080;
    bBMEON =  meshcom_settings.node_sset & 0x0100;
    bLORADEBUG = meshcom_settings.node_sset & 0x0200;
    bSHORTPATH = meshcom_settings.node_sset & 0x0400;
    bGATEWAY =  meshcom_settings.node_sset & 0x1000;
    bEXTUDP =  meshcom_settings.node_sset & 0x2000;
    bDisplayCont =  meshcom_settings.node_sset & 0x4000;

    // TRK-01: Warnhinweis einmal beim Boot, wenn Track aus den Settings aktiv geladen wurde
    if(bDisplayTrack)
        Serial.printf("[INIT]..." TRACK_WARNING_SERIAL "\n");

    bONEWIRE =  meshcom_settings.node_sset2 & 0x0001;
    bLPS33 =  meshcom_settings.node_sset2 & 0x0002;
    bBME680ON = meshcom_settings.node_sset2 & 0x0004;
    bMCU811ON =  meshcom_settings.node_sset2 & 0x0008;
    //bGPSDEBUG = meshcom_settings.node_sset2 & 0x0010;
    iGPSDEBUG = meshcom_settings.node_gpsdebug;
    bMESH = !(meshcom_settings.node_sset2 & 0x0020);
    bWEBSERVER = meshcom_settings.node_sset2 & 0x0040;
    bWIFIAP = meshcom_settings.node_sset2 & 0x0080;
    bGATEWAY_NOPOS =  meshcom_settings.node_sset2 & 0x0100;
    bSMALLDISPLAY =  false;
    //free !! meshcom_settings.node_sset2 & 0x0200;
    bSOFTSERON =  meshcom_settings.node_sset2 & 0x0400;
    bBOOSTEDGAIN =  meshcom_settings.node_sset2 & 0x0800;
    //xxxxx = meshcom_settings.node_sset2 & 0x2000;
    bVIA = meshcom_settings.node_sset2 & 0x4000;

    // nicht mehr notwendig bMHONLY =  meshcom_settings.node_sset3 & 0x0001;
    bNoMSGtoALL =  meshcom_settings.node_sset3 & 0x0002;
    bBLEDEBUG = meshcom_settings.node_sset3 & 0x0004;
    bAnalogCheck = meshcom_settings.node_sset3 & 0x0008;
    bBMP3ON = meshcom_settings.node_sset3 & 0x0010;
    bAHT20ON = meshcom_settings.node_sset3 & 0x0020;
    bUSER_BOARD_LED = meshcom_settings.node_sset3 & 0x0080;   // LED-07: --board led

    bDEBUGCSV = meshcom_settings.node_sset4 & 0x0001;
    bDEBUGEN = meshcom_settings.node_sset4 & 0x0002;
    bDisplayLog = meshcom_settings.node_sset4 & 0x0004;
    bTXCAPTURE = meshcom_settings.node_sset4 & 0x0008;
    bNBRDEBUG = meshcom_settings.node_sset4 & 0x0400;
    nbrDebugApply();
    // --nbrrelay off|count|on (Stufe 2): 0x0800 rechnen/zaehlen, 0x1000 anwenden.
    bNBRRELAY  = (meshcom_settings.node_sset4 & 0x1800) != 0;
    bNBRCANCEL = (meshcom_settings.node_sset4 & 0x1000) != 0;
    // --nbrsym on|off (Stufe 2): 0x2000 invertiert gespeichert, siehe command_functions.cpp.
    bNBRSYM = (meshcom_settings.node_sset4 & 0x2000) == 0;
    // --nbrreport off|auto|on (Stufe 3, HN-Bericht): 0x0100 off, 0x0200 on, keines von beiden auto.
    bNBRRPTOFF = (meshcom_settings.node_sset4 & 0x0100) != 0;
    bNBRRPTON  = (meshcom_settings.node_sset4 & 0x0200) != 0;

    bDisplayInfo = bLORADEBUG;

    if(strlen(meshcom_settings.node_aprsmc) < 4)
    {
        strcpy(meshcom_settings.node_aprsmc, (char*)"APRSMC");  // default
    }

    // CS-01: max_hop_text is user-settable (--maxhop) and survives in the settings
    // file now; only a missing or out-of-range value falls back to the compile
    // default. max_hop_pos stays a compile-time constant (operator, 2026-08-30).
    meshcom_settings.max_hop_text = maxHopTextSanitize(meshcom_settings.max_hop_text);
    meshcom_settings.max_hop_pos = MAX_HOP_POS_DEFAULT;

    iButtonPin = BUTTON_PIN;
    if(meshcom_settings.node_button_pin > 0)
        iButtonPin = meshcom_settings.node_button_pin;

    // user button init
    init_onebutton();

    // if Node not set --> WifiAP Mode on
    /* NRF52 no WiFi
    if(isNodeUnconfigured(meshcom_settings.node_call))
    {
        bWIFIAP = true;
        bWEBSERVER = true;

        Serial.println("WIFIAP starting...");
    }
    */

    if(meshcom_settings.node_gwsrv[0] == 0x00)
        snprintf(meshcom_settings.node_gwsrv, sizeof(meshcom_settings.node_gwsrv), "%s", "OE");

    // if Node is in WifiAP Mode -> no Gateway posible
    if(bWIFIAP && bGATEWAY)
    {
        bGATEWAY=false;
        bEXTUDP=false;
    }

    if(bBMPON)
    {
        bBMEON=false;
        bBME680ON=false;
        bmx_found=false;
    }
    else
    if(bBMEON)
    {
        bBMPON=false;
        bBME680ON=false;
        bmx_found=false;
    }

    bme680_found=false;

    memset(meshcom_settings.node_update, 0x00, sizeof(meshcom_settings.node_update));
    
    #ifndef ENABLE_SOFTSER
        bSOFTSERON=false;
    #endif

    // Umstekllung auf langes WIFI Passwort
    if(strlen(meshcom_settings.node_ossid) > 4 && strlen(meshcom_settings.node_ssid) < 5)
    {
        strncpy(meshcom_settings.node_ssid, meshcom_settings.node_ossid, sizeof(meshcom_settings.node_ssid) - 1);
        meshcom_settings.node_ssid[sizeof(meshcom_settings.node_ssid) - 1] = '\0';
        strncpy(meshcom_settings.node_pwd, meshcom_settings.node_opwd, sizeof(meshcom_settings.node_pwd) - 1);
        meshcom_settings.node_pwd[sizeof(meshcom_settings.node_pwd) - 1] = '\0';

        memset(meshcom_settings.node_ossid, 0x00, sizeof(meshcom_settings.node_ossid));
        memset(meshcom_settings.node_opwd, 0x00, sizeof(meshcom_settings.node_opwd));

        save_settings();
    }

    meshcom_settings.node_press = 0.0;
    meshcom_settings.node_hum = 0.0;
    meshcom_settings.node_temp = 0.0;
    meshcom_settings.node_temp2 = 0.0;
    meshcom_settings.node_press_alt = 0;
    meshcom_settings.node_press_asl = 0.0;

    global_batt = 4125.0;

    posinfo_interval = POSINFO_INTERVAL;

    if(meshcom_settings.node_postime > 0)
        posinfo_interval = meshcom_settings.node_postime;

    if(meshcom_settings.node_maxv > 0)
    {
        setMaxBatt(meshcom_settings.node_maxv * 1000.0F);
    
        global_batt = meshcom_settings.node_maxv * 1000.0F;
    }

	// Initialize onewire sensor
    // check pin number in flash
    if(meshcom_settings.node_owgpio > 7 || meshcom_settings.node_owgpio < 0){
        meshcom_settings.node_owgpio = 0;
        save_settings();
    }

#ifdef OneWire_GPIO
    if(bONEWIRE)
    {
        init_onewire_ds18();
        init_onewire_dht();
    }
#endif

//  Initialize the LoRa Module
    api_init_lora();

    getMacAddr(dmac);

    _GW_ID = dmac[0] | (dmac[1] << 8) | (dmac[2] << 16) | (dmac[3] << 24);

    // BLE ID
    meshcom_settings.node_device_eui[0]=0x4D;   // M
    meshcom_settings.node_device_eui[1]=0x43;   // C
    for(int ieui=0; ieui<6; ieui++)
    {
        meshcom_settings.node_device_eui[ieui+2] = dmac[ieui];
    }


    ////////////////////////////////////////////////////////////////////
    // Initialize time
	bool boResult;
	
	// initialize clock
	boResult = MyClock.Init();
	Serial.printf("[INIT]...Initialize clock: %s\n", (boResult) ? "ok" : "FAILED");
    snprintf(cTimeSource, sizeof(cTimeSource), (char*)"INIT");

    DisplayTimeWait=0;
    //
    ////////////////////////////////////////////////////////////////////

    // Hardware immer aktivieren
    //if(bGPSON)
    {
        //gps init
        #if defined(ENABLE_RAK_GPS)
        pinMode(WB_IO2, OUTPUT);
        digitalWrite(WB_IO2, 0);
        delay(1000);
        digitalWrite(WB_IO2, 1);
        delay(1000);
        
        Serial.println("=====================================");

        Serial.println("GPS: trying 9600 baud");
        
        Serial1.begin(9600);
        Serial1.setTimeout(500);
        while (!Serial1);

        if(Serial1)
        {
            if (myGPS.begin(Serial1))
            {
                Serial.println("GPS: connected at 9600 baud");
            }
            else
            {
                Serial1.end();

                delay(100);
                Serial.println("GPS: trying 38400 baud");

                Serial1.begin(38400);
                Serial1.setTimeout(500);
                while (!Serial1);

                if(Serial1)
                {
                    if (myGPS.begin(Serial1))
                    {
                        Serial.println("GPS: connected at 38400 baud");
                    }
                    else
                    {
                        Serial.println("GPS: speed not found");
                    }
                }
                else
                    Serial.println("GPS: not connected");
            }
        }
        else
            Serial.println("GPS: not connected");

        delay(100);

        SetupUBLOX();

        #endif
    }

    posinfo_fix = false;
    posinfo_satcount = 0;
    fposinfo_hdop = 0.0;

    // Try to initialize!
    #if defined(LPS33)

    if(bLPS33)
    {
        Serial.println("Adafruit LPS33 check");

        if (!g_lps22hb.begin_I2C(0x5d)) 
        {
            Serial.println("Failed to find LPS33 chip");
            //while (1) 
            { 
            //  delay(10); 
            }
        }
        else
        {
            Serial.println("LPS33 sensor found");

            g_lps22hb.setDataRate(LPS22_RATE_10_HZ);

            /*
            Serial.print("Data rate set to: ");

            switch (g_lps22hb.getDataRate()) 
            {
                case LPS22_RATE_ONE_SHOT: Serial.println("One Shot / Power Down"); 
                    break;
                case LPS22_RATE_1_HZ: Serial.println("1 Hz"); 
                    break;
                case LPS22_RATE_10_HZ: Serial.println("10 Hz"); 
                    break;
                case LPS22_RATE_25_HZ: Serial.println("25 Hz"); 
                    break;
                case LPS22_RATE_50_HZ: Serial.println("50 Hz"); 
                    break;
            }
            */
        }
    }
    #endif // LPS33

    shtc3_found = false;

    #if defined(SHTC3)

    Serial.println("[INIT]...Adafruit SHTC3 check");
    if (!shtc3.begin())
    {
        Serial.println("[INIT]...Couldn't find SHTC3");
    }
    else
    {
        Serial.println("[INIT]...SHTC3 sensor found");
        shtc3_found = true;
    }

    #endif // SHTC3

    //////////////////////////////////////////////////////
    // BLE INIT

    g_enable_ble=true;

#if defined NRF52_SERIES || defined ESP32
	if (g_enable_ble)
	{
		// Init BLE
		init_ble();

        Serial.println("[INIT]...BLE init");
	}
	else
	{
		// BLE is not activated, switch off blue LED
        #if not defined(BOARD_HELTEC_T114)
		digitalWrite(LED_BLUE, !LED_STATE_ON);   // LED-15: off level, not LOW
        #endif
	}

	// Take the semaphore so the loop will go to sleep until an event happens
	xSemaphoreTake(g_task_sem, 10);
#endif

#ifdef ARDUINO_ARCH_RP2040
	// RAK11310 does not have BLE, switch off blue LED
	digitalWrite(LED_BLUE, !LED_STATE_ON);
#endif

    // I2C init
    #if not defined(USE_HELTEC_T114)
        Wire.setPins(PIN_WIRE_SDA, PIN_WIRE_SCL);
        Wire.begin();
    #endif

    #if defined(ENABLE_BMX280)
        setupBMX280(true);
    #endif

    #if defined(ENABLE_AHT20)
        setupAHT20(true);
    #endif

    #if defined(ENABLE_MC811)
        setupMCU811();
    #endif

    // BME680
    #if defined(ENABLE_BMX680)
        setupBME680();
    #endif

    // MCP23017
    #if defined(ENABLE_MCP23017)
        setupMCP23017();
    #endif

    // INA226
    #if defined(ENABLE_INA226)
        setupINA226();
    #endif

    // RTC
    #if defined(ENABLE_RTC)
        setupRTC();
    #endif

    // SOFTSER
    #if defined(ENABLE_SOFTSER)
        setupSOFTSER();
    #endif

    #if defined(BOARD_T_ECHO)
        initDisplay();
        startDisplay((char*)"..starting now..", (char*)"@by icssw.org", (char*)"OE1KBC, OE1KFR");
    
    #elif defined(HAS_EPAPER)

    #elif defined(HAS_TFT_114)
        char cvers[22];
        snprintf(cvers, sizeof(cvers), "  FW %s/%-1.1s <%s>", SOURCE_VERSION, SOURCE_VERSION_SUB, getCountry(meshcom_settings.node_country).c_str());
        String  version = cvers;
        displayTFT(" MeshCom 4.0", version, "@BY ICSSW.ORG", "   OE1KBC, OE1KFR",  "   ...starting now", 5000);
    #elif defined(HAS_TFT)
        initTFT();
        char cvers[22];
        snprintf(cvers, sizeof(cvers), "  FW %s/%-1.1s <%s>", SOURCE_VERSION, SOURCE_VERSION_SUB, getCountry(meshcom_settings.node_country).c_str());
        String  version = cvers;
        displayTFT(" MeshCom 4.0 ", version, "  @BY ICSSW.ORG", "  OE1KBC, OE1KFR",  "  ...starting now", 5000);
    #else
        initDisplay();
        startDisplay((char*)"..starting now..", (char*)"@by icssw.org", (char*)"OE1KBC, OE1KFR");
    #endif

    // reset GPS-Time parameter
    meshcom_settings.node_date_hour = 0;
    meshcom_settings.node_date_minute = 0;
    meshcom_settings.node_date_second = 0;
    meshcom_settings.node_date_hundredths = 0;

    Serial.println("[INIT]...CLIENT STARTED");

    // Reset-Ursache loggen (POWER->RESETREAS, vom Core beim Start gesichert):
    // 0x1 Reset-Pin, 0x2 Watchdog, 0x4 Soft-Reset (SREQ Ă˘â‚¬â€ť auch der Weg, den
    // der SoftDevice-Fault-Handler nach einem App-Absturz nimmt), 0x8 Lockup.
    // Unterscheidet nach einem unerwarteten Reboot sofort Absturz von
    // Spannungsproblem Ă˘â‚¬â€ť haette die N-22-Diagnose erheblich verkuerzt.
    {
        extern uint32_t readResetReason(void);
        Serial.printf("[BOOT] RESETREAS=0x%08lX\n", (unsigned long)readResetReason());
    }


    Radio.SetModem(MODEM_LORA);

    Serial.printf("[INIT]...Radio-Sync: %04X\n", Radio.GetSyncWord());

    //  Set the LoRa Callback Functions
    RadioEvents.TxDone = OnTxDone;
    g_rxs.init(millis());
    RadioEvents.RxDone = rxsOnRxDone;
    RadioEvents.TxTimeout = OnTxTimeout;
    RadioEvents.RxTimeout = OnRxTimeout;
    RadioEvents.RxError = rxsOnRxError;
    RadioEvents.CadDone = OnCadDone;
    //RadioEvents.PreAmpDetect = OnPreambleDetect;
    RadioEvents.PreAmpDetect = rxsOnHeaderDetect;

    // 4.34w we use EU8 instead of EU
    if(meshcom_settings.node_country == 0)
        meshcom_settings.node_country = 8;

    lora_setcountry(meshcom_settings.node_country);

    //  Initialize the LoRa Transceiver
    RadioInit();

    // Sets the Syncword new that we can set the MESHCOM SWORD
    DEBUG_MSG("RADIO", "Setting new LoRa Sync Word");
    Radio.SetCustomSyncWord(0x242b);

    // set bandwidth 
    Serial.printf("[LoRa]...RF_BANDWIDTH: %.0f kHz\n", getBW());

    // set spreading factor 
    Serial.printf("[LoRa]...RF_SF: %i\n",  getSF());

    // coding rate
    Serial.printf("[LoRa]...RF_CR: 4/%i\n", getCR());

    // set carrier frequency
    uint32_t ifreq=(getFreq()*1000.)+0.5;
    ifreq = ifreq * 1000;

    Serial.printf("[LoRa]...RF_FREQUENCY: %.4f %ld MHz\n", getFreq(), ifreq);

    //  Set the LoRa Frequency
    Radio.SetChannel(ifreq);

    Serial.printf("[LoRa]...PREAMBLE: %i symbols\n", meshcom_settings.node_preamplebits);

    uint16_t preamble_length = meshcom_settings.node_preamplebits;

    //  Configure the LoRa Transceiver for receiving messages
    Radio.SetRxConfig(
        MODEM_LORA,
        (uint32_t)meshcom_settings.node_bw,
        (uint32_t)meshcom_settings.node_sf,
        (uint8_t)meshcom_settings.node_cr,
        0, //  AFC bandwidth: Unused with LoRa
        preamble_length,
        LORA_SYMBOL_TIMEOUT,
        LORA_FIX_LENGTH_PAYLOAD_ON,
        0,    //  Fixed payload length: N/A
        true, //  CRC enabled
        0,    //  Frequency hopping disabled
        0,    //  Hop period: N/A
        LORA_IQ_INVERSION_ON,
        true //  Continuous receive mode
    );

    // Set Radio TX configuration
    meshcom_settings.node_power = resolve_tx_power(meshcom_settings.node_power, TX_OUTPUT_POWER); // #1132: normalize -20/0 sentinel like ESP32 does
    Serial.printf("[LoRa]...RF_POWER: %i dBm\n", getPower());

    Radio.SetTxConfig(
        MODEM_LORA,
        getPower(),
        0, // fsk only
        (uint32_t)meshcom_settings.node_bw,
        (uint32_t)meshcom_settings.node_sf,
        (uint8_t)meshcom_settings.node_cr,
        preamble_length,
        LORA_FIX_LENGTH_PAYLOAD_ON,
        true, // CRC ON
        0,    // fsk only frequ hop
        0,    // fsk only frequ hop period
        LORA_IQ_INVERSION_ON,
        TX_TIMEOUT_VALUE);

    Serial.printf("[INIT]...Radio-Sync: %04X\n", Radio.GetSyncWord());

    //  Start receiving LoRa packets
    startRadioReceive();

    // Configure CAD parameters: 4 symbols, DETPEAK/DETMIN from config, CAD_ONLY mode
    Radio.SetCadParams(LORA_CAD_04_SYMBOL, RADIOLIB_SX126X_DETPEAK, RADIOLIB_SX126X_DETMIN, LORA_CAD_ONLY, 0);

    // set left button interrupt
    //pinMode(LEFT_BUTTON, INPUT);
    //attachInterrupt(LEFT_BUTTON, interruptHandle1, FALLING);

    // set middle button interrupt
    pinMode(MIDDLE_BUTTON, INPUT);
    attachInterrupt(MIDDLE_BUTTON, interruptHandle2, FALLING);

    // set right button interrupt
    //pinMode(RIGHT_BUTTON, INPUT);
    //attachInterrupt(RIGHT_BUTTON, interruptHandle3, FALLING);

    sd_power_mode_set(NRF_POWER_MODE_CONSTLAT);

    Serial.println("=====================================");

    delay(100);

    seedRandomFromHw();   // ETH-04 F3: after init_ble() (SoftDevice up), before the DHCP xid

    if (bGATEWAY || bWEBSERVER)
    {
        //////////////////////////////////////////////////////
        // ETHERNET INIT
   
        if(ethIsStaticConfigured())
        {
            if(bDEBUG)
                Serial.println("[init] ETH FIX-IP init");

            neth.initethfixIP();
        }
        else
        {
            if(bDEBUG)
                Serial.println("[init] ETH DHCP init");

            neth.initethDHCP();
        }

        if(neth.hasETHHardware)
        {
            if(bGATEWAY)
            {
                sendHeartbeat();

                Serial.println("=====================================");
                Serial.printf("GATEWAY 4.0 RUNNING %s\n", neth.hasIPaddress?"ETH connect":"ETH no connect");
                Serial.println("=====================================");
            }

            if(bWEBSERVER)
            {
                startWebserver();
            }

            if(bEXTUDP)
            {
                startExternUDP();
            }
        }
        else
        {
            meshcom_settings.node_hasIPaddress = false;

            Serial.println("==================================");
            Serial.println("CLIENT 4.0 RUNNING no ETH-Hardware");
            Serial.println("==================================");
        }
    }
    else
    {
        meshcom_settings.node_hasIPaddress = false;
        neth.hasETHHardware = false;
    }
}   

void nrf52loop()
{
    INSTR_LOOPTICK();

    gwRegTick();

    #if defined(REMOTE_LED_PIN)
    remoteLedTick();   // RM "led flash" pattern (LED-07)
    #endif
    boardLedTick();    // --board led heartbeat; no-op without BOARD_LED

    // BP-01/BP-04: close a back-pressure episode with QRV once the TX ring
    // has drained, even when no further user message arrives to observe it.
    // Since BP-02 an occupied-slot scan (O(MAX_RING)), since BP-04 with the
    // water-band hold; it emits at most once per episode.
    bpPollDrain();

    // TM-25: Boot-Marke fuer den Bench-Harness, wie [BOOT];ready auf dem ESP32.
    // Auf dem nRF52 ist die Netzwerkphase (W5100S/DHCP) am Ende von setup()
    // bereits synchron abgeschlossen -- die Marke faellt beim ersten Loop-Durchlauf.
    static bool s_bootReadyLogged = false;
    if (!s_bootReadyLogged)
    {
        s_bootReadyLogged = true;
        Serial.printf("[BOOT];ready;ms;%lu;ip;%d;eth;%d\n", (unsigned long)millis(),
                      neth.hasIPaddress ? 1 : 0, neth.hasETHHardware ? 1 : 0);
    }
    #if defined(HAS_TFT_114) or defined(BOARD_T_ECHO)
    if(bDEEP_SLEEP)
    {
        delay(60000);
        // only loop
    }
    else
    {
    #endif

    // get RTC Now
    // RTC hat Vorrang zu Zeit via MeshCom-Server
    bool bMyClock = true;

    #if defined(ENABLE_RTC)
    if(bRTCON)
    {
        bMyClock = false;

        { INSTR_SECTION("rtc"); loopRTC(); }

        if(posinfo_fix) // GPS hat Vorang zur RTC und setzt RTC
        {
            if(MyClock.Year() > 2023 && rtcRefreshDue(millis(), rtc_refresh_timer))
            {
                //only every minute
                // RTC haelt UTC, MyClock haelt Knotenzeit (RTC-1). Nicht node_date_*:
                // mit RTC und GPS-Fix bleibt bMyClock hier false, die Felder werden
                // dann nicht nachgezogen. getGPS() setzt MyClock alle ~3 s neu,
                // ohne isValid()-Pruefung -- daher die Jahres-Schranke.
                DateTime wutc((uint32_t)rtcUtcFromLocalFields(MyClock.Year(), MyClock.Month(), MyClock.Day(), MyClock.Hour(), MyClock.Minute(), MyClock.Second(), meshcom_settings.node_utcoff));
                setRTCNow(wutc.year(), wutc.month(), wutc.day(), wutc.hour(), wutc.minute(), wutc.second());
                rtc_refresh_timer = millis() | 1;   // 0 = noch nie geschrieben
            }
        }
        else
        {
            DateTime utc = getRTCNow();

            // RTC-UTC + Offset genau einmal (RTC-2), setCurrentTime() mit fUTC = 0
            DateTime now ((uint32_t)rtcNodeEpochFromUtc(utc.unixtime(), meshcom_settings.node_utcoff));

            uint16_t Year = now.year();
            uint16_t Month = now.month();
            uint16_t Day = now.day();

            uint16_t Hour = now.hour();
            uint16_t Minute = now.minute();
            uint16_t Second = now.second();


            // check valid Date & Time
            if(Year > 2023)
            {
                MyClock.setCurrentTime(0.0, Year, Month, Day, Hour, Minute, Second);
                snprintf(cTimeSource, sizeof(cTimeSource), (char*)"RTC");
                bMyClock = true;
            }
        }
    }
    #endif

    if(meshcom_settings.node_hasIPaddress)
    {
        INSTR_SECTION("eth_state");
        strTime = "none";

        extern bool btimeClient;

        // every 15 minutes
        if(btimeClient)
        {
            if((uint32_t)(millis() - updateTimeClient) >= (uint32_t)(1000 * 60 * 15) || updateTimeClient == 0)
            {
                strTime = neth.udpUpdateTimeClient();

                updateTimeClient = millis();
            }
            else
                strTime = neth.udpGetTimeClient();

            strDate = neth.udpGetDateClient();

            uint16_t Year = (uint16_t)strDate.substring(0, 4).toInt();
            uint16_t Month = (uint16_t)strDate.substring(5, 7).toInt();
            uint16_t Day = (uint16_t)strDate.substring(8, 10).toInt();

            uint16_t Hour = (uint16_t)strTime.substring(0, 2).toInt();
            uint16_t Minute = (uint16_t)strTime.substring(3, 5).toInt();
            uint16_t Second = (uint16_t)strTime.substring(6, 8).toInt();
        
            // check valid Date & Time
            if(Year > 2023 && strTime.compareTo("none") != 0)
            {
                MyClock.setCurrentTime(meshcom_settings.node_utcoff, Year, Month, Day, Hour, Minute, Second);
                bNTPDateTimeValid = true;

                snprintf(cTimeSource, sizeof(cTimeSource), (char*)"NTP");

                #if defined(ENABLE_RTC)
                // gueltige NTP-Zeit frischt den RTC einmal pro Minute auf, in UTC.
                // Direkt aus MyClock (Knotenzeit), node_date_* wird erst weiter
                // unten nachgezogen.
                if(bRTCON && rtcRefreshDue(millis(), rtc_refresh_timer))
                {
                    DateTime wutc((uint32_t)rtcUtcFromLocalFields(MyClock.Year(), MyClock.Month(), MyClock.Day(), MyClock.Hour(), MyClock.Minute(), MyClock.Second(), meshcom_settings.node_utcoff));
                    setRTCNow(wutc.year(), wutc.month(), wutc.day(), wutc.hour(), wutc.minute(), wutc.second());
                    rtc_refresh_timer = millis() | 1;   // 0 = noch nie geschrieben
                }
                #endif
            }
            else
                bNTPDateTimeValid = false;
        }
    }
    else
    {
        bNTPDateTimeValid = false;
    }


    if(bMyClock)
    {
        INSTR_SECTION("clock");
        MyClock.CheckEvent();
        
        if(MyClock.Year() > 2023)
            meshcom_settings.node_date_year = MyClock.Year();
        else
            meshcom_settings.node_date_year = 0;

        meshcom_settings.node_date_month = MyClock.Month();
        meshcom_settings.node_date_day = MyClock.Day();

        meshcom_settings.node_date_hour = MyClock.Hour();
        meshcom_settings.node_date_minute = MyClock.Minute();
        meshcom_settings.node_date_second = MyClock.Second();

        // Starttime setzen
        if(meshcom_settings.node_date_year > 2023 && meshcom_settings.node_update[0] == 0x00)
        {
            snprintf(meshcom_settings.node_update, sizeof(meshcom_settings.node_update), "%04i-%02i-%02i %02i:%02i:%02i",
             meshcom_settings.node_date_year, meshcom_settings.node_date_month, meshcom_settings.node_date_day, meshcom_settings.node_date_hour, meshcom_settings.node_date_minute, meshcom_settings.node_date_second);
        }
    }

    // D1-10 loop scheduler: retransmit_timer, mcp_refresh_timer,
    // BattTimeWait, heapMonTimer, BMP3TimeWait, MCU811TimeWait and
    // INA226TimeWait now fire from here (table in loop_scheduler.cpp,
    // bodies in loop_actions_nrf52.cpp) instead of their old, much later
    // positions further down nrf52loop() -- see src/loop_scheduler.h for
    // the full audit trail of what moved and the in-pass reordering check.
    // BattTimeWait's zero-init is unconditional in the original (unlike
    // heapMonTimer's/MCU811TimeWait's/INA226TimeWait's, which are nested
    // inside their own runtime guard and so live inside
    // loopEnabled_heapMon()/loopEnabled_mcu811()/loopEnabled_ina226()
    // instead -- see loop_actions_nrf52.cpp), so it stays a top-level
    // statement here, right before the scheduler call.
    if (BattTimeWait == 0)
        BattTimeWait = millis() - 31000;

    loopSchedulerRun(millis());

    // Periodischer Ringpuffer-Auslastungsbericht (alle 30s)
    {
        static unsigned long ring_status_timer = 0;
        if(bLORADEBUG && (millis() - ring_status_timer) > 30000)
        {
            ring_status_timer = millis();
            int pending = 0, retrying = 0, done = 0;
            for(int i = 0; i < MAX_RING; i++)
            {
                if(ringBuffer[i][0] == 0) continue;
                if(ringBuffer[i][1] == 0xFF) done++;
                else if(ringBuffer[i][1] == 0x00) pending++;
                else retrying++;
            }
            // BP-02: queued is the honest occupied-slot count (the
            // pending/retrying/done buckets above already scan every slot
            // and partition it exactly). TXP W1b (slot pool): the iW=/iR=/
            // dist= fields are gone with the indices; retrying includes
            // INFLIGHT and parked SENT slots.
            int queued = pending + retrying + done;
            Serial.printf("[MC-DBG] RING_STATUS queued=%d pending=%d retrying=%d done=%d\n",
                queued, pending, retrying, done);
        }
    }

    // Deferred display update from OnRxDone (avoid I2C inside radio callback)
    // RACE-01 fix: snapshot under critical section, display call outside
    {
        taskENTER_CRITICAL();
        bool _pendText = bPendingDisplayText;
        bool _pendPos = bPendingDisplayPos;
        struct aprsMessage _msg;
        int16_t _rssi = 0;
        int8_t _snr = 0;
        if(_pendText || _pendPos) {
            _msg = pendingDisplayMsg;
            _rssi = pendingDisplayRssi;
            _snr = pendingDisplaySnr;
            bPendingDisplayText = false;
            bPendingDisplayPos = false;
        }
        taskEXIT_CRITICAL();
        INSTR_SECTION("display_rx");
        if(_pendText) sendDisplayText(_msg, _rssi, _snr);
        if(_pendPos)  sendDisplayPosition(_msg, _rssi, _snr);
    }

    // RM-05 (#1189): authenticated remote-management DMs queued by OnRxDone (LORA task); crypto,
    // execution, flash write and the reply all run here, in the loop task.
    rmDrain();

    // Channel utilization report (every 10s). SL-05: the drain of the
    // ch_util accumulators feeds stat_util_rx_5m/tx_5m for the STAT line
    // (--setlog on), so the 10-s tick runs independent of bLORADEBUG; only
    // the diagnostic prints stay behind the flag, unchanged.
    {
        static unsigned long ch_util_timer = 0;
        if((millis() - ch_util_timer) > 10000)
        {
            unsigned long window = millis() - ch_util_timer;
            ch_util_timer = millis();
            unsigned long rx_ms = ch_util_rx_accum.exchange(0);
            unsigned long tx_ms = ch_util_tx_accum.exchange(0);
            stat_util_rx_5m += (uint32_t)rx_ms;
            stat_util_tx_5m += (uint32_t)tx_ms;
            unsigned int util = (unsigned int)((rx_ms + tx_ms) * 100 / window);
            if(util > 100) util = 100;
            if(bLORADEBUG)
            {
                Serial.printf("[MC-DBG] CHANNEL_UTIL rx=%lums tx=%lums util=%u%%\n",
                    rx_ms, tx_ms, util);
                // ONRXDONE stats: report max and warn count, then reset
                Serial.printf("[MC-DBG] ONRXDONE_STATS max=%lums warn=%u (>%dms)\n",
                    onrxdone_max_ms, onrxdone_warn_count, ONRXDONE_WARN_MS);
                onrxdone_max_ms = 0;
                onrxdone_warn_count = 0;
            }
        }
    }

    // SL-05 STAT tick (--setlog on / bDisplayLog): runs independent of
    // bLORADEBUG so the interval counters never grow unbounded even when the
    // block above never fires. Reset always, print only when enabled.
    {
        static uint32_t setlog_stat_timer = 0;
        if((uint32_t)(millis() - setlog_stat_timer) >= PRIO_STAT_INTERVAL_S * 1000UL)
        {
            setlog_stat_timer = millis();

            struct setlogStatFields f;
            setlogFillStat(&f, nrf52_getFreeHeap());

            // OR-STAT: OnRxDone time distribution (drains the window)
            {
                struct onrxStatsOut o;
                onrxStatsSnapshotReset(&o, ONRXDONE_WARN_MS);
                f.onrx_n = o.n; f.onrx_avg_ms = o.avg_ms; f.onrx_p95_ms = o.p95_ms;
                f.onrx_p99_ms = o.p99_ms; f.onrx_max_ms = o.max_ms; f.onrx_warn = o.warn;
            }

            // stat_drop_count[] increments happen under this same lock in
            // txring_functions.cpp -- clear under it too, right after the
            // (uncleared) read inside setlogFillStat().
            taskENTER_CRITICAL();
            for(int i = 0; i < 5; i++)
                stat_drop_count[i + 1] = 0;
            taskEXIT_CRITICAL();

            if(bDisplayLog)
            {
                char buf[400];
                setlogFormatStat(buf, sizeof(buf), &f);
                setlogPrint(buf);
            }
        }
    }

    // RX-silence tracker. Counters run always; prints and chip reads only under --loradebug.
    {
        static uint32_t rxs_seq_seen = 0;
        uint32_t seq = g_rxs_ev_seq;
        if(seq != rxs_seq_seen)
        {
            rxs_seq_seen = seq;
            bool _hq = g_rxs_ev_has_q;
            int16_t _rssi = g_rxs_ev_rssi;
            int8_t _snr = g_rxs_ev_snr;
            if(g_rxs.noteRx(g_rxs_ev_ms) && bLORADEBUG)
            {
                // Age of the last CAD / own TX / RX restart before the end ("-" = none since last RX)
                char sc[12], st[12], sr[12];
                rxSilenceFmtSince(sc, sizeof(sc), g_rxs.end_since_cad_ms);
                rxSilenceFmtSince(st, sizeof(st), g_rxs.end_since_tx_ms);
                rxSilenceFmtSince(sr, sizeof(sr), g_rxs.end_since_restart_ms);
                if(_hq)
                    Serial.printf("[MC-DBG] RX_SILENCE_END dur=%lu by=%s since_cad=%s since_tx=%s since_restart=%s rssi=%d snr=%d\n",
                        (unsigned long)g_rxs.end_dur_s, rxSilenceReasonName(g_rxs.end_reason), sc, st, sr, (int)_rssi, (int)_snr);
                else
                    Serial.printf("[MC-DBG] RX_SILENCE_END dur=%lu by=%s since_cad=%s since_tx=%s since_restart=%s rssi=na snr=na\n",
                        (unsigned long)g_rxs.end_dur_s, rxSilenceReasonName(g_rxs.end_reason), sc, st, sr);
            }
        }
        uint32_t _rxs_t = 0;
        if(g_rxs.tick(millis(), &_rxs_t) && bLORADEBUG)
        {
            RadioDiag d;
            taskENTER_CRITICAL();
            radioDiagRead(&d);   // read-only SPI commands, RX stays armed; loop task only
            taskEXIT_CRITICAL();
            Serial.printf("[MC-DBG] RX_SILENCE t=%lu mode=%s drv=%s st=0x%02X irq=0x%04X err=0x%04X rssi_inst=%d cad=%lu/%lu restarts=%lu boosted=%d\n",
                (unsigned long)_rxs_t, radioChipModeName(d.chip_mode), radioDrvModeName(d.drv_mode),
                d.status, d.irq, d.err, (int)d.rssi_inst,
                (unsigned long)g_rxs_cad_busy, (unsigned long)g_rxs_cad_scans,
                (unsigned long)g_rxs_restarts, bBOOSTEDGAIN ? 1 : 0);
        }
    }

    if(iReceiveTimeOutTime > 0)
    {
        INSTR_SECTION("lora_rx_timeout");
        if((uint32_t)(millis() - iReceiveTimeOutTime) >= (uint32_t)csma_timeout)
        {
            if(bLORADEBUG)
                Serial.printf("[MC-DBG] RX_TIMEOUT_FIRE ts=%lu wait=%lu delta=%lu\n",
                    millis(), csma_timeout, millis() - iReceiveTimeOutTime);

            // BUG #1 Aequivalent: Wenn Header erkannt, ist Empfang moeglicherweise
            // noch aktiv. Timer verlaengern statt zuruecksetzen.
            if(is_receiving && rx_irq_defer_count < 3)
            {
                rx_irq_defer_count++;
                iReceiveTimeOutTime = millis();
                if(bLORADEBUG)
                    Serial.printf("[MC-DBG] RX_TIMEOUT_DEFERRED src=is_receiving cnt=%d\n", rx_irq_defer_count);
            }
            else
            {
                if(rx_irq_defer_count >= 3 && bLORADEBUG)
                    Serial.printf("[MC-DBG] RX_IRQ_STALE forced restart after %d deferrals\n", rx_irq_defer_count);
                rx_irq_defer_count = 0;
                iReceiveTimeOutTime = 0;
                RadioDiag _rxs_before = {};
                taskENTER_CRITICAL();
                // Chip mode before the restart (read-only), only for the loradebug line below
                if(bLORADEBUG) radioDiagRead(&_rxs_before);
                startRadioReceive();
                // RX-DEAF-02: startRadioReceive() aborted any reception, so a header latched by OnHeaderDetect()
                // without a following OnRxDone/OnRxError/OnRxTimeout must not keep the TX gate shut. Cleared
                // inside the critical section: a header callback cannot slip in between restart and clear.
                {
                    unsigned long _rx_s = ch_util_rx_start.exchange(0);
                    if(_rx_s > 0)
                        ch_util_rx_accum.fetch_add(millis() - _rx_s);
                }
                is_receiving = false;
                taskEXIT_CRITICAL();
                if(bLORADEBUG)
                {
                    Serial.printf("[MC-SM] IDLE -> RX_LISTEN rc=0\n");
                    Serial.printf("[MC-DBG] RX_RESTART src=timeout mode_before=%s\n",
                        radioChipModeName(_rxs_before.chip_mode));
                }
                g_rxs_restarts++;
                g_rxs.noteAction(RXS_BY_WATCHDOG, millis());
            }
        }
    }
    else if(iReceiveTimeOutTime == 0 && is_receiving && tx_is_active == false)
    {
        // RX-DEAF-02: latch without an armed timer; arm it so the branch above (3 deferrals protect a real
        // reception) eventually restarts RX and clears the flag.
        iReceiveTimeOutTime = millis();
    }

    if(iReceiveTimeOutTime == 0 && is_receiving == false && tx_is_active == false)
    {
        INSTR_SECTION("lora_sm");
        // TXP W1b: "something sendable in the TX pool" (was iWrite != iRead); not
        // txRingDepth() > 0: a parked own text waiting for its ACK is not sendable.
        // A CAD already running or finished must still be consumed here (the
        // CAD is async over several passes; the sendable slot may vanish in
        // between, e.g. TTL sweep or ACK): otherwise a stale "channel free"
        // result would be reused for the next frame without a fresh CAD.
        if (getNextTxSlot() >= 0 || cad_in_progress || cad_done_flag)
        {
            // RACE-05 fix: snapshot CAD flags under critical section,
            // then act on snapshot values outside the lock
            taskENTER_CRITICAL();
            bool _cad_ip = cad_in_progress;
            bool _cad_df = cad_done_flag;
            bool _cad_cb = cad_channel_busy;
            bool _cad_dc = cad_double_check;
            taskEXIT_CRITICAL();

            if(!_cad_ip && !_cad_df)
            {
                // Start CAD scan
                // BP-02: qlen is txRingDepth() (occupied slots), not the raw
                // index distance -- see txRingDepth() doc comment.
                if(bLORADEBUG)
                {
                    Serial.printf("[MC-SM] IDLE -> TX_PREPARE rc=0\n");
                    Serial.printf("[MC-DBG] TX_GATE_ENTER qlen=%d cad_attempt=%d\n",
                        txRingDepth(),
                        cad_attempt);
                }

                taskENTER_CRITICAL();
                cad_in_progress = true;
                cad_done_flag = false;
                cad_double_check = false;
                cad_start_time = millis();
                taskEXIT_CRITICAL();
                taskENTER_CRITICAL();
                Radio.Standby();
                Radio.StartCad();
                taskEXIT_CRITICAL();
                g_rxs.noteAction(RXS_BY_CAD, millis());
            }
            else if(_cad_df)
            {
                taskENTER_CRITICAL();
                cad_in_progress = false;
                cad_done_flag = false;
                taskEXIT_CRITICAL();
                g_rxs_cad_scans++;
                if(_cad_cb) g_rxs_cad_busy++;
                if(bLORADEBUG)
                    Serial.printf("[MC-DBG] CAD_SCAN result=%d\n", _cad_cb ? -702 : 0);

                if(!_cad_cb)
                {
                    if(_cad_dc && bLORADEBUG)
                        Serial.printf("[MC-DBG] CAD_FALSE_POSITIVE\n");
                    // Channel free Ă˘â‚¬â€ť transmit
                    //
                    // Marker-Paritaet mit dem ESP32 (esp32_main.cpp:2688 und 2709):
                    // CAD_FREE meldet den freien Kanal VOR doTX(), TX_START den
                    // tatsaechlich abgesetzten Frame. Vorher stand CAD_FREE im
                    // Erfolgszweig und bedeutete damit dasselbe wie TX_START drueben --
                    // gleicher Name, anderes Ereignis. Eine flottenweite Auswertung,
                    // die CAD_FREE zaehlt, verglich damit zwei verschiedene Groessen:
                    // auf dem ESP32 auch den Fall "Kanal frei, aber nichts gesendet"
                    // (dort folgt CAD_FREE_NO_TX auf CAD_FREE), auf dem nRF52 nicht.
                    if(bLORADEBUG)
                        Serial.printf("[MC-DBG] CAD_FREE attempt=%d\n", cad_attempt);

                    tx_cad_attempt = cad_attempt; // honest cad= in the TX log (csma_reset zeroes it)
                    csma_reset();
                    bool _tx_ok;
                    { INSTR_SECTION("lora_tx"); _tx_ok = doTX(); }
                    if(_tx_ok)
                    {
                        g_rxs.noteAction(RXS_BY_TX, millis());
                        ch_util_tx_start = millis();
                        if(bLORADEBUG)
                        {
                            Serial.printf("[MC-SM] TX_PREPARE -> TX_ACTIVE rc=0\n");
                            // BP-02: qlen ist txRingDepth() (belegte Slots), nicht der
                            // rohe Indexabstand -- siehe Doku-Kommentar von txRingDepth().
                            Serial.printf("[MC-DBG] TX_START qlen=%d\n", txRingDepth());
                        }
                    }
                    else
                    {
                        // doTX() returned false (no ready slot) Ă˘â‚¬â€ť restore RX
                        // to prevent CAD spin loop where radio stays in standby
                        if(bLORADEBUG)
                            Serial.printf("[MC-DBG] CAD_FREE_NO_TX restoring RX\n");
                        taskENTER_CRITICAL();
                        startRadioReceive();
                        taskEXIT_CRITICAL();
                        iReceiveTimeOutTime = millis();
                    }
                }
                else if(!_cad_dc)
                {
                    // First scan busy Ă˘â‚¬â€ť double-check
                    if(bLORADEBUG)
                        Serial.printf("[MC-DBG] CAD_BUSY_1 attempt=%d, double-check...\n", cad_attempt);

                    taskENTER_CRITICAL();
                    cad_double_check = true;
                    cad_in_progress = true;
                    cad_done_flag = false;
                    cad_start_time = millis();
                    taskEXIT_CRITICAL();
                    taskENTER_CRITICAL();
                    Radio.Standby();
                    Radio.StartCad();
                    taskEXIT_CRITICAL();
                    g_rxs.noteAction(RXS_BY_CAD, millis());
                }
                else
                {
                    // Double-check confirmed busy Ă˘â‚¬â€ť backoff
                    cad_attempt++;
                    csma_timeout = csma_compute_timeout_nofloor(cad_attempt); // CAD_BUSY: no age floor

                    if(bLORADEBUG)
                    {
                        Serial.printf("[MC-SM] TX_PREPARE -> IDLE rc=-1\n");
                        Serial.printf("[MC-DBG] CAD_BUSY attempt=%d next_timeout=%lu\n",
                            cad_attempt, csma_timeout);
                    }

                    taskENTER_CRITICAL();
                    startRadioReceive();
                    taskEXIT_CRITICAL();
                    iReceiveTimeOutTime = millis();
                }
            }
            else if(_cad_ip && (millis() - cad_start_time > 100))
            {
                // Safety timeout: CadDone never fired
                if(bLORADEBUG)
                    Serial.printf("[MC-DBG] CAD_SAFETY_TIMEOUT\n");

                taskENTER_CRITICAL();
                cad_in_progress = false;
                cad_done_flag = false;
                taskEXIT_CRITICAL();
                taskENTER_CRITICAL();
                startRadioReceive();
                taskEXIT_CRITICAL();
                iReceiveTimeOutTime = millis();
            }
        }
        else
        {
            // Nothing to send Ă˘â‚¬â€ť restart timeout cycle (radio watchdog).
            // Matches ESP32 esp32_main.cpp behaviour: periodic Radio.Rx()
            // prevents silent SX1262 stall when queue is empty.
            iReceiveTimeOutTime = millis();
        }
    }

    #if defined(ENABLE_GPS)
    if(bGPSON)
    {
        INSTR_SECTION("gps_init");
        WZ_GPS_Init();
    }
    #endif

    // SOFTSER
    #if defined(ENABLE_SOFTSER)
    if(bSOFTSERON)
    {
        INSTR_SECTION("softser");
        // check every 5 seconds to ready next telemetry via serial interface
        if ((uint32_t)(millis() - softser_refresh_timer) >= 5000 && softserFunktion == 0)
        {
            if(lastSOFTSER_MINUTE != meshcom_settings.node_date_minute)
            {
                if(meshcom_settings.node_date_minute % SOFTSER_REFRESH_INTERVAL  == 0)
                {
                    lastSOFTSER_MINUTE = meshcom_settings.node_date_minute;

                    // start SOFTSER APP
                    loopSOFTSER(SOFTSER_APP_ID);
                }
            }

            softser_refresh_timer = millis();
        }
        else
        if (bSOFTSER_APP)
        {
            bSOFTSER_APP = false;

            softserFunktion = 0;

            lastSOFTSER_MINUTE = meshcom_settings.node_date_minute;
            
            // start SOFTSER APP
            loopSOFTSER(SOFTSER_APP_ID);
        }
        else
        {
            appSOFTSER(SOFTSER_APP_ID);
        }
    }
    #endif

    btn.tick();

    // BLE Queue: process data from the BLE task in Main Loop context (CONC-14)
    {
        BleQueueItem bleItem;
        while (xQueueReceive(bleQueue, &bleItem, 0) == pdTRUE) {
            { INSTR_SECTION("ble_cmd"); readPhoneCommand(bleItem.data); }
        }
        // Auth failure: disconnect now, not on the phone's next write.
        extern void nrf52BleServiceDisconnect(void);
        nrf52BleServiceDisconnect();
    }

    // BLC-02: deferred disconnect reason, advertising self-check, --bledebug stats
    {
        extern void nrf52BleTick(void);
        nrf52BleTick();
    }

    // Apply a settings write staged by settings_rx_callback(), if any (CONC-17)
    { INSTR_SECTION("ble_settings"); applyPendingBleSettings(); }

    // check if message from phone to send
    if(hasMsgFromPhone)
    {
        INSTR_SECTION("phone_msg");
        if(memcmp(textbuff_phone, ":", 1) == 0)
        {
            // BP-01: tag the origin so the back-pressure notice goes back to
            // the phone that just typed, and never over the air.
            setMsgOrigin(ORIGIN_BLE);
            (void)sendMessage(textbuff_phone, txt_msg_len_phone);
            setMsgOrigin(ORIGIN_NONE);
        }

        if(memcmp(textbuff_phone, "-", 1) == 0)
            commandAction(textbuff_phone, isPhoneReady, true);

        hasMsgFromPhone = false;
    }

    // D1-10 loop scheduler: mcp_refresh_timer moved to the scheduler call above.

    #if defined(ENABLE_GPS)
        gKeyNum = 2;
    #endif


    if(gKeyNum == 1)
    {
        INSTR_SECTION("key1");
        Serial.println("gKeyNum == 1");

        //getTEMP();

        //getPRESSURE();

        gKeyNum = 0;
    }

    if(gKeyNum == 2)
    {
        INSTR_SECTION("key2");
        //TEST Serial.println("gKeyNum == 2");

        #if defined(ENABLE_RAK_GPS)
        if(bGPSON)
        {
            // gps refresh every 10 sec
            if ((uint32_t)(millis() - gps_refresh_timer) >= (uint32_t)(GPS_REFRESH_INTERVAL * 1000))
            {
                unsigned int igps = getGPS();

                if(igps > 0)
                    posinfo_interval = igps;
                else
                {
                    no_gps_reset_counter++;
                    if(no_gps_reset_counter > 10)
                    {
                        posinfo_interval = POSINFO_INTERVAL;
                        no_gps_reset_counter = 0;
                    }
                }

                gps_refresh_timer = millis();
            }
        }
        #endif

        #if defined(ENABLE_GPS)
        if(bGPSON)
        {
            if (gpsDetected) { INSTR_SECTION("gps_feed"); WZ_GPS_Feed(); }

            // gps refresh every sec
            if ((uint32_t)(millis() - gps_refresh_timer) >= 1000)
            {
                unsigned int igps = POSINFO_INTERVAL;

                if(gpsDetected)
                {
                    { INSTR_SECTION("gps"); igps = WZ_GPS_Loop(); }

                    if(iGPSDEBUG > 0)
                    {
                        Serial.printf("[GPS ]...fix:%s sat:%i hdop:%.1lf\n", (posinfo_fix?"yes":"no"), gpsData.satellites, gpsData.hdop);

                        Serial.print("[GPS ]...Time <UTC>: ");
                        if (gpsData.hour < 10) Serial.print(F("0"));
                        Serial.print(gpsData.hour);
                        Serial.print(F(":"));
                        if (gpsData.minute < 10) Serial.print(F("0"));
                        Serial.print(gpsData.minute);
                        Serial.print(F(":"));
                        if (gpsData.second < 10) Serial.print(F("0"));
                        Serial.print(gpsData.second);

                        Serial.print(F(" / Date: "));
                        Serial.print(gpsData.year);
                        Serial.print(F("."));
                        if (gpsData.month < 10) Serial.print(F("0"));
                        Serial.print(gpsData.month);
                        Serial.print(F("."));
                        if (gpsData.day < 10) Serial.print(F("0"));
                        Serial.println(gpsData.day);

                        if(posinfo_fix)
                        {
                            Serial.printf("[GPS ]...position  : lat:%.6lf lon:%.6lf alt:%.1lf\n", gpsData.latitude, gpsData.longitude, gpsData.altitude);
                        }

                    }
                }
                
                if(igps > 0)
                    posinfo_interval = igps;
                else
                {
                    no_gps_reset_counter++;
                    if(no_gps_reset_counter > 10)
                    {
                        posinfo_interval = POSINFO_INTERVAL;
                        no_gps_reset_counter = 0;
                    }
                }

                gps_refresh_timer = millis();
            }
        }
        #endif
        
        #if defined(ENABLE_RAK_GPS) || defined(ENABLE_GPS)
        if(bGPSON)
        {
            // check GPS ON and activ --> <gKeyNum == 2> the signal must be active
            if ((uint32_t)(millis() - gps_refresh_timer) >= (uint32_t)(5 * (GPS_REFRESH_INTERVAL * 1000)))
            {
                posinfo_fix = false;
                posinfo_satcount = 0;
                fposinfo_hdop = 0.0;
                posinfo_interval = POSINFO_INTERVAL;
            }
        }
        #endif
        
        gKeyNum = 0;
    }

    if(gKeyNum == 3)
    {
        INSTR_SECTION("key3");
        Serial.println("Right button pressed");

        gKeyNum = 0;
    }


    if (isPhoneReady == 1)
    {
        if (config_to_phone_prepare)
        {
            for(int config_cmds_index=0; config_cmds_index < json_configs_cnt; config_cmds_index++)
            {
                commandAction((char*)config_cmds[config_cmds_index], isPhoneReady, true);
            }

            mhPhoneListStart(); // MHeard-Liste erst, wenn der Kommando-Ring leer ist (siehe unten)

            config_to_phone_prepare_timer=millis();

            config_to_phone_prepare = false;
        }
        else
        {
            // wait after BLE Connect 3 sec.
            if((uint32_t)(millis() - config_to_phone_prepare_timer) < 3000)
                iPhoneState = 0;

            if (iPhoneState > 3)   // only every 6 times of mainloop send to phone  RAK 2 x ESP
            {
                // prepare JSON config to phone after BLE connection
                // send JSON config to phone after BLE connection
                if (!bf_empty(&phoneComRing))
                {
                    sendComToPhone();
                }
                else if (mhPhoneListPending())
                {
                    // Kommando-Ring leer: naechste Portion der MHeard-Liste nachlegen
                    mhPhoneListStep();
                }
                else if (!bf_empty(&phoneRing))
                {
                    sendToPhone();
                }
                else if (!conffin_sent)
                {
                    // both queues empty Ă˘â‚¬â€ť send config finish once
                    commandAction((char*)"--conffin", isPhoneReady, true);
                    conffin_sent = true;
                }

                iPhoneState = 0;
            }
            else
            {
                iPhoneState++;
            }
        }

        // 5 minuten
        if((uint32_t)(millis() - config_to_phone_datetime_timer) >= (5 * 60 * 1000))
        {
            bNTPDateTimeValid=false;

            config_to_phone_datetime_timer = millis();
        }
    }

    // check NCNT modified -- MeshCom 5 (Welle 4, Konzept 4.8): lokaler
    // Vergleich, nicht die Sendefassung -- nbrNcnt(), nicht nbrNcntAir().
    int incnt = nbrNcnt(nbrMatrix, uptimeMin16());
    if(ncnt_hold != incnt)
    {
        INSTR_SECTION("pos_timer");
        // minimal alle 60 sec
        if((uint32_t)(millis() - posinfo_timer_min) >= 60000)
        {
            posinfo_shot = true;
            ncnt_hold = incnt;
        }
    }

    // posinfo
    //Serial.print(getTimeString());
    //Serial.printf(" posinfo_timer:%ld posinfo_interval:%ld timer:%ld millis:%ld\n", posinfo_timer, posinfo_interval, (posinfo_timer + (posinfo_interval * 1000)), millis());

    // posinfo_interval in Seconds
    if (((uint32_t)(millis() - posinfo_timer) >= (uint32_t)(posinfo_interval * 1000)) || (millis() > 100000 && millis() < 130000 && bPosFirst) || posinfo_shot)
    {
        // minimal transmit time only max 30 sec
        if((uint32_t)(millis() - posinfo_timer_min) >= 30000)
        {
            if(bDisplayInfo)
            {
                Serial.print(getTimeString());
                Serial.printf(" [POS]...sendPostion initialized F:%i S:%i\n", bPosFirst, posinfo_shot);
            }

            bPosFirst = false;

            // posinfo_prev is SmartBeaconing's TRACK point; with TRACK off (or none yet) send the node position
            if(posinfo_shot && bDisplayTrack && (posinfo_prev_lat != 0.0 || posinfo_prev_lon != 0.0))
            {
                double slat = 0.0;
                double slon = 0.0;

                double slatr=60.0;
                double slonr=60.0;

                slat = (int)posinfo_prev_lat;
                slatr = (posinfo_prev_lat - slat) * slatr;
                slat = (slat * 100.) + slatr;

                slon = (int)posinfo_prev_lon;
                slonr = (posinfo_prev_lon - slon) * slonr;
                slon = (slon * 100.) + slonr;
                double node_lat = cround4(posinfo_prev_lat);
                double node_lon = cround4(posinfo_prev_lon);

                char node_lat_c = 'N';
                char node_lon_c = 'E';

                if(posinfo_prev_lat < 0.0)
                    node_lat_c='S';
                else
                    node_lat_c='N';

                if(posinfo_prev_lon < 0.0)
                    node_lon_c='W';
                else
                    node_lon_c='E';

                { INSTR_SECTION("pos_tx"); sendPosition(posinfo_interval, node_lat, node_lat_c, node_lon, node_lon_c, meshcom_settings.node_alt, meshcom_settings.node_press, meshcom_settings.node_hum, meshcom_settings.node_temp, meshcom_settings.node_temp2, meshcom_settings.node_gas_res, meshcom_settings.node_co2, meshcom_settings.node_press_alt, meshcom_settings.node_press_asl); }
            }
            else
            {
                { INSTR_SECTION("pos_tx"); sendPosition(posinfo_interval, meshcom_settings.node_lat, meshcom_settings.node_lat_c, meshcom_settings.node_lon, meshcom_settings.node_lon_c, meshcom_settings.node_alt, meshcom_settings.node_press, meshcom_settings.node_hum, meshcom_settings.node_temp, meshcom_settings.node_temp2, meshcom_settings.node_gas_res, meshcom_settings.node_co2, meshcom_settings.node_press_alt, meshcom_settings.node_press_asl); }
            }

            posinfo_shot=false;

            posinfo_prev_lat = 0.0; // done
            posinfo_prev_lon = 0.0; // done

            posinfo_last_lat=posinfo_lat;
            posinfo_last_lon=posinfo_lon;

            posinfo_last_direction=posinfo_direction;
            posinfo_distance = 0.0;

            posinfo_timer = millis();

            if(pos_shot)
            {
                commandAction((char*)"--pos", isPhoneReady, false);
                pos_shot = false;
            }

            posinfo_timer_min = millis();
        }
    }
    else
    {
        posinfo_timer_min = millis();
    }

    // Trickle-HEY: adaptive interval (RFC 6206)
    if (((uint32_t)(millis() - heyinfo_timer) >= trickle_interval_ms) || bHeyFirst)
    {
        bHeyFirst = false;

        // Check for topology change -- lokaler Vergleich (Konzept 4.8: die
        // Trickle-Ruecksetzung ist kein Sender).
        int current_neighbors = nbrNcnt(nbrMatrix, uptimeMin16());
        if(trickle_last_neighbor_count >= 0 && current_neighbors != trickle_last_neighbor_count)
        {
            trickle_interval_ms = TRICKLE_IMIN_S * 1000UL;
            trickle_consistent_count = 0;
        }
        trickle_last_neighbor_count = current_neighbors;

        // Trickle suppression; F6: a gateway keeps sending at least one HG per Imax.
        if(heyTrickleSuppress(trickle_consistent_count))
        {
            if(bDisplayInfo)
                Serial.printf("[MC-TRICKLE] SUPPRESS consistent=%d interval=%lums\n",
                    trickle_consistent_count, trickle_interval_ms);
        }
        else
        {
            { INSTR_SECTION("hey_tx"); sendHey(); }
        }

        trickle_interval_ms = min(trickle_interval_ms * 2, TRICKLE_IMAX_S * 1000UL);
        trickle_consistent_count = 0;

        heyinfo_timer = millis();
    }

    // HN-Bericht (Nachbarschaftsmatrix Stufe 3, --nbrreport): eigener Takt,
    // unabhaengig vom Trickle-Intervall oben und nie unterdrueckt -- siehe
    // nbrReportTick() in loop_functions.cpp fuer Zeitplan und Modus-Auswertung.
    nbrReportTick();

    // --nbrdebug (24-h-Dauertest der Nachbarschaftsmatrix): 15-Minuten-Takt fuer
    // nbrLogSnapshot(). Nur im Loop, NICHT im Timer-Task -- der hat auf nRF52 nur
    // 1 kB Stack, nbrLogSnapshot() formatiert in einen 160-Byte-Puffer und laeuft
    // ueber alle Zeilen. Laeuft nur, wenn das Flag gesetzt ist; nbrDebugApply()
    // setzt nbrsnap_timer beim Einschalten zurueck, damit der erste Schnappschuss
    // nicht erst 15 Minuten nach dem Einschalten kommt.
    if(bNBRDEBUG && (uint32_t)(millis() - nbrsnap_timer) >= 900000UL)
    {
        nbrsnap_timer = millis();
        nbrLogSnapshot(nbrMatrix, uptimeMin16());
    }

    // Nachbarschaftsmatrix (Welle 2, edge pool): Minuten-Sweep (nbrSweep(),
    // CONTRACT in nbr_matrix.h) -- IMMER, unabhaengig von --nbrdebug (das
    // steuert nur den 15-Minuten-Schnappschuss oben). Loop-Task, NICHT
    // Timer-Task (der hat auf nRF52 nur 1 kB Stack, gleiche Begruendung wie
    // bei nbrLogSnapshot() oben). nbrSweep() selbst ist ein No-Op bei einem
    // zweiten Aufruf in derselben Minute; die Minuten-Waechter hier spart
    // trotzdem den Funktionsaufruf bei jedem Loop-Durchlauf.
    {
        static uint16_t s_nbr_sweep_min = 0xFFFF;
        uint16_t now_min_sweep = uptimeMin16();
        if(now_min_sweep != s_nbr_sweep_min)
        {
            s_nbr_sweep_min = now_min_sweep;
            nbrSweep(nbrMatrix, now_min_sweep);
            // Konsistenzpruefung Masken <-> Kantenpool (nbrLogCheck(), [NBR]|CHECK),
            // einmal je Minute, nur bei --nbrdebug: auf nRF52 das Instrument fuer
            // Task-Wechsel mitten in einer Aenderung (Konzept 5).
            if(bNBRDEBUG)
                nbrLogCheck(nbrMatrix, now_min_sweep);
        }
    }

    // TELEMETRY_INTERVAL in Minutes == 15 minutes default
    unsigned long akt_timer = meshcom_settings.node_parm_time;
    if(akt_timer < 5 || akt_timer > 120)
    {
        INSTR_SECTION("akt_timer");
        akt_timer = 15;   // default 15 minutes (TELEMETRY_INTERVAL is 30*60 and read as minutes = 30 h)
    }
    
    akt_timer = akt_timer * 1000 * 60; // in minutes

    if(iNextTelemetry < 5)
        akt_timer= 15 * 1000; // 15 Seconds PARM, UNIT, EQNS and 1st T-Message

    if (((uint32_t)(millis() - telemetry_timer) >= (uint32_t)akt_timer) || bTeleFirst)
    {
        bTeleFirst = false;

        { INSTR_SECTION("telemetry"); sendTelemetry(telemetryAppId(bSOFTSERON, SOFTSER_APP_ID)); }

        telemetry_timer = millis();
    }
    
    // ETH-01: link poll/heartbeat and the DHCP lease refresh must run
    // whenever Ethernet is up, not only for bGATEWAY -- a gateway-off /
    // webserver-on node (bWEBSERVER, see setup ~1086) has ETH hardware too
    // and was never renewing its lease nor logging link state. Both
    // functions already self-guard on neth.hasETHHardware (false when
    // neither bGATEWAY nor bWEBSERVER is set), so hoisting them here is a
    // no-op for nodes without ETH. Order: link edges/heartbeat first, then
    // the DHCP renew check, then (below) either the gateway UDP get/send or
    // the TM-45 NTP-only harvest -- exactly one of the latter two per pass.

    // TM-35 / N-20 instrumentation: link edges and the 60-s heartbeat
    ethLinkPoll();
    ethLinkHeartbeat();

    // DHCP refresh
    if(neth.hasETHHardware && (uint32_t)(millis() - dhcp_timer) >= (uint32_t)(DHCP_REFRESH * 60000))
    {
        // no need on static IPs
        if(!ethIsStaticConfigured())
        {
            if(bDEBUG)
            {
                Serial.print(getTimeString());
                Serial.println(" [MAIN] checkDHCP");
            }

            { INSTR_SECTION("eth_dhcp"); neth.checkDHCP(); }
        }

        dhcp_timer = millis();
    }

    // ETH-02: DHCP ACQUISITION retry -- the renewal above cannot do this job.
    //
    // checkDHCP() is Ethernet.maintain() (nrf_eth.cpp:709), which renews or
    // rebinds an EXISTING lease. A node that never got one has nothing to
    // maintain, and maintain() returns 0 forever. The only path that actually
    // re-acquires is resetDHCP()/initethfixIP(), and that path lives inside
    // gatewayService_nrf52()'s `if(bGATEWAY)` block -- so until now a node with
    // the gateway OFF (webserver-only, or an EXTUDP peer) had exactly ONE
    // attempt, in setup, and no second chance ever.
    //
    // Measured on DK5EN-90, 2026-09-17, with the cable physically seated:
    //   [ETH];link;down;link;1;...;ip;0.0.0.0;...;got_ip_n;0;downs;0;resets;0
    // Read that line carefully -- `link;1` is the PHY reporting the cable UP,
    // while the node sits at 0.0.0.0, has never once obtained a lease
    // (got_ip_n;0) and has never once retried (resets;0). It stayed that way
    // across a physical replug, because nothing was ever going to try again.
    //
    // resetDHCP(), not initethDHCP(): that is the N-20 distinction and it
    // matters here for the same reason it matters in the gateway path --
    // initethDHCP() hardware-resets the W5100S on every retry, after which PHY
    // negotiation needs seconds and startETH() sees a permanent LinkOFF.
    // resetDHCP() re-runs DHCP without the PHY reset.
    //
    // Gated on hasETHlink() so we do not hammer DHCP on a node with no cable
    // in it, and on a 30 s interval so a genuinely absent DHCP server costs
    // one attempt per half minute rather than one per loop pass.
    //
    // ETH-05: static nodes are included. For them resetDHCP() takes the
    // ReapplyStatic path (no DHCP exchange: reopen UDP / re-apply the static
    // address / hardware reset), so this is the static retry too. Without it a
    // static node whose recovery ended with hasIPaddress=false (bench DK5EN-90:
    // PHY back ~4 s after the W5100S reset) never retried: UDP TX is skipped
    // without an IP and the gateway watchdog runs on bGATEWAY nodes only.
    // The checkDHCP() renewal above stays DHCP-only (no lease to renew).
    if(neth.hasETHHardware && !neth.hasIPaddress)
    {
        static uint32_t eth_acquire_timer = 0;
        if(eth_acquire_timer == 0 || (uint32_t)(millis() - eth_acquire_timer) >= 30000)
        {
            eth_acquire_timer = millis();

            bSPI_ETH_Active = true;   // SPI guard: Ethernet owns the shared bus
            bool link = neth.hasETHlink();
            if(link)
            {
                Serial.printf("[ETH];event;dhcp_acquire_retry;link;1;ms;%lu\n",
                              (unsigned long)millis());
                neth.resetDHCP();
                // ETH-02b (bench 2026-09-18, DK5EN-90): when this retry is what
                // finally gets the lease, nothing re-starts the services --
                // setup() had started the webserver at boot without an IP, and
                // the block below only re-runs on its 15-minute web_timer, so
                // the node sat pingable on .66 with EXTUDP answering (the UDP
                // socket binds without an IP) and the webserver dead for a
                // quarter of an hour, --info still saying "hasIpAddress: no"
                // (that flag is only copied there). Zeroing web_timer makes
                // the next pass re-run that block: flag copy, webserver and
                // extern socket start, exactly what a first-try lease gets.
                if(neth.hasIPaddress)
                {
                    Serial.printf("[ETH];event;dhcp_acquired_late;ms;%lu\n",
                                  (unsigned long)millis());
                    web_timer = 0;
                }
            }
            bSPI_ETH_Active = false;
            if(bPendingRadioRx) { bPendingRadioRx = false; startRadioReceive(); }
        }
    }

    // C4 carve-out: the gateway service block lives in gateway_service_nrf52.cpp
    gatewayService_nrf52();

    #if defined(SHTC3)

    // TEMP/HUM
    if (((uint32_t)(millis() - temphum_timer) >= TEMPHUM_INTERVAL))
    {
        if(shtc3_found)
        {
            INSTR_SECTION("shtc3");
            getTEMP();
        }

        temphum_timer = millis();
    }

    #endif

    #if defined(LPS33)

    if(bLPS33)
    {
        INSTR_SECTION("lps33");
        // DRUCK
        if (((uint32_t)(millis() - druck_timer) >= DRUCK_INTERVAL))
        {
            getPRESSURE();

            druck_timer = millis();

            if(wx_shot)
            {
                commandAction((char*)"--wx", isPhoneReady, true);
                wx_shot = false;
            }
        }
    }

    #endif

    { INSTR_SECTION("display_tick"); mainStartTimeLoop(); }

    if(DisplayOffWait > 0)
    {
        INSTR_SECTION("display_off");
        if ((int32_t)(millis() - DisplayOffWait) > 0)
        {
            DisplayOffWait = 0;
            if(bDisplayOff)
            {
                bDisplayIsOff=true;

                #if defined(BOARD_HELTEC_T114)
                digitalWrite(PIN_TFT_LEDA_CTL, HIGH);   // TFT OFF
                #endif

                sendDisplay1306(true, true, 0, 0, (char*)"#C");
            }
        }
    }
    
    // rebootAuto
    if(rebootAuto > 0)
    {
        INSTR_SECTION("reboot_auto");
        if ((int32_t)(millis() - rebootAuto) > 0)
        {
            rebootAuto = 0;

            #ifdef ESP32
                ESP.restart();
            #endif

            #if defined NRF52_SERIES
                // dfuAuto: --dfu will den UF2-Bootloader statt eines normalen
                // Neustarts. Beides laeuft ueber denselben verzoegerten Pfad, damit
                // die Quittung noch ueber BLE bzw. Seriell rausgeht, bevor der Reset
                // kommt -- ein Reset direkt in commandAction() verschluckt sie.
                //
                // N-19: enterUf2Dfu() (reset_mcu() in cores/nRF5/wiring.c) haengt
                // aus diesem Loop-Task -- auf Hardware reproduziert: --dfu liess das
                // Board mit stehender CPU zurueck (USB-Deskriptor blieb App-PID, kein
                // Reset). Derselbe reset_mcu()-Pfad funktioniert aus dem TinyUSB-Task
                // (1200-Baud-Touch), und NVIC_SystemReset() funktioniert aus genau
                // diesem Loop-Pfad (--reboot) -- verdaechtig ist sd_softdevice_disable()
                // im Loop-Kontext. Deshalb hier ohne SD-Disable: GPREGRET per
                // SoftDevice-SVC setzen (bei aktivem SoftDevice erlaubt, das BLE-Init
                // laeuft auf nRF52 immer) und den bewaehrten NVIC_SystemReset()
                // nehmen; der Bootloader liest GPREGRET beim Start und bleibt im
                // UF2-Modus (USB-Laufwerk).
                if(bEnterDfu)
                {
                    bEnterDfu = false;
                    sd_power_gpregret_clr(0, 0xFF);
                    sd_power_gpregret_set(0, 0x57);   // DFU_MAGIC_UF2_RESET (cores/nRF5/wiring.c)
                    uint32_t gpr = 0;
                    sd_power_gpregret_get(0, &gpr);
                    printfdeb("...GPREGRET=0x%02lX (0x57 -> UF2-Bootloader)\n", (unsigned long)gpr);
                    // Ack/Log noch ueber die CDC rausschreiben, bevor der Reset die
                    // USB-Verbindung kappt. Ohne flush+Wartezeit kam das Board in
                    // einem Hardware-Test trotz korrekt gesetztem GPREGRET als App
                    // statt als Bootloader zurueck.
                    Serial.flush();
                    delay(300);
                }

                NVIC_SystemReset();     // resets the device
            #endif
        }
    }

    { INSTR_SECTION("serial_cmd"); checkSerialCommand(); }

    // D1-10 loop scheduler: BattTimeWait and heapMonTimer moved to the
    // scheduler call (BattTimeWait's zero-init stays at the top of the
    // loop -- see the comment there; heapMonTimer's zero-init lives inside
    // loopEnabled_heapMon(), loop_actions_nrf52.cpp).

    #ifdef OneWire_GPIO
    if(bONEWIRE)
    {
        if(onewireTimeWait == 0)
            onewireTimeWait = millis() - 10000;


        if ((uint32_t)(millis() - onewireTimeWait) >= 30000)  // 30 sec
        {
            //if (tx_is_active == false && is_receiving == false)
            {
                if(one_found)
                    loop_onewire_ds18();

                if(dht_found)
                    loop_onewire_dht();

                onewireTimeWait = millis();

                if(wx_shot)
                {
                    commandAction((char*)"--wx", isPhoneReady, true);
                    wx_shot = false;
                }
            }
        }
    }
    #endif

    // read BMP Sensor
    #if defined(ENABLE_BMX280) || defined(ENABLE_AHT20)
    if(((bBMPON || bBMEON) && bmx_found) || (bAHT20ON && aht20_found))
    {
        unsigned long lreduction = 0;

        if ((uint32_t)(millis() - BMXTimeWait) >= 60000)   // 60 sec
        {
            #if defined(ENABLE_BMX280)
                if(loopBMX280())
                {
                    if(!aht20_found && !bmp3_found)
                    {
                        meshcom_settings.node_temp = getTemp();
                    }

                    if(!aht20_found)
                    {
                        meshcom_settings.node_hum = getHum();
                    }

                    if(!bmp3_found)
                    {
                        meshcom_settings.node_press = getPress();
                        meshcom_settings.node_press_alt = getPressALT();
                        meshcom_settings.node_press_asl = getPressASL(meshcom_settings.node_alt);
                    }

                    bmx_start = 0;
                }
                else
                {
                    if(bmx_start > 0)
                        lreduction = 58000;
                }
            #endif


            #if defined(ENABLE_AHT20)
                if(loopAHT20())
                {
                    meshcom_settings.node_temp = getAHT20Temp();
                    meshcom_settings.node_hum = getAHT20Hum();
                }
            #endif

            if(wx_shot)
            {
                commandAction((char*)"--wx", isPhoneReady, false);
                wx_shot = false;
            }

            BMXTimeWait = millis() - lreduction; // wait for next messurement
        }
    }
    #endif

    // D1-10 loop scheduler: BMP3TimeWait, MCU811TimeWait and INA226TimeWait
    // moved to the scheduler call (bodies/guards/seeds in
    // loop_actions_nrf52.cpp).

    // read every n seconds the bme680 sensor calculated from millis()
    #if defined(ENABLE_BMX680)
    if(bBME680ON && bme680_found)
    {
        if ((uint32_t)(millis() - bme680_timer) >= 60000 || delay_bme680 <= 0)
        {
            if (delay_bme680 <= 0)
            {
                getBME680();

            }

            if(wx_shot)
            {
                commandAction((char*)"--wx", isPhoneReady, true);
                wx_shot = false;
            }

            // calculate delay
            delay_bme680 = bme680_get_endTime() - millis();

            bme680_timer = millis();
        }
    }
    #endif

    // heartbeat
    if (bGATEWAY)
    {
        if ((uint32_t)(millis() - hb_timer) >= (uint32_t)(HEARTBEAT_INTERVAL * 1000))
        {
            if(bDisplayCont)
            {
                Serial.print(getTimeString());
                Serial.printf(" [UDP] sending Heartbeat\n");
            }

            { INSTR_SECTION("eth_heartbeat"); sendHeartbeat(); }

            hb_timer = millis();
        }
    }

    if(bEXTUDP)
    {
        // ETH-03: one number for the whole guard-hold -- how long the SPI
        // bus is unavailable to the radio/webserver for this pass.
        INSTR_SECTION("extudp_guard");
        bSPI_ETH_Active = true;   // SPI guard: Ethernet owns bus
        getExternUDP();
        flushExternQueue();
        bSPI_ETH_Active = false;  // SPI guard: release bus
        if(bPendingRadioRx) { bPendingRadioRx = false; startRadioReceive(); }
    }

    if(bWEBSERVER || bEXTUDP)
    {
        if (web_timer == 0 || ((uint32_t)(millis() - web_timer) >= (uint32_t)(HEARTBEAT_INTERVAL * 1000 * 30)))   // repeat 15 minutes
        {
            meshcom_settings.node_hasIPaddress = neth.hasIPaddress;

            web_timer = millis();

            #ifndef BOARD_RAK4630
                // restart WEB-Client
                stopWebserver();

                if(!meshcom_settings.node_hasIPaddress)
                    startWIFI();
            #endif

            // N-20-Falle: ohne initialisiertes Ethernet (Setup ueberspringt die
            // HW-Initialisierung, wenn weder Gateway noch Webserver aktiv sind,
            // oder es ist keine RAK13800 gesteckt) blockieren W5100S-Socket-Ops
            // (UdpExtern.begin()/sendExternHeartbeat()) den Loop-Task unbegrenzt
            // -- Node wirkt tot, Konsole ohne Echo, nur 1200-Baud-Touch hilft.
            // Reproduziert 2026-08-22: --extudp on bei Gateway/Webserver off
            // friert den Loop ab dem naechsten Durchlauf dauerhaft ein (auch
            // nach jedem Reboot, da gespeichert). Deshalb: Start nur mit IP.
            if(bWEBSERVER && neth.hasIPaddress)
            {
                bSPI_ETH_Active = true;
                startWebserver();
                bSPI_ETH_Active = false;
                if(bPendingRadioRx) { bPendingRadioRx = false; startRadioReceive(); }
            }

            if(bEXTUDP && neth.hasIPaddress)
            {
                bSPI_ETH_Active = true;
                startExternUDP();
                bSPI_ETH_Active = false;
                if(bPendingRadioRx) { bPendingRadioRx = false; startRadioReceive(); }
            }
        }

        if(bWEBSERVER)
        {
            // ETH-03: the starvation victim -- compare against extudp_guard
            // to tell "webserver stalled because EXTUDP held the bus" from
            // "webserver stalled on its own".
            bSPI_ETH_Active = true;   // SPI guard: Ethernet owns bus (web page delivery)
            { INSTR_SECTION("webserver_loop"); loopWebserver(); }
            bSPI_ETH_Active = false;  // SPI guard: release bus
            if(bPendingRadioRx) { bPendingRadioRx = false; startRadioReceive(); }
        }

    }

    if (resendPing == 0)
        resendPing = millis();

    if(meshcom_settings.node_pingtime > 29)
    {
        if((int32_t)(millis() - (resendPing + meshcom_settings.node_pingtime * 1000)) > 0)
        {
            resendPing = millis();

            if(bDisplayInfo)
                printfdeb("[PING]...send Ping to %s\n", meshcom_settings.node_pingcall);

            if(meshcom_settings.node_pingcall[0] != 0x00)
            {
                PingResult pingResult = sendPing(meshcom_settings.node_pingcall);

                // Fehlschlag auÄ‚Ĺşerhalb von bDisplayInfo sichtbar machen, sonst verstummt
                // der Knoten fÄ‚Ä˝r jeden, der mit Info aus lÄ‚Â¤uft, ohne jede Meldung.
                // PING_INVALID_TARGET logs its own notice in sendPing().
                if(pingResult != PING_QUEUED && pingResult != PING_INVALID_TARGET)
                    printfdeb("[PING]...FAILED Ping to %s\n", meshcom_settings.node_pingcall);
            }
        }
    }


    #if defined(HAS_TFT_114) or defined(BOARD_T_ECHO)
    }   // else from 
    #endif

    //  We are on FreeRTOS, give other tasks a chance to run
    delay(100);

    yield();
}

/** @brief Function to check if the modem detected a preamble
 */
void blinkLED()
{
    #if not defined(BOARD_HELTEC_T114)
    digitalWrite(LED_GREEN, LED_STATE_ON);
    delay(20);
    digitalWrite(LED_GREEN, !LED_STATE_ON);
    #endif
}

void blinkLED2()
{
    #if not defined(BOARD_HELTEC_T114)
    digitalWrite(LED_BLUE, LED_STATE_ON);
    delay(20);
    digitalWrite(LED_BLUE, !LED_STATE_ON);
    #endif
}


/**@brief Function for handling a LoRa tx timer timeout event.
 */
void getTEMP(void)
{
    sensors_event_t humidity, temp;

    shtc3.getEvent(&humidity, &temp); // populate temp and humidity objects with fresh data

    if(bWXDEBUG)
    {
        Serial.print("Temperature: "); Serial.print(temp.temperature); Serial.println(" degrees C");
        Serial.print("Humidity: "); Serial.print(humidity.relative_humidity); Serial.println("% rH");
    }

    meshcom_settings.node_temp2 = temp.temperature + meshcom_settings.node_tempo_off;
    meshcom_settings.node_hum = humidity.relative_humidity;
}

/**@brief Function for handling a LoRa tx timer timeout event.
 */
void getPRESSURE(void)
{
    sensors_event_t temp;
    sensors_event_t pressure;
    
    g_lps22hb.getEvent(&pressure, &temp);

    if(bWXDEBUG)
    {
        Serial.print("Temperature: ");Serial.print(temp.temperature);Serial.println(" degrees C");
        Serial.print("Pressure: ");Serial.print(pressure.pressure);Serial.println(" hPa");
        Serial.println("");
    }
    
    //double home_alt=meshcom_settings.node_alt;    // HÄ‚Â¶he des Standorts
    //double temperature_gradient = 0.0065;           // Standard-Temperaturgradient
    //double temperatureK = temp.temperature + 273.15;     // Temperatur in Kelvin
    
    // barometrische HÄ‚Â¶henformel
    //meshcom_settings.node_press = pressure.pressure * pow((temperatureK / (temperatureK + home_alt * temperature_gradient)) , -5.255);
    if(bLPS33)
    {
        meshcom_settings.node_press = pressure.pressure;
        meshcom_settings.node_temp = temp.temperature;
    }
    else
    {
        meshcom_settings.node_press = 0;
        meshcom_settings.node_temp = 0;
    }
}

/**@brief Function for analytical direction.
 */
void direction_parse(String tmp)
{
    if (tmp.indexOf(",E,") < 0 && tmp.indexOf(",W,") > 0)
    {
        direction_E_W = 0;  // WEST
    }
    else
    {
        direction_E_W = 1;  // EAST
    }
    
    if (tmp.indexOf(",N,") < 0 && tmp.indexOf(",S,") > 0)
    {
        direction_S_N = 1;  // SOUTH
    }
    else
    {
        direction_S_N = 0;  // NORTH
    }
}

/**@brief Function for handling a LoRa tx timer timeout event.
 */
#if defined(ENABLE_RAK_GPS)
// Hilfsfunktion zum Senden
void sendUBXCommand(String cmd)
{
  #if defined(USE_HELTEC_T114) or defined(BOARD_T_ECHO)
  Serial1.println(cmd);
  #else
  Serial1.println(cmd);
  #endif
  delay(100); // Kurze Pause fÄ‚Ä˝r das Modul
}

uint32_t startTimeout;
String ver = "";

void WaitPause() {
  startTimeout = millis() + 1000;
  #if defined(USE_HELTEC_T114) or defined(BOARD_T_ECHO)
  while ((!Serial1.available()) && ((int32_t)(millis() - startTimeout) < 0)) { delay(5); } // auf Block von Zeichen warten
  #else
  while ((!Serial1.available()) && ((int32_t)(millis() - startTimeout) < 0)) { delay(5); } // auf Block von Zeichen warten
  #endif
  if(iGPSDEBUG >= 2)
    Serial.printf("[GPS ]...wait");
  startTimeout = millis() + 50;  // fÄ‚Ä˝r Serial Sync Zeichenblock lesen und Pause von 50ms abwarten
  while ((int32_t)(millis() - startTimeout) < 0) {
    #if defined(USE_HELTEC_T114) or defined(BOARD_T_ECHO)
    if (Serial1.available()) {
      Serial1.read();
    #else
    if (Serial1.available()) {
      Serial1.read();
    #endif
      startTimeout = millis() + 50;  // retrigger timeout
    }
  }
}

const uint8_t UBX_MON_VER_RAK[] = {  // Size 8, swVersion, hwVersion
  0xB5, 0x62,             // Header (sync)
  0x0A, 0x04,             // Class, ID
  0x00, 0x00,             // Length (2 Bytes, Little Endian)
  0x0E, 0x34              // CK_A, CK_B
};

uint8_t ubx_cfg_gnss [] = {// GPS + GALILEO + GLONASS wo / SBAS
0xB5,0x62,0x06,0x3E, 0x3C, 0x00,
0x00,0x00,0x20,0x07,
0x00,0x00,0x10,0x00,0x01,0x00,0x01,0x01,
0x01,0x00,0x00,0x00,0x00,0x00,0x01,0x01,
0x02,0x00,0x08,0x00,0x01,0x00,0x01,0x01,
0x03,0x00,0x00,0x00,0x00,0x00,0x01,0x01,
0x04,0x00,0x00,0x00,0x00,0x00,0x01,0x01,
0x05,0x00,0x00,0x00,0x00,0x00,0x01,0x01,
0x06,0x00,0x10,0x00,0x01,0x00,0x01,0x01,
0xF5,0x8A};

void sendUBX_MON_VER() {  // BinÄ‚Â¤res Paket senden
  
  if(iGPSDEBUG >= 2)
    Serial.println("[GPS ]...Sende UBX_MON_VER");

  for (size_t i = 0; i < sizeof(UBX_MON_VER_RAK); i++)
  {
    Serial1.write(UBX_MON_VER_RAK[i]);
  }

  delay(100); // Kurze Pause fÄ‚Ä˝r das Modul
}

void sendUBX_SET_GNSS() {  // BinÄ‚Â¤res Paket senden
  
  if(iGPSDEBUG >= 2)
    Serial.println("[GPS ]...Sende UBX_SET_GNSS");

  for (size_t i = 0; i < sizeof(ubx_cfg_gnss); i++)
  {
    Serial1.write(ubx_cfg_gnss[i]);
  }

  delay(100); // Kurze Pause fÄ‚Ä˝r das Modul
}

String readUBXbin() {
  startTimeout = millis() + 500;
  ver = "";
    while ((int32_t)(millis() - startTimeout) < 0) {
    #if defined(USE_HELTEC_T114) or defined(BOARD_T_ECHO)
    while (Serial1.available()) {
      int c = Serial1.read();
    #else
    while (Serial1.available()) {
      int c = Serial1.read();
    #endif

      if ((ver.length() > 500) || (c == 0x0D)) { break; }  //TODO: mehr Zeichen fÄ‚Ä˝r ganzen Versions-String
      if (c == 0xB5) { c = 0x75; }
      if ((c < 0x20) || (c > 0x7E)) { c = 0x2E; }
      ver = ver + char(c);
      startTimeout = millis() + 500;  // retrigger timeout
    }
  }
  return ver;
}

void SetupUBLOX()
{
  // 1. Alle Nachrichten (GSV) ausschalten, um Flut an Daten zu reduzieren
  sendUBXCommand("$PUBX,40,GSV,0,0,0,0,0,0*59");
  sendUBXCommand("$PUBX,40,VTG,0,0,0,0,0,0*5E");
  sendUBXCommand("$PUBX,40,GSA,0,0,0,0,0,0*4E");
  sendUBXCommand("$PUBX,40,GLL,0,0,0,0,0,0*5C");
  
  // 2. Nur GGA (Position) und RMC (Zeit/Datum/Speed) aktivieren
  sendUBXCommand("$PUBX,40,GGA,0,1,0,0,0,0*5B");
  sendUBXCommand("$PUBX,40,RMC,0,1,0,0,0,0*47");

  WaitPause(); // Pause zwischen BlÄ‚Â¶cken erreicht

  sendUBX_SET_GNSS();

  sendUBX_MON_VER();
  ver = readUBXbin();
  if(iGPSDEBUG >= 2)
    Serial.printf("[GPS_VER] %s\n", ver.c_str());

}

unsigned int getGPS(void)
{
    if(iGPSDEBUG > 1)
        Serial.println("-----------check GPS-----------");

    bool newData = false;
  
    // For one second we parse GPS data and report some key values
    for (unsigned long start = millis(); millis() - start < 1000;)
    {
      while (Serial1.available())
      {
        char c = Serial1.read();
        
        if(iGPSDEBUG > 2)
            Serial.write(c);

        if (tinyGPSPlus.encode(c))// Did a new valid sentence come in?
          newData = true;
      }
    }

    if(iGPSDEBUG > 1)
        Serial.printf("newData:%i SAT:%d Fix:%d UPD:%d VAL:%d HDOP:%i\n", newData, tinyGPSPlus.satellites.value(), tinyGPSPlus.sentencesWithFix(), tinyGPSPlus.location.isUpdated(), tinyGPSPlus.location.isValid(), tinyGPSPlus.hdop.value());

    posinfo_satcount = tinyGPSPlus.satellites.value();
    fposinfo_hdop = tinyGPSPlus.hdop.value();

    bool has_gnss_location=false;

    if ((tinyGPSPlus.hdop.value() < 300) && (tinyGPSPlus.satellites.value() > 4))
    {
        has_gnss_location = true;
        posinfo_fix = true;
    }
    else
    {
        posinfo_fix = false;
    }
    
    if (newData && has_gnss_location)
    {
        double dlat, dlon;
        
        dlat = tinyGPSPlus.location.lat();
        dlon = tinyGPSPlus.location.lng();

        meshcom_settings.node_lat = cround4(dlat);
        meshcom_settings.node_lon = cround4(dlon);

        if(tinyGPSPlus.location.rawLat().negative)
            meshcom_settings.node_lat_c = 'S';
        else
            meshcom_settings.node_lat_c = 'N';

        if(tinyGPSPlus.location.rawLng().negative)
            meshcom_settings.node_lon_c = 'W';
        else
            meshcom_settings.node_lon_c = 'E';

        meshcom_settings.node_alt = ((meshcom_settings.node_alt * 10) + (int)tinyGPSPlus.altitude.meters()) / 11;

        MyClock.setCurrentTime(meshcom_settings.node_utcoff, tinyGPSPlus.date.year(), tinyGPSPlus.date.month(), tinyGPSPlus.date.day(), tinyGPSPlus.time.hour(), tinyGPSPlus.time.minute(), tinyGPSPlus.time.second());
        snprintf(cTimeSource, sizeof(cTimeSource), (char*)"GPS");

        if(iGPSDEBUG > 1)
        {
            Serial.printf("INT: LAT:%lf%c LON:%lf%c ALT:%i (%i-%02i-%02i %02i:%02i:%02i)\n", meshcom_settings.node_lat, meshcom_settings.node_lat_c, meshcom_settings.node_lon, meshcom_settings.node_lon_c, meshcom_settings.node_alt,
            meshcom_settings.node_date_year, meshcom_settings.node_date_month,  meshcom_settings.node_date_day,
            meshcom_settings.node_date_hour, meshcom_settings.node_date_minute, meshcom_settings.node_date_second );
        }

        return setSMartBeaconing(dlat, dlon);
    }

    return POSINFO_INTERVAL;   // no GPS
}
#endif


// C2/U2 carve: sendUDP() lives in nrf52/udp_drain_nrf52.cpp

/**@brief Function to send our heartbeat
 * longanme0x000xAABBCCDDKEEPGW0110x00
 *               GW_ID
 */
void sendHeartbeat()
{
    if (!neth.hasIPaddress)
        return;

    sendKEEP();
    storTick();   // SNF-GW W3 (no-op unless --stor on and gateway)

}