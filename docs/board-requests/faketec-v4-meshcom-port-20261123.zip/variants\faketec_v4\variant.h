#pragma once

#ifndef _VARIANT_FAKETEC_V4_
#define _VARIANT_FAKETEC_V4_

#define FAKETEC_V4

#define VARIANT_MCK (64000000ul)

#define USE_LFRC

#include <Arduino.h>

#ifdef __cplusplus
extern "C"
{
#endif

static const uint8_t WB_IO1 = 24;
static const uint8_t WB_IO2 = 24;
static const uint8_t WB_IO3 = 0xFF;
static const uint8_t WB_IO4 = 0xFF;
static const uint8_t WB_IO5 = 0xFF;
static const uint8_t WB_IO6 = 32;
static const uint8_t WB_A0  = 31; // P0.31 (Pomiar baterii Faketec)
static const uint8_t WB_A1  = 31;

#define PINS_COUNT (48)
#define NUM_DIGITAL_PINS (48)
#define NUM_ANALOG_INPUTS (8)
#define NUM_ANALOG_OUTPUTS (0)

#define PIN_LED1 (15)
#define PIN_LED2 (0xFF)

#define LED_BUILTIN PIN_LED1
#define LED_CONN    PIN_LED1
#define LED_GREEN   PIN_LED1
#define LED_BLUE    PIN_LED1
#define BOARD_LED   PIN_LED1

#define LED_STATE_ON 0

#define PIN_A0 (31)
#define PIN_VBAT (31)
static const uint8_t A0 = PIN_A0;
#define ADC_RESOLUTION 14

#define PIN_NFC1 (9)
#define PIN_NFC2 (10)

#define PIN_SERIAL1_RX (20)
#define PIN_SERIAL1_TX (22)

#define SPI_INTERFACES_COUNT 1
#define PIN_SPI_MISO (2)
#define PIN_SPI_MOSI (47)
#define PIN_SPI_SCK  (43)

static const uint8_t SS   = 45;
static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t SCK  = PIN_SPI_SCK;

#define WIRE_INTERFACES_COUNT 1
#define PIN_WIRE_SDA (36)
#define PIN_WIRE_SCL (11)

#define BUTTON_PIN (32)

#ifdef __cplusplus
}
#endif

#endif