/**
 * @file ble.cpp
 * @author Bernd Giesecke (bernd.giesecke@rakwireless.com)
 * @brief BLE initialization & device configuration
 * @version 0.1
 * @date 2021-01-10
 *
 * @copyright Copyright (c) 2021
 *
 */
#ifdef NRF52_SERIES

#include "WisBlock-API.h"
#include "ble_settings_v1.h"
#include "ble_settings_stage.h"
#include <loop_functions.h>
#include <loop_functions_extern.h>
#include <phone_commands.h>
#include "ble_phone_drain.h"   // BLE-N1/N2: BlePhoneSend, g_blePhoneStats
#include "ble_session.h"       // BLC-02: BleStats, bleStatsOn*, bleReasonText
#include <debugconf.h>
#include <configuration.h>
#include <command_functions.h>
#include <prod_lock.h>      // prodLockNormalise(): the blob is copied unchecked
#include <maxhop.h>        // maxHopTextSanitize()
#include <settings_sanitize.h>   // sanitize_ping_target()
#include <instrument.h>     // INSTRUMENT_ENABLED

extern int isPhoneReady;
extern bool bAckInfo;
extern bool ble_busy_flag;
extern uint16_t swap2bytes(uint16_t value);
extern void commandAction(char *msg_text, int len, bool ble);
extern bool hasMsgFromPhone;
extern char textbuff_phone [MAX_MSG_LEN_PHONE];
extern uint8_t txt_msg_len_phone;
// `extern bool bInitDisplay;` stand hier und band an NICHTS: den Namen gibt
// es nirgendwo sonst im Baum, weder als Definition noch als zweite
// Verwendung. Uebersetzt und linkt nur, weil ihn niemand liest -- ein
// Symbol, das aussieht, als gaebe es irgendwo einen Display-Init-Zustand.
// Gefunden 2026-09-16, als carve_extern_lint.py auf diese Datei erweitert
// wurde.
extern uint8_t dmac[6];
extern bool config_to_phone_prepare;
extern bool conffin_sent;

// FreeRTOS queue holding raw BLE payloads handed from the BLE stack's
// RX callback (adafruit_ble_task context) to the Main Loop task, which
// drains it in nrf52loop() (src/nrf52/nrf52_main.cpp). readPhoneCommand()/
// commandAction()/save_settings() must not run inline in the BLE callback
// concurrently with the Main Loop; this mirrors the ESP32 bleQueue design
// (CONC-14). Non-static: nrf52_main.cpp references it via extern.
struct BleQueueItem {
	uint8_t data[MAX_MSG_LEN_PHONE];
	size_t length;
};

QueueHandle_t bleQueue = NULL;

// Create device name
char helper_string[256] = {0};

/** OTA DFU service */
BLEDfu ble_dfu;
/** BLE UART service */
BLEUart g_ble_uart;
/** Device information service */
BLEDis ble_dis;

/** LoRa service 0xF0A0 */
BLEService lora_service = BLEService(0xF0A0);
/** LoRa settings  characteristic 0xF0A1 */
BLECharacteristic g_lora_data = BLECharacteristic(0xF0A1);

// Settings callback
void settings_rx_callback(uint16_t conn_hdl, BLECharacteristic *chr, uint8_t *data, uint16_t len);

// Connect callback
void connect_callback(uint16_t conn_handle);
// Disconnect callback
void disconnect_callback(uint16_t conn_handle, uint8_t reason);
// Uart RX callback
void bleuart_rx_callback(uint16_t conn_handle);

/** Flag if BLE UART is connected */
bool g_ble_uart_is_connected = false;

/** BLC-02: connect/disconnect/advertising counters (src/ble_session.h) */
BleStats g_bleStats;

// BLC-02: disconnect_callback() runs in the Bluefruit callback task, where
// Serial.printf (malloc above 64 B) and logging are unsafe. It only records
// the HCI reason here; nrf52BleTick() prints it from the Main Loop task. Two
// disconnects before one tick: the later reason wins, the counters count both.
static volatile uint8_t s_discReason = 0;
static volatile bool s_discPending = false;

/**
 * @brief Initialize BLE and start advertising
 *
 */
void init_ble(void)
{
	// Create the BLE RX queue before starting BLE so the RX callback can
	// enqueue into it as soon as connections are possible (CONC-14).
	bleQueue = xQueueCreate(5, sizeof(BleQueueItem));

	// Config the peripheral connection with maximum bandwidth
	// more SRAM required by SoftDevice
	// Note: All config***() function must be called before begin()
	Bluefruit.configPrphBandwidth(BANDWIDTH_MAX);
#ifdef ISP4520
	Bluefruit.configPrphConn(250, BLE_GAP_EVENT_LENGTH_MIN, 16, 16);
#else
	Bluefruit.configPrphConn(250, BLE_GAP_EVENT_LENGTH_MIN, 16, 16);
#endif
	// Start BLE
	Bluefruit.begin(1, 0);
	// BLE Pin 
	Bluefruit.Security.setPIN(PAIRING_PIN);

	// Set max power. Accepted values are: (min) -40, -20, -16, -12, -8, -4, 0, 2, 3, 4, 5, 6, 7, 8 (max)
	// RAK4631 - nRF52840 max 4dBm
	Bluefruit.setTxPower(0);

#if NO_BLE_LED > 0
	Bluefruit.autoConnLed(false);
	digitalWrite(LED_BLUE, !LED_STATE_ON);
#endif

#ifdef _VARIANT_ISP4520_
	/** Device name for ISP4520 */
	snprintf(helper_string, sizeof(helper_string), "%s-%02X%02X%02X%02X%02X%02X", g_ble_dev_name,
			(uint8_t)(meshcom_settings.node_device_eui[2]), (uint8_t)(meshcom_settings.node_device_eui[3]),
			(uint8_t)(meshcom_settings.node_device_eui[4]), (uint8_t)(meshcom_settings.node_device_eui[5]), (uint8_t)(meshcom_settings.node_device_eui[6]), (uint8_t)(meshcom_settings.node_device_eui[7]));
#else
	/** Device name for RAK4631 */
	snprintf(helper_string, sizeof(helper_string), "%s-%02x%02x-%s", g_ble_dev_name, dmac[1], dmac[0], meshcom_settings.node_call);	// Anzeige mit callsign

	Serial.print("[INIT]...init helper_string:");
	Serial.println(helper_string);

#endif

	Bluefruit.setName(helper_string);

	// Set connection/disconnect callbacks
	Bluefruit.Periph.setConnectCallback(connect_callback);
	Bluefruit.Periph.setDisconnectCallback(disconnect_callback);

	// Configure and Start Device Information Service
#ifdef _VARIANT_ISP4520_
	ble_dis.setManufacturer("Insight_SIP");

	ble_dis.setModel("ISP4520");
#else
	ble_dis.setManufacturer("RAKwireless");

	ble_dis.setModel("RAK4631 FakeTec");
#endif

	snprintf(helper_string, sizeof(helper_string), "%d.%d.%d", g_sw_ver_1, g_sw_ver_2, g_sw_ver_3);
	ble_dis.setSoftwareRev(helper_string);

	ble_dis.setHardwareRev("52840");

	// Start the DFU service first - needed for the OTA update
	ble_dfu.begin();

	ble_dis.begin();

	// Permission / Pairing
	// KBC 28.04.2025 g_ble_uart.setPermission(SECMODE_ENC_WITH_MITM, SECMODE_ENC_WITH_MITM);
	// Start the UART service
	g_ble_uart.begin();
	g_ble_uart.setRxCallback(bleuart_rx_callback);

	// Initialize the LoRa setting service
	BLEService sett_service = init_settings_characteristic();

	// Secondary Scan Response packet (optional)
  	// Since there is no room for 'Name' in Advertising packet
	Bluefruit.ScanResponse.addName();

	// Advertising packet
	Bluefruit.Advertising.addFlags(BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE); //
	Bluefruit.Advertising.addService(sett_service);
	Bluefruit.Advertising.addName();
	Bluefruit.Advertising.addTxPower();

	/* Start Advertising
	 * - Enable auto advertising if disconnected
	 * - Interval:  fast mode = 20 ms, slow mode = 152.5 ms
	 * - Timeout for fast mode is 30 seconds
	 * - Start(timeout) with timeout = 0 will advertise forever (until connected)
	 *
	 * For recommended advertising interval
	 * https://developer.apple.com/library/content/qa/qa1931/_index.html
	 */
	Bluefruit.Advertising.restartOnDisconnect(true);
	Bluefruit.Advertising.setInterval(32, 244); // in unit of 0.625 ms
	Bluefruit.Advertising.setFastTimeout(15);	// number of seconds in fast mode
	// Bluefruit.Advertising.start(60);			// 0 = Don't stop advertising
	{
		restart_advertising(0);
	}
}

/**
 * @brief Restart advertising for a certain time
 *
 * @param timeout timeout in seconds
 */
void restart_advertising(uint16_t timeout)
{
	Bluefruit.Advertising.start(timeout);
}

/**
 * @brief Stop advertising for a certain time
 *
 * @param timeout timeout in seconds
 */
void stop_advertising()
{
	Bluefruit.Advertising.stop();

	// disconnect
	g_ble_uart_is_connected = false;
	isPhoneReady = 0;
	bAckInfo = false;
	Bluefruit.setTxPower(0);
	DEBUG_MSG("BLE", "Disconnected");
}

/**
 * @brief  Callback when client connects
 * @param  conn_handle: Connection handle id
 */
void connect_callback(uint16_t conn_handle)
{
	// BLE-N2: the MTU right after connect is the default (23) -- the phone
	// negotiates it later. nrf52_ble_mtu() reads the live value on every send
	// and the drain keeps g_blePhoneStats.last_mtu current; this is the start
	// value of the connection.
	{
		BLEConnection *conn = Bluefruit.Connection(conn_handle);
		g_blePhoneStats.last_mtu = conn ? conn->getMtu() : 0;
	}
	bleStatsOnConnect(g_bleStats);
	Bluefruit.setTxPower(4);
	DEBUG_MSG("BLE", "Connected");

	// BLE link established â€” app auth not yet done.
	// isPhoneReady and config_to_phone_prepare are set only after
	// successful app-layer PIN authentication via the hello message.
	isPhoneReady = 0;
	bAckInfo = false;
	config_to_phone_prepare = false;
	conffin_sent = false;
	ble_disconnect_requested = false;	// BLC-01: a wrong-PIN request of the previous central
	g_ble_uart_is_connected = true;

}

/**
 * @brief  Callback invoked when a connection is dropped
 * @param  conn_handle: connection handle id
 * @param  reason: disconnect reason
 */
void disconnect_callback(uint16_t conn_handle, uint8_t reason)
{
	(void)conn_handle;
	bleStatsOnDisconnect(g_bleStats, (int)reason);
	s_discReason = reason;
	s_discPending = true;	// printed by nrf52BleTick() in the Main Loop task
	g_ble_uart_is_connected = false;
	isPhoneReady = 0;
	bAckInfo = false;
	config_to_phone_prepare = false;
	conffin_sent = false;
	ble_disconnect_requested = false;
	Bluefruit.setTxPower(0);
	DEBUG_MSG("BLE", "Disconnected");
}

/**
 * @brief BLC-02: Main Loop housekeeping for the BLE link, called every pass
 * from nrf52loop() (src/nrf52/nrf52_main.cpp).
 *
 * 1. Prints the disconnect reason that disconnect_callback() recorded.
 * 2. Advertising self-check: every 5 s while no central is connected, if the
 *    stack is not advertising (restartOnDisconnect() missed it, or a failed
 *    connect left it stopped), start it again and count it.
 * 3. With --bledebug on, a [BLE ];stat line every 15 min.
 * Lines are built in a stack buffer and printed with Serial.print: no
 * Print::printf malloc next to the BLE stack.
 */
void nrf52BleTick(void)
{
	static uint32_t lastAdvCheck = 0;
	static uint32_t lastStat = 0;
	static bool started = false;
	const uint32_t now = millis();

	if(!started)
	{
		started = true;
		lastAdvCheck = now;
		lastStat = now;
	}

	if(s_discPending)
	{
		const uint8_t reason = s_discReason;
		s_discPending = false;
		if(bBLEDEBUG)
		{
			char line[64];
			snprintf(line, sizeof(line), "[BLE ];disconnect;reason;0x%02x;text;%s", (unsigned)reason, bleReasonText((int)reason));
			Serial.println(line);
		}
	}

	if((uint32_t)(now - lastAdvCheck) >= 5000UL)
	{
		lastAdvCheck = now;
		if(!g_ble_uart_is_connected && Bluefruit.connected() == 0 && !Bluefruit.Advertising.isRunning())
		{
			Bluefruit.Advertising.start(0);
			bleStatsOnAdvRestart(g_bleStats);
			if(bBLEDEBUG)
				Serial.println("[BLE ];adv_restart");
		}
	}

	if(bBLEDEBUG && (uint32_t)(now - lastStat) >= 900000UL)
	{
		lastStat = now;
		char buf[128];
		bleStatsFormat(g_bleStats, buf, sizeof(buf));
		Serial.print("[BLE ];stat;");
		Serial.println(buf);
	}
}

/**
 * @brief BLE TX sink for the phone drain (src/ble_phone_drain.h): one notify.
 *
 * BLE-N1: what BLEUart::write() returns (Bluefruit52Lib BLEUart.cpp, with
 * bufferTXD() off -- this firmware never enables it -- write() is
 * `_txd.notify(conn, content, len) ? len : 0`):
 *   - 0 when notifications are not enabled (CCCD off)  -> checked first: DOWN
 *   - len when BLECharacteristic::notify() got every chunk to the SoftDevice
 *   - 0 when notify() failed: no free HVN packet (conn->getHvnPacket(), the
 *     SoftDevice TX queue is full) or sd_ble_gatts_hvx() refused -> BUSY
 * So 0 with notifications on means "queue full, try again" and the drain keeps
 * the frame.
 *
 * Known limit: notify() splits a payload longer than MTU-3 into several
 * notifies. If the FIRST chunk was queued and a later one is refused, the
 * frame is reported BUSY although part of it went out, and the retry sends
 * the head chunk again. Only frames longer than MTU-3 (the ones counted as
 * "truncated") can hit this.
 */
BlePhoneSend nrf52_write_ble(const uint8_t *buf, uint16_t len)
{
	if(!g_ble_uart_is_connected || !g_ble_uart.notifyEnabled())
		return BLE_SEND_DOWN;

	return (g_ble_uart.write(buf, (size_t)len) == (size_t)len) ? BLE_SEND_SENT : BLE_SEND_BUSY;
}

/**
 * @brief BLE-N2: the live ATT MTU of the current connection, 0 if none.
 */
uint16_t nrf52_ble_mtu()
{
	if(!g_ble_uart_is_connected)
		return 0;

	BLEConnection *conn = Bluefruit.Connection(Bluefruit.connHandle());
	return conn ? conn->getMtu() : 0;
}

/**
 * Callback if data has been sent from the connected client
 * @param conn_handle
 * 		The connection handle
 */
void bleuart_rx_callback(uint16_t conn_handle)
{
	(void)conn_handle;

	g_task_event_type |= BLE_DATA;
	xSemaphoreGiveFromISR(g_task_sem, pdFALSE);

	// Forward data from Mobile to our peripheral: enqueue for processing
	// in the Main Loop task instead of calling readPhoneCommand() here,
	// inline in the BLE stack's callback context (CONC-14).
	BleQueueItem item = {};
	item.length = g_ble_uart.read(item.data, MAX_MSG_LEN_PHONE);
	xQueueSend(bleQueue, &item, 0);  // non-blocking, drop on full queue

	// Disconnect if app-layer auth failed
	if(ble_disconnect_requested)
	{
		ble_disconnect_requested = false;
		Bluefruit.disconnect(conn_handle);
	}

}

/**
 * @brief Act on an app-layer auth failure (wrong or missing PIN hash).
 *
 * readPhoneCommand() sets ble_disconnect_requested, but since CONC-14 it runs
 * in the Main Loop from bleQueue -- after bleuart_rx_callback() has already
 * returned. The check there therefore only fired on the phone's NEXT write: a
 * phone that sent a wrong PIN hash and then waited stayed connected (no burst,
 * but an open link). The Main Loop calls this right after draining bleQueue.
 */
void nrf52BleServiceDisconnect(void)
{
	if(ble_disconnect_requested)
	{
		ble_disconnect_requested = false;
		Bluefruit.disconnect(Bluefruit.connHandle());
	}
}

// CONC-17: settings_rx_callback() runs in the Bluefruit Ada callback task,
// which can be preempted mid-write by a higher-priority task or, on a tick
// wake-up, an equal-priority one â€” a torn image could put a beacon on the air
// with a spliced callsign or frequency once applied.
// The callback stages the wire bytes with the seqlock writer in
// ble_settings_stage.h (counter odd, memcpy, counter even) and wakes the loop
// task. applyPendingBleSettings(), called once per Main Loop iteration,
// converts the staged image straight onto meshcom_settings inside a short
// critical section. No snapshot and no converted copy are needed: inside the
// section the callback task cannot run, and an odd counter (a write paused
// mid-copy) makes the apply back off and retry. Converting in place also
// keeps node_msgid, which bleSettingsFromV1() deliberately never writes; a
// whole-struct copy from a scratch struct would reset it and replay message
// ids into the neighbours' dedup rings.
static BleSettingsV1Stage s_bleSettingsStage;
static uint32_t s_appliedBleSettingsSeq = 0;

/**
 * @brief Initialize the settings characteristic
 *
 */
BLEService init_settings_characteristic(void)
{
	// Initialize the LoRa setting service
	lora_service.begin();
	g_lora_data.setProperties(CHR_PROPS_NOTIFY | CHR_PROPS_READ | CHR_PROPS_WRITE);
	g_lora_data.setPermission(SECMODE_OPEN, SECMODE_OPEN);
	g_lora_data.setFixedLen(sizeof(s_ble_settings_v1) + 1);
	g_lora_data.setWriteCallback(settings_rx_callback);

	g_lora_data.begin();

	// The characteristic ships the frozen v1 wire image, never
	// s_meshcom_settings directly (see ble_settings_v1.h). write() copies
	// synchronously, so the shared scratch is free again when it returns.
	s_ble_settings_v1 &outImage = bleSettingsV1Scratch();
	bleSettingsToV1(meshcom_settings, outImage);
	g_lora_data.write((void *)&outImage, sizeof(outImage));

	return lora_service;
}

/**
 * Callback if data has been sent from the connected client
 * @param conn_hdl
 * 		The connection handle
 * @param chr
 *      The called characteristic
 * @param data
 *      Pointer to received data
 * @param len
 *      Length of the received data
 */
void settings_rx_callback(uint16_t conn_hdl, BLECharacteristic *chr, uint8_t *data, uint16_t len)
{
	(void)conn_hdl;
	API_LOG("SETT", "Settings received");

	delay(1000);

	// Check the characteristic
	if (chr->uuid == g_lora_data.uuid)
	{
		if (!bleSettingsV1LengthOk(len))
		{
			API_LOG("SETT", "Received settings have wrong size %d", len);
			return;
		}

		const s_ble_settings_v1 *rcvdSettings = (const s_ble_settings_v1 *)data;
		if (!bleSettingsV1MarkersOk(*rcvdSettings))
		{
			API_LOG("SETT", "Received settings data do not have required markers");
			return;
		}

		// CONC-17: stage only, apply from the Main Loop (see the comment
		// above s_bleSettingsStage).
		stageBleSettingsV1(s_bleSettingsStage, *rcvdSettings);

		// Notify task about the event
		if (g_task_sem != NULL)
		{
			g_task_event_type |= BLE_CONFIG;
			API_LOG("SETT", "Waking up loop task");
			xSemaphoreGive(g_task_sem);
		}
	}
}

static void bleSanitizeLog(const char *field, const char *oldv, const char *newv)
{
	Serial.printf("[FLASH]...sanitized %s: %s -> %s\n", field, oldv, newv);
}

/**
 * @brief Apply a settings write staged by settings_rx_callback(), if any.
 * Must be called from the Main Loop task only (CONC-17).
 */
void applyPendingBleSettings(void)
{
	BleSettingsV1ApplyResult result;
	int tries = 0;
	for (;;)
	{
		// The critical section keeps the callback task out while the staged
		// image is read and converted (see the comment above s_bleSettingsStage).
		taskENTER_CRITICAL();
		result = tryApplyBleSettingsV1Stage(s_bleSettingsStage, &s_appliedBleSettingsSeq, meshcom_settings);
		taskEXIT_CRITICAL();

		if (result != BleSettingsV1ApplyResult::Busy)
			break;

		// Busy: a write was paused mid-copy. Yield so the callback task can
		// finish; bounded, and the next Main Loop iteration retries anyway
		// because the staged sequence still differs from the applied one.
		if (++tries >= 20)
			return;
		delay(1);
	}

	if (result != BleSettingsV1ApplyResult::Applied)
		return; // None: nothing staged since the last apply

	// The blob copies every field unchecked: bring the locked settings (production) and the
	// ranges back before anything is saved or reported to the app.
	meshcom_settings.max_hop_text = maxHopTextSanitize(meshcom_settings.max_hop_text);
	// The blob also carries node_pingcall unchecked; before prodLockNormalise(),
	// which derives node_pingtime from node_pingcall[0]
	sanitize_ping_target(meshcom_settings.node_pingcall, sizeof(meshcom_settings.node_pingcall), meshcom_settings.node_call, bleSanitizeLog);
	prodLockNormalise(meshcom_settings, INSTRUMENT_ENABLED != 0, false);

	// Save new settings
	save_settings();

	// Update settings. write() and notify() both copy before returning
	// (notify() per MTU chunk), so the shared scratch is free afterwards.
	s_ble_settings_v1 &outImage = bleSettingsV1Scratch();
	bleSettingsToV1(meshcom_settings, outImage);
	g_lora_data.write((void *)&outImage, sizeof(outImage));

	// Inform connected device about new settings
	g_lora_data.notify((void *)&outImage, sizeof(outImage));

	/*KBC
	if (meshcom_settings.resetRequest)
	{
		API_LOG("SETT", "Initiate reset");
		delay(1000);
		sd_nvic_SystemReset();
	}
	*/
}

#endif
