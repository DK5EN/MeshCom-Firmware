#include "variant.h"
#include "wiring_constants.h"
#include "wiring_digital.h"
#include "nrf.h"

#ifdef __cplusplus
extern "C"
{
#endif

const uint32_t g_ADigitalPinMap[] =
{
    0,  1,  2,  3,  4,  5,  6,  7,
    8,  9,  10, 11, 12, 13, 14, 15,
    16, 17, 18, 19, 20, 21, 22, 23,
    24, 25, 26, 27, 28, 29, 30, 31,

    32, 33, 34, 35, 36, 37, 38, 39,
    40, 41, 42, 43, 44, 45, 46, 47
};

void initVariant()
{
    // KRYTYCZNE DLA PRO MICRO: Przeczenie pinów P0.09 i P0.10 z trybu NFC na GPIO
    if ((NRF_UICR->NFCPINS & 1) == 1)
    {
        NRF_NVMC->CONFIG = NVMC_CONFIG_WEN_Wen << NVMC_CONFIG_WEN_Pos;
        while (NRF_NVMC->READY == NVMC_READY_READY_Busy);
        NRF_UICR->NFCPINS = 0; // 0 = P0.09 i P0.10 dziaaj jako normalne GPIO
        while (NRF_NVMC->READY == NVMC_READY_READY_Busy);
        NRF_NVMC->CONFIG = NVMC_CONFIG_WEN_Ren << NVMC_CONFIG_WEN_Pos;
        while (NRF_NVMC->READY == NVMC_READY_READY_Busy);
        NVIC_SystemReset(); // Jednorazowy restart sprztowy w celu zaaplikowania zmian
    }

    // Zaczenie przetwornicy zasilajcej 3.3V (VCC / LoRa / I2C) przez P0.13
    pinMode(13, OUTPUT);
    digitalWrite(13, HIGH);
    delay(100);

    // Zaczenie zasilania GPS (P0.24)
    pinMode(24, OUTPUT);
    digitalWrite(24, HIGH);

    // Dioda LED na Nice!Nano (P0.15)
    pinMode(PIN_LED1, OUTPUT);
    digitalWrite(PIN_LED1, !LED_STATE_ON);
}

#ifdef __cplusplus
}
#endif