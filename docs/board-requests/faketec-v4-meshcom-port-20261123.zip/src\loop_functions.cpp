#include "mc_text.h"
#include "uptime_min.h"   // wrap-safe 16-bit uptime minutes (NBR stamps)
#include "Arduino.h"

#include <atomic>

#if defined(ESP32)
#include <WiFi.h>
#endif

#include "loop_functions.h"
#include "gfx_charmap.h"   // national characters on the GFXfont displays (E290, WP, E213)
#include "text_fold.h"     // CHARS-01: fold what the display font lacks
#include "ack_attribution.h"
#include "txring_functions.h"
#include "bp_notice_frame.h"
#include "dedup_functions.h"
#include "beacon_rate.h"
#include "hey_policy.h"     // F6: gateway keeps its HG alive through trickle suppression
#include "nbr_views.h"
#include "command_functions.h"
#include "ble_phone_drain.h"   // BLE-N1/N2: blePhonePush(), g_blePhoneStats

#include "clock.h"

#include "batt_functions.h"
#include "udp_functions.h"
#include "extudp_functions.h"
#include "kiss_functions.h"
#include "configuration.h"
#include "loop_functions_extern.h"   // REMOTE_LED_PIN rule + RM LED levels
#include "board_led.h"
#if defined(ESP32)
#include "esp32/esp32_pmu.h"   // chargeLedFitted()
#endif

#include "TinyGPSPlus.h"

#include "printfdeb_functions.h"

#include "via_functions.h"
#include "charset_filter.h"
#include "msgid_counter.h"
#include <counters_store.h>
#include "setlog_lines.h"
#include "dm_stats.h"
#if defined(ENABLE_MSGSTORE)
#include "msgstore_api.h"    // S3: store node (last-hop mailbox)
#endif
#include "mcp17_bits.h"
#include "pos_tag_nan.h"
#include "prod_lock.h"   // production lock: {SET} hop range
#include "instrument.h"   // INSTRUMENT_ENABLED
#include "rm_client_cmd.h"   // client RM1 commands: reply stops their repeats
#include "lora_functions.h"   // rm1StoppedForget()
#include "dm_text_escape.h"   // P14/P15: {ping}/{SET}-Ausnahme vom Klammer-Escape
#include "nbr_matrix.h"   // nbrMatrix, nbrBuildReport(), nbrLog -- sendNbrReport() unten
#include "ping_target.h"   // One ping-target rule
#include "own_msg_status.h"   // durable delivery state of own text messages (web GUI ticks)

bool gpsDetected = false;
bool gpsInitDone = false;

#include <Wire.h> 

#if defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS)
#include <lvgl.h>
#include <t-deck/tdeck_main.h>
#include <t-deck/lv_obj_functions.h>
#endif 

#if defined(BOARD_T_DECK_PRO)
#include <t-deck-pro/tdeck_pro.h>
#endif

#if defined(BOARD_T5_EPAPER)
#include <t5-epaper/t5epaper_extern.h>
#include <t5-epaper/t5epaper_main.h>
#endif

#if defined(HAS_TFT) || defined(HAS_TFT_114)
#include "tft_display_functions.h"
#endif

// CHARS-01: UTF-8 text -> what the display font can draw (text_fold). Folding can grow
// ("deg" for a 2-byte degree sign), the buffer has room; text_fold truncates cleanly.
static inline String foldForDisplay(const char *utf8, TextFoldTarget t)
{
#if defined(NRF52_SERIES)
    static char buf[MC_PAYLOAD_LEN + 48];   // N-22: 4-KB loop stack; display text runs in one task only
#else
    char buf[MC_PAYLOAD_LEN + 48];
#endif
    text_fold(utf8, strnlen(utf8, MC_PAYLOAD_LEN), buf, sizeof(buf), t);
    return String(buf);
}

#if defined(HAS_TFT_CONNECT)
#include "tft_display_functions.h"
#include "pin_config.h"
#endif
// TinyGPS
// gps (TinyGPSPlus) wird in gps_functions.cpp unbedingt instanziiert und hier nur fuer
// reine Distanz-/Kursberechnungen (distanceBetween/courseTo) genutzt - kein GPS-Modul noetig.
// Daher auch fuer Wireless Paper (ohne ENABLE_GPS) sichtbar machen.
#if defined(ENABLE_GPS) || defined(ENABLE_RAK_GPS) || defined(WP_DISP)
extern TinyGPSPlus gps;
#endif


bool bnextread=false;

int ifalseping = 0;

int BOARD_HARDWARE = MODUL_HARDWARE;
bool bUSER_BOARD_LED = false;

// LED-08/09/10 (design 6.1): which LEDs exist on this build/node, the one source for --info, BLE SN/SN1 and the web
// GUI. Board LED = BOARD_LED pin or a NeoPixel-only heartbeat (LED_PIN with pixels, no BOARD_LED); charge LED =
// AXP compiled in AND a PMU answered (chargeLedFitted(): false without AXP). ledFitted() of board_led.h decides.
LedFitted ledFittedNow(void)
{
#if defined(BOARD_LED)
    const bool boardPin = true;
#else
    const bool boardPin = false;
#endif
#if defined(LED_PIN) && defined(LED_PIXEL) && (LED_PIXEL > 0) && !defined(BOARD_LED)
    const bool neo = true;
#else
    const bool neo = false;
#endif
#if defined(ESP32)
    return ledFitted(boardPin, neo, true, chargeLedFitted());
#else
    return ledFitted(boardPin, neo, false, false);   // nRF52: no PMU charge LED
#endif
}

#if defined(REMOTE_LED_PIN)
bool bRemoteLed = false;        // RM "led on|flash": never persisted, off after boot
bool bRemoteLedFlash = false;

bool remoteLedPinUsable(void)
{
#if defined(BOARD_LED) && (REMOTE_LED_PIN == BOARD_LED)
    return boardLedPinUsable();   // the board LED pad: OneWire may own it (T-Beam GPIO4)
#else
    return true;                  // own pad (Heltec V3/V4 GPIO35)
#endif
}

void remoteLedSet(int mode)
{
    bRemoteLed = (mode == 1 || mode == 2);
    bRemoteLedFlash = (mode == 2);
    if (!remoteLedPinUsable())   // pad shared with OneWire (T-Beam GPIO4): never drive it
    {
        bRemoteLed = false;
        bRemoteLedFlash = false;
        return;
    }
    pinMode(REMOTE_LED_PIN, OUTPUT);
    digitalWrite(REMOTE_LED_PIN, mode == 1 ? REMOTE_LED_ON_LEVEL : REMOTE_LED_OFF_LEVEL);
}

void remoteLedTick(void)
{
    if (!remoteLedPinUsable())   // OneWire took the pad (steady hold or flashing): release without writing the pin
    {
        bRemoteLed = false;
        bRemoteLedFlash = false;
        return;
    }
    if (!bRemoteLedFlash)
        return;
    const bool lit = (millis() % REMOTE_LED_FLASH_PERIOD_MS) < REMOTE_LED_FLASH_ON_MS;
    digitalWrite(REMOTE_LED_PIN, lit ? REMOTE_LED_ON_LEVEL : REMOTE_LED_OFF_LEVEL);
}

void remoteLedForceOff(void)
{
    remoteLedSet(0);
}
#endif

// Board LED heartbeat ("--board led on": 30 ms every 2 s), W1 helpers. The decision logic is in board_led.h
// (native test); this is the pin side. BOARD_LED = plain GPIO LED; LED_PIN without BOARD_LED = NeoPixel only
// (S3 DevKitC): the pulse goes through the status-colour path of esp32_main.cpp (bLED_WEISS). Boards with
// nRF52 (RAK4631, T114, T-Echo) use the same code through BOARD_LED / LED_STATE_ON (LED-07).
#if defined(BOARD_LED) || defined(LED_PIN)
    #ifndef BOARD_LED_ACTIVE_LOW
        #define BOARD_LED_ACTIVE_LOW 0
    #endif
    #if defined(BOARD_LED)
        #define BOARD_LED_DRIVE_PIN BOARD_LED
    #else
        #define BOARD_LED_DRIVE_PIN LED_PIN
        #include <Adafruit_NeoPixel.h>
        extern Adafruit_NeoPixel pixels;   // esp32_main.cpp
    #endif
    #if defined(LED_PIN)
        // NeoPixel status path of esp32_main.cpp. No variant defines both BOARD_LED and LED_PIN after W4;
        // the branch is kept for a board that does, which then pulses the pixel white with every flash
        extern bool bLED_WEISS;
        extern unsigned long pixels_delay;
    #endif
    #if defined(BOARD_TBEAM)
        #define BOARD_LED_OW_TBEAM_REMAP true    // onewire_functions.cpp: stored 16 -> 0 -> OneWire_GPIO
    #else
        #define BOARD_LED_OW_TBEAM_REMAP false
    #endif
    #if defined(OneWire_GPIO)
        #define BOARD_LED_OW_COMPILE (OneWire_GPIO)
    #else
        #define BOARD_LED_OW_COMPILE (-1)
    #endif

static bool boardLedLit = false;       // logical flasher state (starts dark, LED-11)
static uint32_t boardLedTimer = 0;

bool boardLedPinUsable(void)
{
    return boardLedPinFree(bONEWIRE, boardLedOwPin(meshcom_settings.node_owgpio, BOARD_LED_OW_COMPILE, BOARD_LED_OW_TBEAM_REMAP),
                           BOARD_LED_DRIVE_PIN);
}

#if defined(LED_PIN)
// Same guards as the inline flasher in esp32_main.cpp: no status colour running or pending
static void boardLedWhitePulse(void)
{
    if (pixels_delay == 0 && !bLED_CLEAR)
    {
        if (!bLED_RED && !bLED_GREEN && !bLED_ORANGE && !bLED_BLUE)
            bLED_WEISS = true;   // lit edge only; the NeoPixel handler shows it and clears it again
    }
}
#endif

#if defined(BOARD_LED)
static bool boardLedOutput = false;   // pinMode(OUTPUT) done since the pad was last given up
#endif

static void boardLedWrite(bool lit)
{
    #if defined(BOARD_LED)
        #if defined(LED_PIN)
        if (lit)
            boardLedWhitePulse();
        #endif
        // RM "led on|flash" holds the same pad: the flasher only keeps its phase
        #if defined(REMOTE_LED_PIN) && (REMOTE_LED_PIN == BOARD_LED)
        if (bRemoteLed)
            return;
        #endif
        if (!boardLedOutput)   // pad may come back from OneWire at run time
        {
            pinMode(BOARD_LED, OUTPUT);
            boardLedOutput = true;
        }
        digitalWrite(BOARD_LED, boardLedLevel(lit, BOARD_LED_ACTIVE_LOW));
    #else
        if (lit)
            boardLedWhitePulse();
    #endif
}

void boardLedTick(void)
{
    if (!bUSER_BOARD_LED || !boardLedPinUsable())
    {
        if (boardLedLit)   // switched off (or OneWire took the pin) mid-flash: leave dark
        {
            boardLedLit = false;
            if (boardLedPinUsable())   // OneWire owns the pad: clear the state, never write the pin
                boardLedWrite(false);
        }
        #if defined(BOARD_LED)
        if (!boardLedPinUsable())
            boardLedOutput = false;
        #endif
        return;
    }
    const BoardLedStep st = boardLedPhase(millis(), boardLedTimer, boardLedLit);
    boardLedTimer = st.timer;
    boardLedLit = st.lit;
    if (st.changed)
        boardLedWrite(st.lit);
}

void boardLedForceOff(void)   // before deep sleep: LED dark, flasher phase reset
{
    boardLedLit = false;
    if (!boardLedPinUsable())
        return;   // the pad belongs to OneWire: not ours to drive
    #if defined(BOARD_LED)
        pinMode(BOARD_LED, OUTPUT);
        digitalWrite(BOARD_LED, boardLedLevel(false, BOARD_LED_ACTIVE_LOW));
    #else
        bLED_WEISS = false;
        pixels.clear();
        pixels.show();
    #endif
}
#else
bool boardLedPinUsable(void) { return false; }
void boardLedTick(void) {}
void boardLedForceOff(void) {}
#endif

bool bRadio=false;

bool bLED_RED=false;
bool bLED_BLUE=false;
bool bLED_GREEN=false;
bool bLED_ORANGE=false;
bool bLED_CLEAR=false;
bool bLED_DELAY=false;

bool bCHARGE_LED=false;

bool bPingSend=false;

extern unsigned long rebootAuto;
extern bool g_ble_uart_is_connected;

int iWlanWait = 0;

extern float global_batt;
extern int global_proz;

volatile bool bSetLoRaAPRS = false;

bool bDEBUG = false;
bool bDEBUGCSV = false;
bool bDEBUGEN = false;
bool bDEBUGLNG = false;
bool bLORADEBUG = false;
bool bNBRDEBUG = false;   // --nbrdebug: [NBR]-Zeilen der Nachbarschaftsmatrix, getrennt von bLORADEBUG
// --nbrrelay off|count|on (Stufe 2, docs/nbr-wichtigkeit-konzept.md Abschnitt 5): count rechnet
// Bedarfs- und Allein-Maske je Relay und zaehlt, was abgebrochen werden koennte, ohne Wirkung;
// on bricht Fall-B-Relays gegen gehoerte fremde Wiederholungen ab und staffelt den Backoff nach Fall.
bool bNBRRELAY = false;   // count oder on: Masken rechnen, NEED/CANCEL?-Zeilen, Zaehler
bool bNBRCANCEL = false;  // on: Abbruch und Backoff nach Fall wirklich anwenden
// --nbrsym on|off (Stufe 2, Symmetrie-Annahme): default an, gespeichert invertiert
// (node_sset4 0x2000 gesetzt heisst "aus") -- jeder bestehende Knoten startet damit
// nach einem Firmware-Update ohne Migration mit sym an. Siehe nbr_matrix.h
// NBR_SYM_MIN_SNR fuer die Schwelle. Bit seit 2026-09-25 auf 0x2000 (vorher
// 0x0080, kollidierte mit upstream KISS/TCP), siehe settings_sanitize.h.
bool bNBRSYM = true;
// --nbrreport off|auto|on (Stufe 3, HN-Bericht): zwei Bits in node_sset4 --
// 0x0100 "off" (nie senden), 0x0200 "on" (immer senden), keines von beiden
// "auto" (Default fuer jeden bestehenden Knoten, keine Migration noetig):
// Bericht nur, wenn weder bMESH noch bGATEWAY (siehe sendNbrReport()-Aufrufer
// in esp32_main.cpp/nrf52_main.cpp). Modell wie --nbrrelay oben: EIN Bool je
// Bit, jede Kommandozeile schreibt nur ihr eigenes.
bool bNBRRPTOFF = false;   // 0x0100 gesetzt
bool bNBRRPTON = false;    // 0x0200 gesetzt
uint32_t stat_nbr_relay_a = 0;          // eingereihte Relays Fall A (Allein-Maske != 0)
uint32_t stat_nbr_relay_b = 0;          // eingereihte Relays Fall B
uint32_t stat_nbr_cancel = 0;           // abgebrochene Relays (nur on)
uint32_t stat_nbr_cancel_possible = 0;  // Relays, deren Bedarf durch fremde Wiederholungen gedeckt war (count: je Slot einmal)
uint32_t stat_nbr_refuse_alone = 0;     // gehoerte fremde Wiederholung, Abbruch wegen Allein-Maske verweigert (je Slot einmal)
bool bBLEDEBUG = false;
bool bWXDEBUG = false;
bool bIODEBUG = false;
bool bTDECKDEBUG = false;
bool bCHECKMESH = false;

bool bPosDisplay = true;
bool bDisplayOff = false;
bool bDisplayIsOff = false;
bool bDisplayVolt = false;
bool bDisplayInfo = false;
bool bDisplayVia = false;
bool bDisplayCont = false;

bool bDisplayLog = false;
char LogCallsign[10] = {0};

bool bDisplayRetx = false;
unsigned long DisplayOffWait = 0;
bool bDisplayTrack = false;
bool bOneButton = false;
bool bEnterDfu = false;   // --dfu: beim naechsten faelligen rebootAuto in den UF2-Bootloader statt Neustart
// ALT-35: getrennt von bOneButton -- "Anzeige neu aufbauen", nicht "Taste gedrueckt".
bool bDisplayDirty = false;
bool bGPSON = false;
bool bGPSAutosymbol = false;
bool bGPSUBLOX = false;
bool bGPSL76K = false;
bool bBMPON = false;
bool bBMP3ON = false;
bool bAHT20ON = false;
bool bUVON = false;
bool bWINDON = false;
#if defined(ENABLE_LTR390) || defined(ENABLE_WIND)
wx_mean_t wx_uv_mean = {0.0f, 0};
wx_mean_t wx_wind_mean = {0.0f, 0};
wx_gust_t wx_wind_gust = {{0.0f, 0.0f, 0.0f}, 0, 0, 0.0f, false};
bool ltr390_found = false;
uint32_t wx_uv_raw = 0;
float wx_uv_last = 0.0f;
float wx_wind_last_kmh = 0.0f;
#endif
bool bSHT21ON = false;
bool bBMEON = false;
bool bBME680ON = false;
bool bMCU811ON = false;
bool bINA226ON = false;
bool bRTCON = false;
bool bSMALLDISPLAY = false;
bool bSOFTSERON = false;
bool bSOFTSERREAD = false;
bool bNoMSGtoALL = false;

bool bTCA9548A = false;

bool bONEWIRE = false;

bool bLPS33 = false;

bool bme680_found = false;
bool bmx_found = false;
bool bmx_is_bme = false;   // chip ID 0x60 (BME280) detected; read only together with bmx_found
int bmx_start = 0;
bool bmp3_found = false;
bool aht20_found =false;
bool sht21_found = false;
bool mcu811_found = false;
bool one_found = false;
int one_start = 0;
bool ina226_found = false;
bool shtc3_found = false;
bool dht_found = false;

bool bGATEWAY = false;
bool bGATEWAY_NOPOS = false;
bool bMESH = false;
bool bVIA = false;
bool bWEBSERVER = false;
bool bWIFIAP = false;
bool bEXTUDP = false;
bool bNETCONSOLE = false;
bool bKISS = false;
bool bKISSTX = false;
bool bKISSMETA = false;
bool bKISSAUTH = false;

bool bSHORTPATH = false;
//bool bGPSDEBUG = false;
int iGPSDEBUG = 0;
bool bSOFTSERDEBUG = false;

bool bBOOSTEDGAIN = false;

bool bBLElong = false;

int iDisplayType = 0;
int DisplayTimeWait = 0;

bool bButtonCheck = false;
uint8_t iButtonPin = 0;

bool bAnalogCheck = false;
float fAnalogValue = 0.0;
bool bAnalogFilter = false;

float fBattFaktor = 0.0;

int iInitDisplay = 0;
int iDisplayChange = 0;

unsigned long lastHeardTime = 0;
unsigned long posfixinterall = 0;

unsigned long currentWiFiMillis = 0;
unsigned long previousWiFiMillis = 0;

// Timer variables for persitence to SD
unsigned long lastsavePOSPersistence = 0;

char cTimeSource[10];

char cBLEName[60]={0};

// SOFTSER global variables
String strSOFTSER_BUF = "";
bool bSOFTSER_APP = false;
int lastSOFTSER_MINUTE = -1;
int softserFunktion=0;

String strSOFTSERAPP_ID = "";    // ID der Messstelle
String strSOFTSERAPP_NAME = "";  // Name der Messstelle

// TELEMTRY global variables
int iNextTelemetry=0;
String strTelemetry="";

// same set of variables for BATT
float BATTalpha = 0.1;
float BATTexp1 = 0.0;
float BATTexp1pre = 0.0;
float BATTexp12 = 0.0;
float BATexp12pre = 0.0;
float BATexp2 = 0.0;

// T5Paper
int t5_cursor_y = 50;

// common variables
char msg_text[MAX_MSG_LEN_PHONE * 2] = {0};

unsigned int _GW_ID = 0x12345678; // ID of our Node

#if (defined(BOARD_E290) || defined(WP_DISP) || defined(BOARD_E213))
#include "heltec-eink-modules.h"

#if defined(BOARD_E290)
EInkDisplay_VisionMasterE290 epaper_display;
#elif (defined(WP_DISP) || defined(BOARD_E213))
// Wireless Paper: Panel-Controller variiert je HW-Version (E0213A367 ab V1.1.1,
// LCMEN2R13EFC1 bei V1.1). Welcher verbaut ist, wird zur Laufzeit per Chip-ID erkannt
// (detectEinkChipId() in esp32_functions.cpp) und der passende Treiber dynamisch
// instanziiert. epaper_display ist daher ein BaseDisplay-Zeiger; das Makro haelt die
// bestehende ".methode()"-Schreibweise im uebrigen Code unveraendert.
BaseDisplay* g_epaper_display = nullptr;
const char*  g_wp_panel_name  = "?";
#define epaper_display (*g_epaper_display)
#endif

#include "Fonts/FreeMonoBold9pt7b.h"
#include "Fonts/FreeMonoBold12pt7b.h"

#include "Fonts/FreeSans9pt7b.h"
#include "Fonts/FreeSansBold9pt7b.h"
#include "Fonts/FreeSans12pt7b.h"

#include <GxEPD2.h>

// 9pt-Schrift fuer den E-Paper-Pfad. Auf der Wireless Paper FETT (FreeSansBold), auf der E290
// regulaer (unveraendert).
//
// WARUM FETT? Das E-Ink-Panel kennt nur "Pixel schwarz" oder "Pixel weiss" - keine Graustufen,
// kein Antialiasing. Ein nur EIN Pixel breiter Strich (wie bei der regulaeren FreeSans9pt) wirkt
// deshalb NICHT satt schwarz, sondern graeulich/duenn: ein einzelner schwarzer Pixel zwischen
// weissen Nachbarn wird optisch als Grau wahrgenommen (zu wenig "Masse" Schwarz). Damit ein
// Strich satt schwarz erscheint, muss er aus MEHREREN Pixeln bestehen - genau das liefert die
// fette FreeSansBold9pt (Striche ~2 Pixel breit). Gleiche Schriftgroesse (9pt), nur kraeftiger
// -> auf E-Ink klar lesbar und richtig schwarz statt grau.
#if defined(WP_DISP)
#define WP_FONT9 (&FreeSansBold9pt7b)
#else
#define WP_FONT9 (&FreeSans9pt7b)
#endif

#if defined(WP_DISP)
// Standard-Layout (Statusseiten wie Info/Position/Track: gross, ueber das ganze
// Panel verteilt). Nur die Nachrichtenseite (iDisplayType 0) schaltet via
// wpApplyLayout() auf ein kompaktes Layout (kleine Statuszeile, enge Zeilen) um,
// damit eine volle 160-Zeichen-Nachricht passt.
int dzeile[maxdisplines] = {16, 41, 61, 81, 101, 121, 0};
bool bWpCompactLayout = false;
// Index der aktuell per 1x-Klick angezeigten Nachricht (oben rechts): neueste=N..aelteste=1,
// 0 = kein Index (Home/Status, frische Nachricht). Wird in wpRefreshClock mitgezeichnet, damit
// der 10-s-Statuszeilen-Refresh die Ziffer nicht wegloescht.
int wpMsgIdx = 0;


void wpApplyLayout(bool compact)
{
    bWpCompactLayout = compact;
    // dzeile[0] = Statuszeilen-Baseline. Bewusst in BEIDEN Layouts 12, damit die 9pt-Schrift
    // vollstaendig in das 16px-Refresh-Fenster passt (bei 16 wurde die unterste Pixelreihe der
    // Statuszeile auf den Info-/Track-Seiten abgeschnitten). Body-Zeilen bleiben layout-abhaengig.
    if(compact) { dzeile[0]=12; dzeile[1]=32; dzeile[2]=47; dzeile[3]=62; dzeile[4]=77; dzeile[5]=92; }
    else        { dzeile[0]=12; dzeile[1]=41; dzeile[2]=61; dzeile[3]=81; dzeile[4]=101; dzeile[5]=121; }
}

// Nachrichtentext-Font: gleiche 9pt-fett-Glyphen wie WP_FONT9, aber enger Zeilenabstand
// (yAdvance=15 statt ~22), damit eine volle Nachricht (bis ~160 Zeichen) auf das Panel passt.
// Wird SOWOHL beim Live-Empfang (sendDisplayText) ALS AUCH beim Durchblaettern ("#N") genutzt
// -> identischer Zeilenabstand in beiden Faellen. Lazy-Init beim ersten Aufruf.
const GFXfont* wpMsgFont()
{
    static GFXfont f;
    static bool ready = false;
    if(!ready)
    {
        memcpy_P(&f, WP_FONT9, sizeof(GFXfont));
        f.yAdvance = 15;
        ready = true;
    }
    return &f;
}
#else
int dzeile[maxdisplines] = {16, 41, 61, 81, 101, 121, 0};
#endif

#elif defined (BOARD_T_ECHO)

#include "t_echo_utilities.h"
#include "t_echo_images.h"

#define WP_FONT9 (&FreeSans9pt7b)

//Libraries for E-paper Display
#include <GxEPD.h>
#include <GxDEPG0150BN/GxDEPG0150BN.h>  // 1.54" b/w
#include GxEPD_BitmapExamples
#include <GxIO/GxIO_SPI/GxIO_SPI.h>
#include <GxIO/GxIO.h>

SPIClass dispPort(NRF_SPIM3, ePaper_Miso, ePaper_Sclk, ePaper_Mosi);

GxIO_Class io(dispPort, ePaper_Cs, ePaper_Dc, ePaper_Rst);
GxEPD_Class epaper_display(io, ePaper_Rst, ePaper_Busy);

#include "Fonts/FreeMonoBold9pt7b.h"
#include "Fonts/FreeMonoBold12pt7b.h"

#include "Fonts/FreeSans9pt7b.h"
#include "Fonts/FreeSans12pt7b.h"

int dzeile[maxdisplines] = {16, 41, 61, 81, 101, 121, 141, 161, 181, 200, 0};

#elif defined (BOARD_TBEAM_V3)
int dzeile[maxdisplines] = {11, 24, 34, 44, 54, 64, 0};
#elif defined (BOARD_STICK_V3)
int dzeile[maxdisplines] = {42, 52, 62, 0, 0, 0, 0};
#else
int dzeile[maxdisplines] = {8, 21, 31, 41, 51, 61, 0};
#endif

#if MC_HAS_U8G2   // GRD-01: war die wortgleiche 11-Term-Liste

#include <U8g2lib.h>
#include "instrument.h"

U8G2 *u8g2;

#if defined(BOARD_HELTEC)
    U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2_1(U8G2_R0, 16, 15, 4);
    U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2_2(U8G2_R0, 16, 15, 4);
#elif defined(BOARD_HELTEC_V3) || defined(BOARD_HELTEC_V4) || defined(BOARD_STICK_V3)
    // Hardware-I2C auf Wire1 (SDA_PIN/SCL_PIN werden vor begin() mit
    // Wire1.setPins() gesetzt, siehe esp32_functions.cpp) statt Software-
    // Bitbanging mit 1-Seiten-Puffer: ein Bild kostete 579 ms auf dem
    // Hauptschleifen-Task (gemessen DK5EN-93, [INSTR-FLUSH]), jetzt einige ms.
    // Wire selbst haengt auf diesen Boards an den Sensoren (I2C_SDA/I2C_SCL).
    U8G2_SSD1306_128X64_NONAME_F_2ND_HW_I2C u8g2_1(U8G2_R0, 21);
    U8G2_SH1106_128X64_NONAME_F_2ND_HW_I2C u8g2_2(U8G2_R0, 21);
#elif defined(BOARD_FAKETEC_V4)
    U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2_1(U8G2_R0, U8X8_PIN_NONE, 11, 36);
    U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2_2(U8G2_R0, U8X8_PIN_NONE, 11, 36);
#elif defined(BOARD_RAK4630)
    U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2_1(U8G2_R0);  //RESET CLOCK DATA
    U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2_2(U8G2_R0);  //RESET CLOCK DATA
#elif defined(BOARD_TBEAM_V3)
    // Wie bei Heltec V3/V4 (TM-09): Software-Bitbanging mit 1-Seiten-Puffer
    // kostete ein Bild ~570 ms auf dem Hauptschleifen-Task (Feldmeldung
    // T-Beam Supreme, [INSTR-LOOP];gap;...;in;display_tick, 4x/min beim
    // 15-s-Uhr-Refresh). Anders als dort liegt das OLED hier auf DEMSELBEN
    // Bus wie PMU/RTC/Sensoren (SDA_PIN 17 / SCL_PIN 18), also Wire statt
    // Wire1. Vollbild-Puffer (_F_) statt _1_: ein Transfer je Bild, und ein
    // unveraendertes Bild kann uebersprungen werden (TM-10).
    //
    // Keine Pins an den Konstruktor: mit expliziten clock/data-Pins ruft u8g2
    // in U8X8_MSG_GPIO_AND_DELAY_INIT (U8x8lib.cpp) pinMode(OUTPUT) auf genau
    // den Pins, die der I2C-Controller seit Wire.begin(17, 18) im Setup schon
    // besitzt, und haengt sie damit vom Peripheral ab; das anschliessende
    // Wire.begin(17, 18) aus u8g2 ist auf dem laufenden Bus ein No-op. Der
    // Controller startet die Init-Sequenz dann auf einem Bus, den er nicht
    // mehr treibt: 4.35t blieb auf dem T-Beam Supreme in u8g2->begin()
    // stehen (Feldmeldung, zwei Knoten, Bus davor mit ACK auf 0x3C). Ohne
    // Pins bleibt u8g2 bei Wire.begin() ohne Argumente und fasst keine
    // GPIOs an -- dasselbe Muster wie T-Beam v1.2 und RAK oben.
    U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2_1(U8G2_R0);
    U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2_2(U8G2_R0);
#elif defined(BOARD_TBEAM_1W)
    DISPLAY_MODEL u8g2_1(U8G2_R0, U8X8_PIN_NONE);  //RESET CLOCK DATA
    DISPLAY_MODEL u8g2_2(U8G2_R0, U8X8_PIN_NONE);
#else
    // TM-22: Vollbild-Puffer (_F_) auch fuer den SSD1306, wie beim SH1106 --
    // im Seitenmodus (_1_) kostete ein Bild 8 I2C-Transfers und jedes Bild
    // musste komplett neu gezeichnet werden; mit dem Puffer im RAM kann
    // sendDisplay1306() ein unveraendertes Bild ueberspringen (TM-10).
    U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2_1(U8G2_R0);
    U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2_2(U8G2_R0);
#endif
#endif

unsigned int msg_counter = 0;

// Buffer to hold temp info-frames
uint8_t RcvBuffer[UDP_TX_BUF_SIZE * 2] = {0};

// RINGBUFFER to hold own msg_id
uint8_t own_msg_id[MAX_RING][5] = {0};
int iWriteOwn=0;

// RINGBUFFER for incoming UDP lora packets for lora TX
unsigned char ringBuffer[MAX_RING][UDP_TX_BUF_SIZE+5] = {0};
int iRetransmit=-1;

// FIX: Per-slot retry counter for retransmit cap
uint8_t retryCount[MAX_RING] = {0};

// RINGBUFFER for incomming LoRa RX msg_id
// ringBufferLoraRX/loraWrite liegen jetzt in dedup_functions.cpp.

// RINGBUFFER RAW LoRa RX
// R1-04: der RAW-RX-Ringpuffer wird erst angelegt, wenn ihn jemand ANSIEHT.
//
// Er hat genau EINEN Leser -- die rxlog-Seite der Web-Oberflaeche
// (web_functions.cpp) -- und kostete bisher MAX_LOG * (UDP_TX_BUF_SIZE+5)
// Byte statisch auf JEDEM Knoten, auch auf denen ohne Webserver und auf denen,
// die die Seite nie oeffnen. Das sind 5 200 B bei MAX_LOG 20 und 2 600 B bei
// MAX_LOG 10.
//
// WARUM DAS OHNE SPERRE SICHER IST, und das ist hier die eigentliche Frage:
// der Schreiber laeuft auf einem ANDEREN Task als der Anleger. charBuffer_aprs()
// haengt an OnRxDone(), also am LORA-Task (16 kB, nicht am 1-kB-Timer-Task --
// die Audit-Zeile sagt "timer task" und liegt damit falsch, siehe die Notiz in
// docs/BACKLOG.md). Angelegt wird aus dem Web-Pfad.
//
// Die Regeln, die den Wettlauf ausschliessen:
//   1. Der Zeiger geht GENAU EINMAL von NULL auf gueltig und wird NIE wieder
//      NULL. Es gibt kein free(), also auch kein use-after-free.
//   2. Der Puffer ist VOLLSTAENDIG genullt, BEVOR der Zeiger veroeffentlicht
//      wird. Ein Schreiber sieht darum entweder NULL -- dann schreibt er nicht --
//      oder einen fertigen Puffer. Einen halb initialisierten sieht er nie.
//   3. Der Schreiber liest den Zeiger EINMAL in eine lokale Variable und
//      benutzt nur diese. Ein zweites Lesen koennte sonst zwischen Pruefung
//      und Benutzung einen anderen Wert sehen.
// Ein einzelner ausgerichteter Zeigerschreibzugriff ist auf ARM und Xtensa
// atomar; mehr Synchronisation braucht es fuer dieses Muster nicht.
typedef unsigned char rawLogLine_t[UDP_TX_BUF_SIZE+5];
rawLogLine_t *ringbufferRAWLoraRX = NULL;

// Legt den Puffer beim ersten Aufruf an. Gibt false zurueck, wenn kein Speicher
// da ist -- die rxlog-Seite zeigt dann eine Notiz statt Zeilen, der Knoten
// funkt unveraendert weiter.
bool rawLogEnsure(void)
{
    if(ringbufferRAWLoraRX != NULL)
        return true;

    rawLogLine_t *p = (rawLogLine_t *)calloc(MAX_LOG, sizeof(rawLogLine_t));
    if(p == NULL)
    {
        Serial.printf("[RXLOG];alloc;failed;bytes;%u\n",
                      (unsigned)(MAX_LOG * sizeof(rawLogLine_t)));
        return false;
    }

    ringbufferRAWLoraRX = p;   // Veroeffentlichung, nachdem calloc() genullt hat
    return true;
}
int RAWLoRaWrite=0;
int RAWLoRaRead=0;

// Flag set by app-layer auth failure to request BLE disconnection
bool ble_disconnect_requested = false;

// Die drei Ausgangsringe -- UDP-Ausgang, BLE-Daten zum Telefon, BLE-Kommandos
// zum Telefon -- sind Byte-Ringe (src/byte_fifo.h), keine Schlitzfelder mehr.
// Vorher lagen sie als [MAX_RING][260], [MAX_RING][260] und [MAX_RING_UDP][256]
// im statischen RAM, 15,2 kB auf der 20er-Klasse, davon im Dauerlauf 70 %
// Luft. Die Erzeuger klemmen die Laenge wie bisher (UDP: UDP_TX_BUF_SIZE,
// Telefon: UDP_TX_BUF_SIZE-4 bzw. 255 fuer 'D'-Frames, Kommandos: 245); der
// Ring selbst nimmt jeden Frame bis 255 Byte.
static uint8_t udpOutStore[RING_BYTES_UDP];
byte_fifo_t udpOutRing = BYTE_FIFO_INIT(udpOutStore);

// phoneRing / phoneComRing: static storage everywhere, except on the classic ESP32 with the AU BLE
// pause (PHONE_RINGS_DYNAMIC): there they start without storage (cap 0 = empty, push drops),
// phoneRingsAttach() allocates 2 + 3 KB at BLE start and esp32BlePause() releases them, so the
// TLS job gets the 5 KB (heap verdict 2026-10-18, lever 3).
#if PHONE_RINGS_DYNAMIC
byte_fifo_t phoneRing = {NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#else
static uint8_t phoneStore[RING_BYTES_PHONE];
byte_fifo_t phoneRing = BYTE_FIFO_INIT(phoneStore);

static uint8_t phoneComStore[RING_BYTES_PHONECOM];
#endif
// Der BLE-Config-Burst nach dem Verbinden (config_cmds[] in esp32_main.cpp /
// nrf52_main.cpp, --nodeset liefert SN und SN1) geht in EINEM
// Schleifendurchlauf in diesen Ring und wird mit einem Frame je 300 ms
// geleert. Passt er nicht ganz hinein, verdraengt bf_push() die ersten
// ungelesenen Frames -- darunter das I-Register, und die App zeigt leere
// Node-Settings. Obergrenze: 12 Frames zu je 245 Byte plus Laengenbyte.
static_assert(RING_BYTES_PHONECOM >= 12 * (245 + 1),
              "phoneComRing must hold the whole BLE config burst (12 x 246 B)");
#if PHONE_RINGS_DYNAMIC
byte_fifo_t phoneComRing = {NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0};

bool phoneRingsAttach(void)
{
    // all or nothing (bf_attach_all): never one ring up and the other without storage
    byte_fifo_t *const rings[2] = {&phoneRing, &phoneComRing};
    static const uint16_t caps[2] = {RING_BYTES_PHONE, RING_BYTES_PHONECOM};
    return bf_attach_all(rings, caps, 2, malloc, free);
}

void phoneRingsDetach(void)
{
    // bf_detach() sets cap/buf under the ring lock (byte_fifo.cpp, portMUX on ESP32), so no
    // producer or reader on the loop/LoRa/web tasks can still be inside a ring afterwards:
    // the memory is freed right away.
    byte_fifo_t *const rings[2] = {&phoneRing, &phoneComRing};
    bf_detach_free(rings, 2, free);
}
#else
byte_fifo_t phoneComRing = BYTE_FIFO_INIT(phoneComStore);
bool phoneRingsAttach(void) { return true; }
void phoneRingsDetach(void) {}
#endif

// BLE-N1/N2: counters of the node->phone path (sent, retried, dropped,
// truncated, evicted, last MTU). Written by the producers below and by the
// drain in phone_commands.cpp, shown by --info. See src/ble_phone_drain.h.
BlePhoneStats g_blePhoneStats = {0, 0, 0, 0, 0, 0};

bool hasMsgFromPhone = false;

// LoRa RX/TX sequence control
is_receiving_t is_receiving{false};  // flag to store we are receiving a lora packet.
std::atomic<bool> tx_is_active{false};  // flag to store we are transmitting  a lora packet.

int cad_attempt = 0;
unsigned long csma_timeout = CSMA_BASE_0;
int rx_irq_defer_count = 0;

// Channel utilization tracking (10s window)
ch_util_rx_start_t ch_util_rx_start{0};   // timestamp when RX started
ch_util_ulong_t ch_util_tx_start{0};   // timestamp when TX started
ch_util_ulong_t ch_util_rx_accum{0};   // accumulated RX airtime (ms) in current window
ch_util_ulong_t ch_util_tx_accum{0};   // accumulated TX airtime (ms) in current window

// SL-05 -- Zaehler fuer die 5-Minuten-STAT-Zeile unter `--setlog on`.
// std::atomic wie ch_util_*_accum daneben: geschrieben werden sie im LORA-Task
// (OnRxDone/OnRxError, SL-01/SL-04) und in loop() (doTX, SL-03), gelesen und
// per exchange(0) zurueckgesetzt in setlogFillStat().
std::atomic<uint32_t> stat_newid{0};       // neue msg_id im Dedup-Ring
std::atomic<uint32_t> stat_dup{0};         // erkannte Kopien
std::atomic<uint32_t> stat_rx_err{0};      // RX-/CRC-Fehler
std::atomic<uint32_t> stat_txn{0};         // eigene Sendungen
std::atomic<uint32_t> stat_txfail{0};      // vom TX-Watchdog abgebrochen
std::atomic<uint32_t> stat_util_rx_5m{0};  // RX-Luftzeit im 5-min-Fenster (ms)
std::atomic<uint32_t> stat_util_tx_5m{0};  // TX-Luftzeit im 5-min-Fenster (ms)
// Hochwasser von txRingDepth(); in addTxRingEntry() mitgefuehrt
// (txring_functions.cpp), im STAT-Druck zurueckgesetzt.
std::atomic<uint8_t> stat_ring_max{0};

int isPhoneReady = 0;      // flag we receive from phone when itis ready to receive data
bool bAckInfo = false;     // --ackinfo on: volatile session flag, reset on BLE disconnect, never in flash

// APP Time OK
bool bPhoneTimeValid = false;

// NTP Date/Time valid
bool bNTPDateTimeValid = false;

// GPS SmartBeaconing variables
double gps_refresh_intervall = GPS_REFRESH_INTERVAL;   // sec
unsigned long posinfo_interval = POSINFO_INTERVAL; // check interval
double posinfo_distance = 0.0;
double posinfo_direction = 0.0;
double posinfo_lat = 0.0;
double posinfo_lon = 0.0;
double posinfo_last_lat = 0.0;
double posinfo_last_lon = 0.0;
double posinfo_prev_lat = 0.0;
double posinfo_prev_lon = 0.0;
double posinfo_last_direction = 0.0;
unsigned int posinfo_last_rate = POSINFO_INTERVAL;  // seconds

uint32_t posinfo_satcount = 0;
float fposinfo_hdop = 0.0;
bool posinfo_fix = false;
bool posinfo_shot=false;
uint32_t posinfo_age=0;
bool pos_shot = false;
bool wx_shot = false;
int no_gps_reset_counter = 0;
int gps_refresh_track = 0;

// Loop timers
unsigned long posinfo_timer = 0;        // we check periodically to send GPS
unsigned long posinfo_timer_min = 0;    // we check min. periodically to send GPS
// Zeitpunkt des letzten selbst erzeugten Positions-Beacons und ob es ihn schon
// gab -- Schranke fuer den Sofort-Pfad in sendPosition(), siehe beacon_rate.h.
static unsigned long lastOwnPosTx = 0;
static bool bHaveOwnPosTx = false;
static unsigned long iShotSuppressed = 0;
// Dasselbe fuer den Sofort-Pfad von sendHey() (FL-02) -- eigener Zeitstempel,
// unabhaengig vom Positions-Pfad. Siehe sendHeyShot() unten und beacon_rate.h.
static unsigned long lastOwnHeyTx = 0;
static bool bHaveOwnHeyTx = false;
static unsigned long iHeyShotSuppressed = 0;
unsigned long heyinfo_timer = 0;        // we check periodically to send HEY
int ncnt_hold = 0;
unsigned long nbrsnap_timer = 0;        // --nbrdebug: 15-min-Takt fuer nbrLogSnapshot()

// Priority Queue arrays
uint8_t ringPriority[MAX_RING];                 // Prio 1-5 pro Slot
uint32_t ringEnqueueTime[MAX_RING];             // millis() timestamp when enqueued

// Trickle-HEY state
unsigned long trickle_interval_ms = TRICKLE_IMIN_S * 1000UL;
uint8_t trickle_consistent_count = 0;
int trickle_last_neighbor_count = -1;

// Priority statistics
uint16_t stat_tx_count[6] = {0};
uint16_t stat_drop_count[6] = {0};
uint16_t stat_preempt_count = 0;
uint32_t stat_latency_sum[6] = {0};
uint32_t stat_latency_max[6] = {0};
uint8_t  stat_queue_hwm = 0;
uint16_t stat_csma_hwm_attempts = 0;
uint32_t stat_csma_aged_boot[3] = {0}; // since boot
uint32_t stat_wait_hwm_ms = 0;         // max queue latency since boot
int      tx_cad_attempt = 0;           // cad_attempt captured at CAD_FREE, before csma_reset()
unsigned long stat_prio_timer = 0;
unsigned long stat_hwm_timer = 0;
unsigned long telemetry_timer = 0;      // we check periodically to send TELEMETRY
unsigned long temphum_timer = 0;        // we check periodically get TEMP/HUM
unsigned long druck_timer = 0;          // we check periodically get AIRPRESURE
unsigned long hb_timer = 0;
bool hb_warn_logged = false;
unsigned long web_timer = 0;

// Function that gets current epoch time
unsigned long getUnixClock()
{
	struct tm timeinfo;


    timeinfo.tm_year = meshcom_settings.node_date_year - 1900;
    timeinfo.tm_mon = meshcom_settings.node_date_month - 1;
    timeinfo.tm_mday = meshcom_settings.node_date_day;

    timeinfo.tm_hour = meshcom_settings.node_date_hour;
    timeinfo.tm_min = meshcom_settings.node_date_minute;
    timeinfo.tm_sec = meshcom_settings.node_date_second;

    unsigned long ut = (unsigned long)mktime(&timeinfo);
    unsigned long ot = (unsigned long)(meshcom_settings.node_utcoff * 3600.0); // utcoff in sec

    //printfdeb("Date: %i.%i.%i %i:%i:%i %lu %f %lu\n",timeinfo.tm_year, timeinfo.tm_mon, timeinfo.tm_mday, timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec, ut, meshcom_settings.node_utcoff, ot);


	return ut - ot;
}

/** @brief Function adding messages into outgoing BLE ringbuffer
 *   BLE to PHONE Buffer
 */
void addBLEOutBuffer(uint8_t *buffer, uint16_t len)
{
    // Das Laengenbyte im Ring ist ein uint8_t. Im Nicht-'D'-Zweig kommen noch 4 Byte
    // Zeitstempel dazu, dort muss also len+4 hineinpassen; im 'D'-Zweig (JSON) wird
    // len unveraendert abgelegt und darf die vollen 255 nutzen. Die Klemmung und
    // der Push stehen in blePhonePush() (src/ble_phone_drain.h, host-getestet).
    //
    // CONC-15: addBLEOutBuffer() is reachable from OnRxDone (the FreeRTOS
    // timer-service task on nRF52, priority 2, see C-01) while sendToPhone()
    // drains the same ring from the Main Loop task. Der Byte-Ring sperrt
    // jede Operation selbst (byte_fifo.cpp, BF_LOCK), ein eigener kritischer
    // Abschnitt ist hier nicht mehr noetig.
    //
    // Frames ausser 'D' (JSON) bekommen 4 Byte Unix-Zeit angehaengt; der Ring
    // nimmt beide Teile in einem Zug, ohne Zwischenpuffer. Verdraengte
    // ungelesene Frames zaehlt g_blePhoneStats.evicted (BLE-N1).
    int lost;
    if(buffer[0] != 'D')
    {
        uint8_t tbuffer[4];
        blePhoneTimeTag((uint32_t)getUnixClock(), tbuffer);
        lost = blePhonePush(&phoneRing, &g_blePhoneStats, buffer, &len, UDP_TX_BUF_SIZE - 4, tbuffer);
    }
    else
        lost = blePhonePush(&phoneRing, &g_blePhoneStats, buffer, &len, UDP_TX_BUF_SIZE, NULL);

    if(bBLEDEBUG)
    {
        printfdeb("<%02X>BLEtoPhone RingBuff added len=%i unread=%u lost=%i\n", buffer[0], len, (unsigned)bf_unread(&phoneRing), lost);
        printBuffer(buffer, len);
    }
}

/** @brief Function adding config messages into outgoing BLE ringbuffer
 * BLE to PHONE Buffer
 */
void addBLEComToOutBuffer(uint8_t *buffer, uint16_t len)
{
    if (!g_ble_uart_is_connected && !bWEBSERVER)
        return;

    if (len > 245)
        printfdeb("[ERR]...BLE out-buffer to long <%i> <%-245.245s>\n", len, buffer);

    // clamp to 245 - length byte and destination buffer both size to this
    int lost = blePhonePush(&phoneComRing, &g_blePhoneStats, buffer, &len, 245, NULL);

    if(bBLEDEBUG)
    {
        printfdeb("<%s> BLEComToPhone RingBuff added len=%i unread=%u\n", buffer, len, (unsigned)bf_unread(&phoneComRing));
        if(lost > 0)
            printfdeb("[ERR]...BLEComToPhoneRingBuff overflow! %i unread frame(s) evicted\n", lost);
    }
}

void addBLECommandBack(char text[UDP_TX_BUF_SIZE])
{
    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, ':');

    aprsmsg.msg_len = 0;
    aprsmsg.payload_type = ':';
    aprsmsg.msg_id = millis();
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "*");
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), "*");
    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), "response");
    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), text);

    aprsmsg.msg_app_offline = true; // RÄ‚Ä˝ckmeldungen niemals annoucen

    checkVia(aprsmsg);

    encodeAPRS(msg_buffer, aprsmsg);

    addBLEOutBuffer(msg_buffer, aprsmsg.msg_len);
}

// addLoraRxBuffer()/checkOwnRx()/checkServerRx() sind nach
// dedup_functions.cpp gewandert (reine Verschiebung).

int checkOwnTx(unsigned int msg_id)
{
    if(msg_id == 0)
        return -1;

    unsigned int own_id=0;

    for(int ilo=0; ilo<MAX_RING; ilo++)
    {
        own_id = own_msg_id[ilo][0] | (own_msg_id[ilo][1] << 8) | (own_msg_id[ilo][2] << 16) | (own_msg_id[ilo][3] << 24);

        if(own_id == msg_id)
        {
            if(bDisplayInfo)
                printfdeb("%s checkOwnTx:%08X own_msg_id:%08X <%02X%02X%02X%02X> %02X\n", getTimeString().c_str(), msg_id, own_id, own_msg_id[ilo][3], own_msg_id[ilo][2], own_msg_id[ilo][1], own_msg_id[ilo][0], own_msg_id[ilo][4]);

            return ilo;
        }
    }

    return -1;
}

// The ONE write path for the delivery state of an own message
// (own_msg_id[idx][4]: 0x00 sent, 0x01 heard, 0x02 ACK, 0x03 failed, 0x04 held).
// The ring slot is recycled on the next own TX, so the web GUI reads the durable
// status table (own_msg_status.h) instead; the T-Deck bubble glyph (TD-11) is
// driven from here as well. Every state change goes through this function so the
// three views cannot drift apart. insertOwnTx() stays a direct write: it stores a
// NEW id, that is not a state change.
void setOwnMsgStatus(int idx, uint8_t state)
{
    if(idx < 0 || idx >= MAX_RING)
        return;

    uint8_t old = own_msg_id[idx][4];
    own_msg_id[idx][4] = state;

    // msg_id of the slot, bytes 0-3 little-endian (as insertOwnTx() stores it)
    uint32_t id = (uint32_t)own_msg_id[idx][0] | ((uint32_t)own_msg_id[idx][1] << 8) | ((uint32_t)own_msg_id[idx][2] << 16) | ((uint32_t)own_msg_id[idx][3] << 24);

    ownMsgStatusSet(id, state);

    #if defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS)
    // TD-11: every call site runs in esp32loop(), the LVGL task, no lock needed;
    // report the transition only (every relay echo reaches the 0x01 site)
    if(old != state)
        tdeck_set_msg_status(id, state);
    #else
    (void)old;
    #endif
}

void insertOwnTx(unsigned int msg_id)
{
    if(msg_id == 0)
        return;

        // byte 0-3 msg_id
    own_msg_id[iWriteOwn][3] = msg_id >> 24;
    own_msg_id[iWriteOwn][2] = msg_id >> 16;
    own_msg_id[iWriteOwn][1] = msg_id >> 8;
    own_msg_id[iWriteOwn][0] = msg_id;

    own_msg_id[iWriteOwn][4]=0x00;

    if(bDisplayInfo)
    {
        printfdeb("%s Insert own_msg_id:%08X <%02X%02X%02X%02X>\n", getTimeString().c_str(), msg_id, own_msg_id[iWriteOwn][3], own_msg_id[iWriteOwn][2], own_msg_id[iWriteOwn][1], own_msg_id[iWriteOwn][0]);
    }

    iWriteOwn++;
    if(iWriteOwn >= MAX_RING)
        iWriteOwn=0;
}

#if defined(BOARD_T_ECHO)
#define maxdisplines 11
#define PAGE_MAX 6
#elif defined(WP_DISP) || defined(BOARD_E290)
#define maxdisplines 7
#define PAGE_MAX 10   // Wireless Paper: bis zu 9 gespeicherte Nachrichten in einer Loop durchblaettern
#else
#define maxdisplines 7
#define PAGE_MAX 6
#endif

int16_t pageLine[maxdisplines][3] = {0};
char pageText[maxdisplines][25] = {0};
char pageTextLong1[25] = {0};
char pageTextLong2[200] = {0};
int pageLineAnz=0;


int16_t pageLastLine[PAGE_MAX][maxdisplines][3] = {0};
char pageLastText[PAGE_MAX][maxdisplines][25] = {0};
#if defined(HAS_LONG_PAGE_TEXT)
char pageLastTextLong1[PAGE_MAX][25] = {0};
char pageLastTextLong2[PAGE_MAX][200] = {0};
#endif
int pageLastLineAnz[PAGE_MAX] = {0};
int pageLastPointer=0;
int pagePointer=0;
int pageHold=PAGE_MAX-1;

// Bench-Harness: Bildaufbau-Zeit des OLED und Seitenzustand (--oledstat, --oledlog)
bool bOledLog = false;
uint32_t oled_last_frame_us = 0;
uint32_t oled_frames = 0;
uint32_t oled_skipped = 0;          // TM-10: Bilder, die unveraendert waren und nicht gesendet wurden
uint32_t oled_last_crc = 0;         // TM-27: CRC32 des zuletzt gezeichneten Bildpuffers
static bool oled_last_crc_valid = false;

#if MC_HAS_U8G2   // GRD-01: war die wortgleiche 11-Term-Liste
// CRC32 (IEEE, bitweise) ueber den U8g2-Bildpuffer: 1 KB fuer 128x64, ~50 us.
static uint32_t oledBufferCrc(void)
{
    const uint8_t *p = u8g2->getBufferPtr();
    size_t n = (size_t)u8g2->getBufferTileHeight() * (size_t)u8g2->getBufferTileWidth() * 8u;
    uint32_t crc = 0xFFFFFFFFu;
    for(size_t i = 0; i < n; i++)
    {
        crc ^= p[i];
        for(int k = 0; k < 8; k++)
            crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}

// TM-10: true, wenn der gerade gezeichnete Puffer dem zuletzt gesendeten Bild
// entspricht -- nur im Vollbild-Modus (_F_), im Seitenmodus liegt nie das
// ganze Bild im RAM und es wird immer gesendet. Merkt sich die CRC (TM-27).
static bool oledFrameUnchanged(void)
{
    if(u8g2->getBufferTileHeight() * 8 < u8g2->getDisplayHeight())
        return false;
    uint32_t crc = oledBufferCrc();
    bool same = oled_last_crc_valid && crc == oled_last_crc;
    oled_last_crc = crc;
    oled_last_crc_valid = true;
    return same;
}
#endif

// Nach jedem Zeichnen am Display vorbei an sendDisplay1306() (DisplayPong,
// Track-Seite, clearDisplay beim Start) muss das naechste Bild wieder gesendet werden.
void oledInvalidate(void)
{
    oled_last_crc_valid = false;
}

bool bSetDisplay = false;
bool bShowHead = false;;

// detect oled-display type
// see https://github.com/olikraus/u8g2/discussions/2088
int esp32_isSSD1306(int address)
{
    #if defined(BOARD_FAKETEC_V4)
        return 1; // 0.96 cala SSD1306 dla Faketec v4
    #endif
    byte buffer[1];

    #if defined (BOARD_HELTEC_V3) || defined(BOARD_HELTEC_V4)
        return 1;
    #endif

    #if defined (BOARD_STICK_V3)
        return 1;
    #endif

    #if defined(BOARD_TRACKER)
        return 1;
    #endif

    #if defined(BOARD_HELTEC_T114)
        return 1;
    #endif

    #if defined(BOARD_T_CONNECT_PRO)
        return 1;
    #endif

    #if defined(BOARD_T_ECHO)
        return 1;
    #endif

    #if defined(BOARD_T5_EPAPER)
        return 1;
    #endif

    #if defined(BOARD_TBEAM_V3)
        return 2;
    #endif

    #if defined(BOARD_TBEAM_1W)
        // DISP-01: der Zweifel im alten Kommentar ("SH1106 aber stimmt 1
        // wirklich?") ist BERECHTIGT und bleibt offen. Unter dem jetzt
        // geklaerten Vertrag heisst 1 = 0,9"/SSD1306. Ist das Panel dieses
        // Boards tatsaechlich ein 1,3"/SH1106, muesste hier 2 stehen. Nicht
        // blind geaendert: kein T-Beam 1W auf dieser Bench, und ein falscher
        // Wert tauscht nur einen ungeprueften Zustand gegen einen anderen.
        // Zu pruefen ist genau eins -- Panelgroesse des Boards.
        return 1;
    #endif

    #if defined(BOARD_T3S3_V13)
        return 1;
    #endif

    TwoWire *w = NULL;

    w = &Wire;

    w->beginTransmission(address);
    w->write(0x00);
    w->endTransmission(false);
    w->requestFrom(address, 1);

    bool bFound=false;

    if (w->available() > 0)
    {
        w->readBytes(buffer, 1);
        bFound=true;
    }
    w->endTransmission();

    // no display found
    if(!bFound)
    {
        printlndeb("[INIT]...Display not found");
        return -1;
    }

    printfdeb("[INIT]...Display type: 0x%02X\n", buffer[0]);

    // 0x00 == T-BEAM 1.3" 1106 !! sonst kommen artefakte

    // 0x00 == T-BEAM 1.3" 1306
    // 0x16 == T-BEAM 1.3" 1306
    // 0x28 == T-BEAM 1.3" 1306

    // 0x28 == E22 1.3" 1306
    // 0x28 == T-BEAM 1.3" SUPREME 1306

    // 0x03 == T-BEAM 0.9"
    // 0x07 == T-LORA 0.9"
    // 0x07 == T-LORA 0.9"
    // 0x09 == HELTEC V3
    // 0x3F == HELTEC V3

    // check 1.3"
    byte checkByte = buffer[0] & 0x03f;
    if(checkByte == 0x28 || checkByte == 0x16 || checkByte == 0x00)
    {
        // DISP-01, 2026-09-17: diese Zeile sagte "SSD1306" und war damit GENAU
        // VERKEHRT. Der Test hier klassifiziert nach PANEL-GROESSE, nicht nach
        // Controller: die Kommentare darueber ordnen 0x28/0x16/0x00 alle einem
        // 1,3"-Panel zu, und 1,3"-OLEDs sind SH1106 (0,96" sind SSD1306). Der
        // Kommentar "0x00 == T-BEAM 1.3\" 1106 !! sonst kommen artefakte" sagt
        // es sogar ausdruecklich. Die falsche Beschriftung hat die Pruefzeile
        // DISP-01 und einen spaeteren Leser in die entgegengesetzte Richtung
        // geschickt -- beide hielten den ESP32-Zweig fuer verdreht, obwohl er
        // richtig ist. Bench-belegt 2026-09-17 auf DK5EN-93 (Heltec V3,
        // fest verdrahtet 1) und einem T-Beam (Sonde: 0x04 -> 1): beide
        // bekommen u8g2_1 (SSD1306) und stellen sauber dar.
        printlndeb("[INIT]...OLED panel is 1.3 inch -> SH1106");
        return 2;
    }

    // 0,9"-Panel: SSD1306. Auch diese Zeile war verkehrt beschriftet.
    printlndeb("[INIT]...OLED panel is 0.9 inch -> SSD1306");
    return 1;
}

// DISP-01: die Zuordnung "Sondenwert -> U8g2-Objekt" lag ZWEIMAL im Baum,
// einmal in esp32_functions.cpp und einmal in nrf52_functions.cpp -- und die
// beiden Kopien waren GEGENLAEUFIG. ESP32 bildete 1 auf u8g2_1 ab, nRF52 auf
// u8g2_2, obwohl beide dieselbe Sonde aufrufen. Eine der beiden musste falsch
// sein; auf der Bench ist ESP32 als richtig belegt (siehe esp32_isSSD1306()).
//
// Statt die nRF52-Kopie zu korrigieren und zwei Kopien zu behalten, gibt es
// jetzt EINE Zuordnung. Ein kuenftiges Auseinanderlaufen ist damit nicht mehr
// moeglich, und das war der eigentliche Defekt -- nicht der Zahlendreher.
//
//   1 = 0,9"-Panel = SSD1306 = u8g2_1
//   2 = 1,3"-Panel = SH1106  = u8g2_2
//   < 0 = kein Panel gefunden
#if MC_HAS_U8G2   // GRD-01: u8g2_1/u8g2_2 gibt es nur auf Boards mit Panel
U8G2 *mcSelectU8g2(int idtype)
{
    if(idtype < 0)
        return NULL;

    // Beide Objekte sind verschiedene U8g2-Unterklassen; der ternaere
    // Ausdruck braucht daher den gemeinsamen Basistyp ausdruecklich.
    return (idtype == 1) ? (U8G2 *)&u8g2_1 : (U8G2 *)&u8g2_2;
}
#else
// Board ohne U8g2-Panel: die beiden Treiberobjekte existieren nicht, und
// initDisplay() wird auf diesen Boards gar nicht erst aufgerufen. Die
// Fassung hier haelt nur die Verlinkung zusammen.
U8G2 *mcSelectU8g2(int idtype) { (void)idtype; return NULL; }
#endif

void E290DisplayUpdate()
{
    #ifdef HAS_EPAPER
    epaper_display.update();
    #endif
}

#if defined(BOARD_E290)
// E290 refresh policy. Returns true when this page update should be a full refresh (it flashes the panel).
//  - OTP build (EINK_HELTEC_VME290_OTP): quiet partial refresh. Default E290_FULL_EVERY=0: never a full
//    refresh (tested on FPC-7519revb panels, no ghost build-up). Build with -D E290_FULL_EVERY=N to get a full
//    "cleaning" refresh after every N page updates. The TRACK page always uses partial refresh.
//  - Stock build: never (original behaviour, partial refresh only).
#ifndef E290_FULL_EVERY
#define E290_FULL_EVERY 0
#endif
static bool e290FullRefreshDue()
{
    #ifdef EINK_HELTEC_VME290_OTP
    static int cnt = 0;
    if(bDisplayTrack || E290_FULL_EVERY <= 0)
        return false;
    if(++cnt >= E290_FULL_EVERY)
    {
        cnt = 0;
        return true;
    }
    #endif
    return false;
}
#endif

void sendDisplay1306(bool bClear, bool bTransfer, int x, int y, char *text)
{
    #if !defined (BOARD_T_DECK)  && !defined (BOARD_T_DECK_PLUS)

    #if MC_HAS_U8G2   // GRD-01: war die wortgleiche 11-Term-Liste
        if(u8g2 == NULL)
            return;
    #endif
    
    //printfdeb("bClear:%i bTransfer:%i x:%i y:%i pageLineAnz:%i text:%s\n", bClear, bTransfer, x, y, pageLineAnz, text);

	if(bClear || (x == 0 && y== 0) || (x == 0 && memcmp(text, "#F", 2) == 0))
    {
        #if defined(BOARD_T_ECHO)
            epaper_display.fillScreen(GxEPD_WHITE);
            epaper_display.setFont(&FreeMonoBold9pt7b);
        #elif defined(HAS_EPAPER)
            epaper_display.clearMemory();

        	if(memcmp(text, "#F", 2) == 0)
                epaper_display.clear();
            else
                epaper_display.clearMemory();

            epaper_display.fastmodeOn();

            #if defined(WP_DISP)
            // Nachrichtenseite: kleine Statuszeile (9pt) -> Platz fuer 160 Zeichen.
            // Statusseiten: gewohnte groessere Schrift (12pt).
            epaper_display.setFont(bWpCompactLayout ? WP_FONT9 : &FreeSans12pt7b);
            #else
            epaper_display.setFont(&FreeMonoBold12pt7b);
            #endif
        #elif defined(BOARD_HELTEC_T114) || defined(BOARD_T_CONNECT_PRO)
        #elif defined(BOARD_TRACKER) || defined(BOARD_T_ECHO) || defined(BOARD_T5_EPAPER) || defined(BOARD_T_DECK_PRO)
        #else
            u8g2->setFont(u8g2_font_6x10_mf);
        #endif

    	if(bClear)
            pageLineAnz=0;
    }

    bool bNeu=true;

	if(memcmp(text, "#N", 2) == 0)
    {
        bNeu=false;
    }
    else
	if(memcmp(text, "#C", 2) == 0)
    {
        bNeu=false;
    }
    else
    {
        if(pageLineAnz < maxdisplines)
        {
            //printfdeb("pageLineAnz:%i text:%s\n", pageLineAnz, text);

            pageLine[pageLineAnz][0] = x;
            pageLine[pageLineAnz][1] = y;
            pageLine[pageLineAnz][2] = 20;
            memcpy(pageText[pageLineAnz], text, 25);
            pageLineAnz++;
            if(pageLineAnz > maxdisplines)
                pageLineAnz = maxdisplines;
        }
    }

    if(bTransfer)
    {
        //printlndeb("Transfer");
        #if defined HAS_EPAPER
            if(pageLineAnz > 0)
            {
                for(int its=0;its<pageLineAnz;its++)
                {
                    // Save last Text (init)
                    if(iDisplayType == 0 && bNeu)
                    {
                        pageLastLineAnz[pageLastPointer] = pageLineAnz;
                        pageLastLine[pageLastPointer][its][0] = pageLine[its][0];
                        pageLastLine[pageLastPointer][its][1] = pageLine[its][1];
                        pageLastLine[pageLastPointer][its][2] = pageLine[its][2];
                        memcpy(pageLastText[pageLastPointer][its], pageText[its], 25);
                    }

                    char ptext[30] = {0};
                    pageText[its][pageLine[its][2]] = 0x00;
                    
                    if(memcmp(pageText[its], "#S", 2) == 0 || memcmp(pageText[its], "#F", 2) == 0)  // #F fastmode off
                    {
                        // only transfer
                        if(!bNeu)
                        {
                            epaper_display.setCursor(0, dzeile[1]);
                            epaper_display.setFont(WP_FONT9);

                            
                            epaper_display.println(pageTextLong1);

                            epaper_display.setCursor(0, dzeile[2]);
                            #if defined(WP_DISP)
                            epaper_display.setFont(wpMsgFont());   // enger Zeilenabstand (15) wie Live-Empfang -> Browse == Live
                            #endif
                            epaper_display.println(pageTextLong2);
                        }
                    }
                    else
                    if(memcmp(pageText[its], "#L", 2) == 0)
                    {
                        #if defined(WP_DISP)
                        // Nachrichtenseite (kompakt): Linie hoeher bei y=17; Statusseiten bei y=22.
                        // Die Statusseite darf bewusst anders sein als die Nachrichten-/Blaetter-Ansicht.
                        epaper_display.drawLine(0, bWpCompactLayout ? 17 : 22, 250, bWpCompactLayout ? 17 : 22, GxEPD_BLACK);
                        #else
                        epaper_display.drawLine(0, 22, 320, 22, GxEPD_BLACK);
                        #endif

                        //u8g2->drawHLine(pageLine[its][0], pageLine[its][1], 120);
                    }
                    else
                    {
                        snprintf(ptext, sizeof(ptext), "%s", pageText[its]);
                        if(pageLine[its][1] >= 0)
                        {
                            epaper_display.setCursor(pageLine[its][0], pageLine[its][1]);
                            epaper_display.println(ptext);

                            //u8g2->drawUTF8(pageLine[its][0], pageLine[its][1], ptext);
                        }
                    }
                }

            	if(memcmp(text, "#S", 2) != 0 && memcmp(text, "#F", 2) != 0)
                {
                    #if defined(WP_DISP)
                    // Der "#N"-Render kommt AUSSCHLIESSLICH von wpShowStoredMessage (Nachrichten-
                    // Blaettern) und schiebt UNMITTELBAR danach selbst einen fastmodeOff()+update()
                    // = Voll-Refresh nach (zeigt denselben Framebuffer inkl. Browse-Ziffer). Dieses
                    // erste "#N"-update() ist daher auf BEIDEN Panels redundant und erzeugt nur einen
                    // zusaetzlichen Refresh/Blitzer pro Klick. Auf der ganzen Wireless Paper (V1.1 UND
                    // V1.2) ueberspringen -> je Blaetter-Schritt nur EIN Voll-Refresh.
                    if(memcmp(text, "#N", 2) != 0)
                    #endif
                    {
                    #if defined(BOARD_E290)
                    // E290: partial refresh, full "cleaning" refresh only now and then (see e290FullRefreshDue()).
                    bool bE290Full = e290FullRefreshDue();
                    if(bE290Full)
                        epaper_display.fastmodeOff();
                    #endif
                    epaper_display.update();
                    #if defined(BOARD_E290)
                    if(bE290Full)
                        epaper_display.fastmodeOn();   // back to fastmode ON: the panel RAMs hold what is on screen
                    #endif
                    }
                }
            }
            
        #elif defined(BOARD_TRACKER) || defined(BOARD_HELTEC_T114) || defined(BOARD_T_CONNECT_PRO)

        #if defined(BOARD_HELTEC_T114)
        if(!bDisplayIsOff)
            digitalWrite(PIN_TFT_LEDA_CTL, LOW);   // TFT ON
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
        if(!bDisplayIsOff)
            ledcAttachPin(SCREEN_BL, 1);
        #endif

        #if defined(HAS_TFT)
        tftBacklight();   // #1182: dark on "#C" while bDisplayIsOff, even with no lines drawn
        #endif

        if(pageLineAnz > 0)
        {
            int ianz=0;

            String strLine[8];

            for(int its=0;its<pageLineAnz;its++)
            {
                // Save last Text (init)
                if(iDisplayType == 0 && bNeu)
                {
                    pageLastLineAnz[pageLastPointer] = pageLineAnz;
                    pageLastLine[pageLastPointer][its][0] = pageLine[its][0];
                    pageLastLine[pageLastPointer][its][1] = pageLine[its][1];
                    pageLastLine[pageLastPointer][its][2] = pageLine[its][2];
                    memcpy(pageLastText[pageLastPointer][its], pageText[its], 25);
                }

                if(memcmp(pageText[its], "#L", 2) != 0)
                {
                    strLine[ianz] = pageText[its];
                    ianz++;
                }
            }

            #if defined(HAS_TFT) || defined(HAS_TFT_114) || defined(HAS_TFT_CONNECT)
            displayTFT(strLine[0], strLine[1], strLine[2], strLine[3], strLine[4], strLine[5], 0);
            #endif
        }

        #elif defined (BOARD_T_ECHO)
        // extra source
        #elif defined (BOARD_T5_EPAPER)
        // extra source
        #elif defined (BOARD_T_DECK_PRO)
        // extra source
        #elif defined (BOARD_T_CONNECT_PRO)
        // extra source
        #elif defined (BOARD_STICK_V3)
        // extra source

        INSTR_T0(t_oled);                 // OLED frame push time -> [INSTR-FLUSH]
        uint32_t t_oled_us = micros();
        bool oled_skip = false;
        u8g2->firstPage();
        do
        {
            if(pageLineAnz > 0)
            {
                int inz=0;
                
                u8g2->setFont(u8g2_font_6x10_tf);

                for(int its=0;its<pageLineAnz;its++)
                {
                    // Save last Text (init)
                    if(iDisplayType == 0 && bNeu)
                    {
                        pageLastLineAnz[pageLastPointer] = pageLineAnz;
                        pageLastLine[pageLastPointer][its][0] = pageLine[its][0];
                        pageLastLine[pageLastPointer][its][1] = pageLine[its][1];
                        pageLastLine[pageLastPointer][its][2] = pageLine[its][2];
                        memcpy(pageLastText[pageLastPointer][its], pageText[its], 25);
                    }

                    char ptext[30] = {0};
                    pageText[its][pageLine[its][2]] = 0x00;
                    
                    if(memcmp(pageText[its], "#L", 2) == 0)
                    {
                        //u8g2->drawHLine(pageLine[its][0], pageLine[its][1], 120);
                    }
                    else
                    {
                        if(its == 0)
                        {
                            if(memcmp(pageText[its], "GM", 2) == 0 || pageText[its][0] == '4')
                                snprintf(ptext, sizeof(ptext), "%-10.10s", pageText[its]+6);
                            else
                                snprintf(ptext, sizeof(ptext), "%-10.10s", pageText[its]);
                        }
                        else
                        {
                            if(memcmp(pageText[its], "LAT:", 4) == 0)
                                snprintf(ptext, sizeof(ptext), "%-4.4s %-5.5s", pageText[its]+5, pageText[its+1]+4);
                            else
                            if(pageText[its][5] == ':')
                                snprintf(ptext, sizeof(ptext), "%-10.10s", pageText[its]+7);
                            else
                                snprintf(ptext, sizeof(ptext), "%-10.10s", pageText[its]);
                        }

                        if(pageLine[its][1] >= 0)
                        {
                            if(dzeile[inz] > 0)
                                u8g2->drawStr(36, dzeile[inz], ptext);
                        }
                        
                        inz++;
                    }
                }

            }

            if(oledFrameUnchanged())    // TM-10: Bild identisch -> Transfer sparen
            {
                oled_skip = true;
                oled_skipped++;
                if(bOledLog)
                    Serial.printf("[OLED];skip;n;%lu;crc;%08lx;page;%d\n", (unsigned long)oled_skipped,
                                  (unsigned long)oled_last_crc, pagePointer);
                break;
            }
        } while (u8g2->nextPage());
        if(!oled_skip)
        {
            INSTR_FLUSH(t_oled);
            oled_last_frame_us = micros() - t_oled_us;
            oled_frames++;
            if(bOledLog)
                Serial.printf("[OLED];frame;us;%lu;n;%lu;page;%d;last;%d;lines;%d;crc;%08lx;skipped;%lu\n", (unsigned long)oled_last_frame_us,
                              (unsigned long)oled_frames, pagePointer, pageLastPointer, pageLineAnz,
                              (unsigned long)oled_last_crc, (unsigned long)oled_skipped);
        }

        #else
        
        INSTR_T0(t_oled);                 // OLED frame push time -> [INSTR-FLUSH]
        uint32_t t_oled_us = micros();
        bool oled_skip = false;
        u8g2->firstPage();
        do
        {
            if(pageLineAnz > 0)
            {
                for(int its=0;its<pageLineAnz;its++)
                {
                    // Save last Text (init)
                    if(iDisplayType == 0 && bNeu)
                    {
                        pageLastLineAnz[pageLastPointer] = pageLineAnz;
                        pageLastLine[pageLastPointer][its][0] = pageLine[its][0];
                        pageLastLine[pageLastPointer][its][1] = pageLine[its][1];
                        pageLastLine[pageLastPointer][its][2] = pageLine[its][2];
                        memcpy(pageLastText[pageLastPointer][its], pageText[its], 25);
                    }

                    char ptext[30] = {0};
                    pageText[its][pageLine[its][2]] = 0x00;
                    
                    if(memcmp(pageText[its], "#L", 2) == 0)
                    {
                        #if not defined(BOARD_T3S3_V13)
                        u8g2->drawHLine(pageLine[its][0], pageLine[its][1], 120);
                        #endif
                    }
                    else
                    {
                        snprintf(ptext, sizeof(ptext), "%s", pageText[its]);
                        if(pageLine[its][1] >= 0)
                            u8g2->drawStr(pageLine[its][0], pageLine[its][1], ptext);   // Latin-1 bytes (CHARS-01)
                    }
                }

            }

            if(oledFrameUnchanged())    // TM-10: Bild identisch -> Transfer sparen
            {
                oled_skip = true;
                oled_skipped++;
                if(bOledLog)
                    Serial.printf("[OLED];skip;n;%lu;crc;%08lx;page;%d\n", (unsigned long)oled_skipped,
                                  (unsigned long)oled_last_crc, pagePointer);
                break;
            }
        } while (u8g2->nextPage());
        if(!oled_skip)
        {
            INSTR_FLUSH(t_oled);
            oled_last_frame_us = micros() - t_oled_us;
            oled_frames++;
            if(bOledLog)
                Serial.printf("[OLED];frame;us;%lu;n;%lu;page;%d;last;%d;lines;%d;crc;%08lx;skipped;%lu\n", (unsigned long)oled_last_frame_us,
                              (unsigned long)oled_frames, pagePointer, pageLastPointer, pageLineAnz,
                              (unsigned long)oled_last_crc, (unsigned long)oled_skipped);
        }
        
        #endif

        if(iDisplayType == 0 && bNeu)
        {
            pagePointer=pageLastPointer;

            pageLastPointer++;
            if(pageLastPointer >= PAGE_MAX)
                pageLastPointer=0;

            pageLastLineAnz[pageLastPointer] = 0;   // nÄ‚Â¤chsten Ringplatz frei machen
        }
    }

    #endif
}

// Bench-Harness: Seitenzustand des OLED in einer Zeile
void oledStat()
{
    Serial.printf("[OLEDSTAT];page;%d;last;%d;hold;%d;lines;%d;info;%d;track;%d;off;%d;isoff;%d;type;%d;frames;%lu;last_us;%lu;posdisp;%d;offwait_ms;%ld;u8g2;%d;crc;%08lx;skipped;%lu\n",
                  pagePointer, pageLastPointer, pageHold,
                  (pagePointer >= 0 && pagePointer < PAGE_MAX) ? pageLastLineAnz[pagePointer] : -1,
                  bDisplayInfo ? 1 : 0, bDisplayTrack ? 1 : 0, bDisplayOff ? 1 : 0, bDisplayIsOff ? 1 : 0,
                  iDisplayType, (unsigned long)oled_frames, (unsigned long)oled_last_frame_us,
                  bPosDisplay ? 1 : 0,
                  DisplayOffWait > 0 ? (long)((int32_t)(DisplayOffWait - millis())) : 0L,
    #if MC_HAS_U8G2   // GRD-01: war die wortgleiche 11-Term-Liste
                  u8g2 != NULL ? 1 : 0
    #else
                  -1
    #endif
                  , (unsigned long)oled_last_crc, (unsigned long)oled_skipped);
}

void sendDisplayHead(bool bInit)
{
    if((bSetDisplay || pageHold > 0) && !bInit)
        return;

    bSetDisplay=true;

    #if defined(WP_DISP)
    wpMsgIdx = 0;       // Home/Info-Seite -> keine Nachrichten-Ziffer oben rechts
    #endif

    #ifdef BOARD_T5_EPAPER
        bSetDisplay=false;
        return;
    #endif

    if(bDisplayIsOff)
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, HIGH);   // TFT OFF
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
            ledcAttachPin(SCREEN_BL, 0);
        #endif

        sendDisplay1306(true, true, 0, 0, (char*)"#C");
        bSetDisplay=false;
        return;
    }
    else
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, LOW);   // TFT ON
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
            ledcAttachPin(SCREEN_BL, 1);
        #endif
    }

    #if defined(BOARD_HELTEC_T114)
    digitalWrite(PIN_TFT_LEDA_CTL, LOW);   // TFT ON
    #endif

    #if defined(BOARD_T_CONNECT_PRO)
        ledcAttachPin(SCREEN_BL, 1);
    #endif

    iDisplayType=9;

    sendDisplayMainline();

    #if defined(WP_DISP)
    // Info-Seite in EINEM Voll-Refresh aufbauen (fastmodeOff vor dem Zeichnen). Sonst
    // wuerde ein Fastmode-Partial-Update ueber ein zuvor gecleartes (weisses) Panel nichts
    // anzeigen -> die Seite bliebe leer (z.B. beim Zurueckschalten aus dem Track-Modus).
    // Schrift etwas kleiner (FreeSans 9pt statt 12pt) - mehr Platz fuer SSID/IP-Zeilen.
    epaper_display.fastmodeOff();
    epaper_display.setFont(WP_FONT9);
    #endif

    int izeile = 1;
    snprintf(msg_text, sizeof(msg_text), "CALL : %s", meshcom_settings.node_call);
    sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
    izeile++;

    snprintf(msg_text, sizeof(msg_text), "MAC  : %08X", _GW_ID);
    sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
    izeile++;

    snprintf(msg_text, sizeof(msg_text), "BLE-C: %06i", meshcom_settings.bt_code);
    sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
    izeile++;

    #if !defined (BOARD_TRACKER) && !defined (BOARD_HELTEC_T114) && !defined (BOARD_T_CONNECT_PRO) && !defined (BOARD_T_ECHO)
    if(bWIFIAP)
        snprintf(msg_text, sizeof(msg_text), "AP   : %-13.13s", meshcom_settings.node_call);
    else
    {
        #if MC_HAS_U8G2
        // CHARS-01: the SSID is user-set UTF-8; the OLED page draws Latin-1 bytes with drawStr,
        // so fold first (Latin-1 is never longer than the UTF-8, and %-15.15s can't split a letter)
        char ssidLatin1[sizeof(meshcom_settings.node_ssid) + 1];
        text_fold(meshcom_settings.node_ssid, strnlen(meshcom_settings.node_ssid, sizeof(meshcom_settings.node_ssid)),
                  ssidLatin1, sizeof(ssidLatin1), TF_LATIN1);
        snprintf(msg_text, sizeof(msg_text), "SSID : %-15.15s", ssidLatin1);
        #elif defined(WP_DISP) || defined(BOARD_E290)
        // CHARS-01: convert before %-15.15s so the width counts glyphs, not UTF-8 bytes.
        // WP info page draws in WP_FONT9 (extended -> GFX font codes, one byte per letter);
        // the E290 info page draws in FreeMonoBold12pt7b (0x20..0x7E only -> ASCII fold).
        char ssidDisp[sizeof(meshcom_settings.node_ssid) * 2 + 1];
        size_t ssidLen = strnlen(meshcom_settings.node_ssid, sizeof(meshcom_settings.node_ssid));
        #if defined(WP_DISP)
        gfx_utf8_to_font(meshcom_settings.node_ssid, ssidLen, ssidDisp, sizeof(ssidDisp));
        #else
        text_fold(meshcom_settings.node_ssid, ssidLen, ssidDisp, sizeof(ssidDisp), TF_ASCII);
        #endif
        snprintf(msg_text, sizeof(msg_text), "SSID : %-15.15s", ssidDisp);
        #else
        snprintf(msg_text, sizeof(msg_text), "SSID : %-15.15s", meshcom_settings.node_ssid);
        #endif
    }

    sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
    izeile++;

    snprintf(msg_text, sizeof(msg_text), "IP%s%s %s", (bGATEWAY?"G":""), (bWEBSERVER?"W":""), meshcom_settings.node_ip);
    sendDisplay1306(false, true, 3, dzeile[izeile], msg_text);
    izeile++;

    #else
    memset(msg_text, 0x00, sizeof(msg_text));
    sendDisplay1306(false, true, 3, dzeile[izeile], msg_text);
    izeile++;
    #endif

    bSetDisplay=false;
}

void sendDisplayTrack()
{
    if(bSetDisplay)
        return;

    bSetDisplay=true;

    #ifdef BOARD_T5_EPAPER
        bSetDisplay=false;
        return;
    #endif

    if(bDisplayIsOff)
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, HIGH);   // TFT OFF
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
            ledcAttachPin(SCREEN_BL, 0);
        #endif

        sendDisplay1306(true, true, 0, 0, (char*)"#C");
        bSetDisplay=false;
        return;
    }
    else
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, LOW);   // TFT ON
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
            ledcAttachPin(SCREEN_BL, 1);
        #endif
    }

    iDisplayType=9;

    // nur alle 15 sekunden
    if(meshcom_settings.node_date_second == 0 || meshcom_settings.node_date_second == 15 || meshcom_settings.node_date_second == 30 || meshcom_settings.node_date_second == 45 || bOneButton || bDisplayDirty)
    {
        bOneButton    = false;
        bDisplayDirty = false;

        sendDisplayMainline();

        #if defined(WP_DISP)
        // Direkt im Voll-Refresh aufbauen (fastmodeOff vor dem Zeichnen) - kein Fastmode-
        // Partial-Zwischenframe. Zusaetzlich die Track-Seite kleiner setzen (FreeSans 9pt
        // statt 12pt): die RATE-Zeile ("RATE: 1800 NEXT 1778") ist bei 12pt so breit, dass
        // println die letzte NEXT-Ziffer umbricht - der umgebrochene Rest erschien als
        // wechselnde "Geister"-Ziffer zwischen Zeile 3 und 4. Bei 9pt passt die Zeile.
        epaper_display.fastmodeOff();
        epaper_display.setFont(WP_FONT9);
        #endif

        snprintf(msg_text, sizeof(msg_text), "LAT :%.4lf %c %s", meshcom_settings.node_lat, meshcom_settings.node_lat_c, (posinfo_fix?"fix":""));
        sendDisplay1306(false, false, 3, dzeile[1], msg_text);

        snprintf(msg_text, sizeof(msg_text), "LON :%.4lf %c%4i", meshcom_settings.node_lon, meshcom_settings.node_lon_c, (int)posinfo_satcount);
        sendDisplay1306(false, false, 3, dzeile[2], msg_text);

        int pos_seconds = posinfo_interval - ((millis() - (int)posinfo_timer)) / 1000;

        #if defined(BOARD_T_ECHO)
        snprintf(msg_text, sizeof(msg_text), "RATE:%5i", (int)posinfo_interval);
        sendDisplay1306(false, false, 3, dzeile[3], msg_text);
        snprintf(msg_text, sizeof(msg_text), "NEXT:%5i", pos_seconds);
        sendDisplay1306(false, false, 3, dzeile[4], msg_text);
        #else
        #if defined(WP_DISP)
        // Kompaktere Beschriftung fuer die fette WP-Schrift (FreeSansBold ist breiter), damit die
        // Zeile nicht umbricht. E290 behaelt die ausfuehrliche Beschriftung.
        snprintf(msg_text, sizeof(msg_text), "RATE:%4i N:%4i", (int)posinfo_interval, pos_seconds);
        #else
        snprintf(msg_text, sizeof(msg_text), "RATE: %4i NEXT %4i", (int)posinfo_interval, pos_seconds);
        #endif
        sendDisplay1306(false, false, 3, dzeile[3], msg_text);
        #endif

        #if defined(BOARD_T_ECHO)
        snprintf(msg_text, sizeof(msg_text), "DIST:%5.0lf", posinfo_distance);
        sendDisplay1306(false, false, 3, dzeile[5], msg_text);
        snprintf(msg_text, sizeof(msg_text), "HDOP:%5.1f", fposinfo_hdop);
        sendDisplay1306(false, false, 3, dzeile[6], msg_text);
        #else
        snprintf(msg_text, sizeof(msg_text), "DIST:%5.0lf HDOP%5.1f", posinfo_distance, fposinfo_hdop);
        sendDisplay1306(false, false, 3, dzeile[4], msg_text);
        #endif

        #if defined(BOARD_T_ECHO)
        snprintf(msg_text, sizeof(msg_text), "DIR:old%3i new%3i", (int)posinfo_last_direction, (int)posinfo_direction);
        sendDisplay1306(false, true, 3, dzeile[7], msg_text);
        #elif defined(BOARD_TRACKER)
        memset(msg_text, 0x00, sizeof(msg_text));
        sendDisplay1306(false, true, 3, dzeile[5], msg_text);
        #else
        snprintf(msg_text, sizeof(msg_text), "DIR :old%3i new%3i", (int)posinfo_last_direction, (int)posinfo_direction);
        sendDisplay1306(false, true, 3, dzeile[5], msg_text);
        #endif
        // Hinweis: Der abschliessende sendDisplay1306(..., bTransfer=true, ...) rendert die
        // ganze Seite und ruft update() auf - da oben fastmodeOff() gesetzt wurde, ist das
        // bereits ein sauberer Voll-Refresh (kein separater Nach-Refresh noetig).
    }


    bSetDisplay=false;
}

void sendDisplayWX()
{
    if(bSetDisplay)
        return;

    bSetDisplay=true;

    #ifdef BOARD_T5_EPAPER
        bSetDisplay=false;
        return;
    #endif

    if(bDisplayIsOff)
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, HIGH);   // TFT OFF
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
            ledcAttachPin(SCREEN_BL, 0);
        #endif

        sendDisplay1306(true, true, 0, 0, (char*)"#C");
        bSetDisplay=false;
        return;
    }
    else
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, LOW);   // TFT ON
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
           ledcAttachPin(SCREEN_BL, 1);
        #endif
    }

    iDisplayType=9;

    sendDisplayMainline();

    #if MC_HAS_U8G2   // CHARS-01: u8g2 drawStr takes Latin-1 bytes, the degree sign is 0xB0 (not UTF-8 C2 B0)
    snprintf(msg_text, sizeof(msg_text), "TEMP : %.1f \xB0" "C", meshcom_settings.node_temp);
    #else
    snprintf(msg_text, sizeof(msg_text), "TEMP : %.1f Ă‚Â°C", meshcom_settings.node_temp);
    #if defined(BOARD_E290) || defined(WP_DISP)
    // CHARS-01: the WX page draws in a 12pt font (0x20..0x7E, no extended glyphs) -> "degC"
    epaper_status_ascii(msg_text, sizeof(msg_text));
    #endif
    #endif
    sendDisplay1306(false, false, 3, dzeile[1], msg_text);

    snprintf(msg_text, sizeof(msg_text), "HUM  : %.1f %%", meshcom_settings.node_hum);
    sendDisplay1306(false, false, 3, dzeile[2], msg_text);

    snprintf(msg_text, sizeof(msg_text), "QFE  : %.1f hPa", meshcom_settings.node_press);
    sendDisplay1306(false, false, 3, dzeile[3], msg_text);

    snprintf(msg_text, sizeof(msg_text), "QNH  : %.1f hPa", meshcom_settings.node_press_asl);
    sendDisplay1306(false, false, 3, dzeile[4], msg_text);

    snprintf(msg_text, sizeof(msg_text), "ALT:%5im / %5im", meshcom_settings.node_alt, meshcom_settings.node_press_alt);
    sendDisplay1306(false, true, 3, dzeile[5], msg_text);


    bSetDisplay=false;
}

void sendDisplayTime()
{
    // Button Page 5 Sekunden halten
    pageHold--;
    if(pageHold < 0)
    {
        pageHold=0;
        pagePointer=pageLastPointer-1;
        if(pagePointer < 0)
            pagePointer=PAGE_MAX-1;
    }

    #if MC_HAS_U8G2   // GRD-01: war die wortgleiche 11-Term-Liste
        if(u8g2 == NULL)
            return;
    #endif

    #if defined (HAS_EPAPER) || defined (BOARD_T_DECK)  || defined (BOARD_T_DECK_PLUS) || defined (BOARD_T5_EPAPER)
        return;
    #endif

    //TEST ONLY printfdeb("Time bDisplayOff:%i iDisplayType:%i bSetDisplay:%i\n", bDisplayOff, iDisplayType, bSetDisplay);

    if(bDisplayIsOff)
        return;

    if(iDisplayType == 0)
        return;

    if(bSetDisplay)
        return;

    bSetDisplay = true;

    #ifdef BOARD_T5_EPAPER
        bSetDisplay=false;
        return;
    #endif

    char cbatt[10];
    char cstatus[10];

    #if defined (HAS_TFT) || defined(HAS_TFT_114) || defined(HAS_TFT_CONNECT) || defined(BOARD_T_ECHO)
    if(bDisplayVolt)
        snprintf(cbatt, sizeof(cbatt), "%4.1fV", global_batt/1000.0);
    else
        snprintf(cbatt, sizeof(cbatt), "%4d%%", global_proz);
    if(global_batt == 0.0)
        snprintf(cbatt, sizeof(cbatt), " USB");
    #else
    if(bDisplayVolt)
        snprintf(cbatt, sizeof(cbatt), "%5.2fV", global_batt/1000.0);
    else
        snprintf(cbatt, sizeof(cbatt), "%5d%%", global_proz);

    if(global_batt == 0.0)
        snprintf(cbatt, sizeof(cbatt), "   USB");
    #endif

    #if defined(XPOWERS_CHIP_AXP192) || defined(HAS_EPAPER) || defined(BOARD_TBEAM_1W) || defined(BOARD_T_CONNECT_PRO)
    // [OE3WAS] 2S-Akku nom. 7.4V (LiPo = 5.0 .. 8.4 V)
    // wenn USB aber kein Akku, dann wird eine Spannung Ă˘â€°Â>2V gemessen, durch FehlstrÄ‚Â¶me erzeugt
    if(global_batt == 0.0)
        snprintf(cbatt, sizeof(cbatt), "   USB");
    #endif

    if(bGPSON)
        snprintf(cstatus, sizeof(cstatus), "G     ");
    else
        snprintf(cstatus, sizeof(cstatus), "      ");

    if(bDisplayTrack)
        cstatus[1] = 'T';

    if(!bGPSON && !bDisplayTrack)
        snprintf(cstatus, sizeof(cstatus),  "%-4.4s%-1.1s ", SOURCE_VERSION, SOURCE_VERSION_SUB);

    // nur alle 15 sekunden
    if(meshcom_settings.node_date_second == 0 || meshcom_settings.node_date_second == 15 || meshcom_settings.node_date_second == 30 || meshcom_settings.node_date_second == 45 || bOneButton || bDisplayDirty)
    {
        bOneButton    = false;
        bDisplayDirty = false;

        #ifdef BOARD_T_ECHO
        snprintf(msg_text, sizeof(msg_text), "%02i:%02i:%02i   %s", meshcom_settings.node_date_hour, meshcom_settings.node_date_minute, meshcom_settings.node_date_second, cbatt);
        #else
        snprintf(msg_text, sizeof(msg_text), "%s%02i:%02i:%02i%s", cstatus, meshcom_settings.node_date_hour, meshcom_settings.node_date_minute, meshcom_settings.node_date_second, cbatt);
        #endif

        memcpy(pageText[0], msg_text, 20);
        pageLine[0][0] = 3;
        pageLine[0][1] = dzeile[0];

        #if defined (BOARD_T5_EPAPER)
        // extra source
        #elif defined (HAS_TFT) || defined(HAS_TFT_114) || defined(HAS_TFT_CONNECT)
            displayTFT(msg_text);
        #else
            sendDisplay1306(false, true, 3, dzeile[0], msg_text);
        #endif
    }

    bSetDisplay = false;
}

void sendDisplayMainline()
{
    #if defined(WP_DISP)
    // Nachrichtenseite (0) und die zeilenreiche Positions-Anzeige (1) kompakt
    // darstellen; die Info-/Track-Seiten (9) im grossen Standardlayout. Wird hier
    // zentral umgeschaltet, da jede Seite sendDisplayMainline() nach dem Setzen
    // von iDisplayType aufruft.
    wpApplyLayout(iDisplayType == 0 || iDisplayType == 1);
    #endif

    char cbatt[10];
    char cstatus[10];
    char nodetype[5];

    #if defined (HAS_TFT) || defined(HAS_TFT_114) || defined(HAS_TFT_CONNECT) || defined(BOARD_T_ECHO)
    if(bDisplayVolt)
        snprintf(cbatt, sizeof(cbatt), "%4.1fV", global_batt/1000.0);
    else
        snprintf(cbatt, sizeof(cbatt), "%4d%%", global_proz);
    if(global_batt == 0.0)
        snprintf(cbatt, sizeof(cbatt), " USB");
    #else
    if(bDisplayVolt)
        snprintf(cbatt, sizeof(cbatt), "%5.2fV", global_batt/1000.0);
    else
        snprintf(cbatt, sizeof(cbatt), "%5d%%", global_proz);

    if(global_batt == 0.0)
        snprintf(cbatt, sizeof(cbatt), "   USB");
    #endif

    if(bGPSON)
        snprintf(cstatus, sizeof(cstatus), "G     ");
    else
        snprintf(cstatus, sizeof(cstatus), "      ");

    if(bDisplayTrack)
        cstatus[1] = 'T';

    if(!bGPSON && !bDisplayTrack)
        snprintf(cstatus, sizeof(cstatus),  "%-4.4s%-1.1s ", SOURCE_VERSION, SOURCE_VERSION_SUB);

    #if defined(XPOWERS_CHIP_AXP192) || defined(HAS_EPAPER) || defined(BOARD_TBEAM_1W) || defined(BOARD_T_CONNECT_PRO)
    // [OE3WAS] 2S-Akku nom. 7.4V (LiPo = 5.0 .. 8.4 V)
    // wenn USB aber kein Akku, dann wird eine Spannung Ă˘â€°Â>2V gemessen, durch FehlstrÄ‚Â¶me erzeugt
    if(global_batt == 0.0)
        snprintf(cbatt, sizeof(cbatt), "   USB");
    #endif

    if(meshcom_settings.node_date_hour == 0 && meshcom_settings.node_date_minute == 0 && meshcom_settings.node_date_second == 0)
    {
        #ifdef BOARD_T_ECHO
        snprintf(msg_text, sizeof(msg_text), "%-1.1s %s%s", nodetype, cstatus, cbatt);
        #else
        snprintf(msg_text, sizeof(msg_text), "%-1.1s %s      %s", nodetype, cstatus, cbatt);
        #endif
    }
    else
    {
        #ifdef BOARD_T_ECHO
        snprintf(msg_text, sizeof(msg_text), "%02i:%02i:%02i    %s", meshcom_settings.node_date_hour, meshcom_settings.node_date_minute, meshcom_settings.node_date_second, cbatt);
        #else
        snprintf(msg_text, sizeof(msg_text), "%s%02i:%02i:%02i%s", cstatus, meshcom_settings.node_date_hour, meshcom_settings.node_date_minute, meshcom_settings.node_date_second, cbatt);
        #endif
    }

    sendDisplay1306(true, false, 3, dzeile[0], msg_text);
    sendDisplay1306(false, false, 3, dzeile[0]+3, (char*)"#L");
}

#if defined(WP_DISP)
// Zeichnet die Nachrichten-Ziffer oben rechts (neueste=N..aelteste=1) in den Framebuffer.
// Muss VOR jedem update() der obersten Zeile aufgerufen werden (wpShowStoredMessage UND
// wpRefreshClock), sonst loescht der 10-s-Statuszeilen-Refresh die Ziffer weg.
static void wpDrawMsgIdx()
{
    if(wpMsgIdx <= 0) return;
    char d = '0' + (char)(wpMsgIdx > 9 ? 9 : wpMsgIdx);
    epaper_display.fillRect(236, 0, 14, dzeile[0] + 3, WHITE);   // Ecke oben rechts freiraeumen
    epaper_display.setFont(WP_FONT9);
    epaper_display.setCursor(238, dzeile[0]);
    epaper_display.print(d);
}

// Aktualisiert NUR die obere Statuszeile (Uhrzeit/Akku) per Teilbereich-Refresh
// (setWindow). Der darunterliegende Seiteninhalt bleibt unberuehrt. Wird alle 10 s
// aufgerufen - sekuendliches Voll-Update waere auf E-Ink Verschleiss und unnoetig.
void wpRefreshClock()
{
    // Panel-Unterscheidung fuer die Statuszeilen-Aktualisierung (Uhr/Akku):
    //  - V1.2 (E0213A367, SSD1680): hat ein echtes Hardware-Fenster -> schneller TEIL-Refresh
    //    nur der obersten 16px, KEIN Blitzen. Alle 10 s.
    //  - V1.1 (LCMEN2R13EFC1): unterstuetzt KEIN partielles Fenster -> jeder update() ist ein
    //    VOLL-Refresh des GANZEN Panels.
    //
    // *** E-INK-LEBENSDAUER (wichtig!) ***
    // Ein Voll-Refresh laesst das gesamte Panel kurz schwarz/weiss durchblitzen und belastet
    // die E-Ink-Zellen deutlich staerker als ein Teil-Refresh. Deshalb wird die Uhr auf V1.1
    // NUR alle 60 s (1x pro Minute) per Voll-Refresh aktualisiert - haeufigere Voll-Refreshes
    // wuerden die Display-Lebensdauer spuerbar verkuerzen. Auf V1.2 bleibt es beim schonenden
    // 10-s-Teil-Refresh.
    // E213 hat das E0213A367 (= WP V1.2) -> partial-window/Teilrefresh moeglich (Uhr alle 10 s ohne
    // Blitzen). bV11 nur fuer das LCMEN2R13EFC1-Panel (WP V1.1, kein partielles Fenster). Der
    // wait()-Timeout in BaseDisplay sichert gegen ein etwaiges Haengen ab.
    const bool bV11 = (memcmp(g_wp_panel_name, "LCMEN", 5) == 0);

    // Wechsel der Batterieanzeige VOLT<->PROZ (bDisplayVolt, via --volt/--proz oder Web-Client)
    // loest selbst KEINEN Display-Refresh aus. Auf V1.2 faengt das der 10-s-Teilrefresh ab; auf
    // V1.1 wuerde die alte Anzeige sonst bis zum 60-s-Voll-Refresh stehen bleiben und die neue
    // Zeile ueberlagern. Daher den Wechsel erkennen und auf V1.1 den 60-s-Gate ausnahmsweise
    // ueberspringen (naechster 10-s-Aufruf refresht dann sauber via fillRect). lastVolt wird bei
    // JEDEM Aufruf nachgefuehrt (auch auf off-minute-Aufruf, der sonst frueh zurueckkehrt).
    static bool lastVolt = false;
    static bool voltInit  = false;
    const bool voltChanged = voltInit && (lastVolt != bDisplayVolt);
    lastVolt = bDisplayVolt;
    voltInit = true;

    if(bV11 && meshcom_settings.node_date_second != 0 && !voltChanged)   // V1.1: sonst nur zum Minutenwechsel (= 60 s)
        return;

    char cbatt[10];
    char cstatus[10];

    if(bDisplayVolt)
        snprintf(cbatt, sizeof(cbatt), "%5.2fV", global_batt/1000.0);
    else
        snprintf(cbatt, sizeof(cbatt), "%5d%%", global_proz);

    if(global_batt == 0.0)
        snprintf(cbatt, sizeof(cbatt), "   USB");

    if(bGPSON)
        snprintf(cstatus, sizeof(cstatus), "G  ");
    else
        snprintf(cstatus, sizeof(cstatus), "   ");

    if(bDisplayTrack)
        cstatus[1] = 'T';

    if(!bGPSON && !bDisplayTrack)
        snprintf(cstatus, sizeof(cstatus),  "%-4.4s%-1.1s ", SOURCE_VERSION, SOURCE_VERSION_SUB);

    char st[40];
    snprintf(st, sizeof(st), "%s%02i:%02i:%02i%s", cstatus,
             meshcom_settings.node_date_hour, meshcom_settings.node_date_minute,
             meshcom_settings.node_date_second, cbatt);

    if(bV11)
    {
        // V1.1: KEIN partial-window. setWindow waere destruktiv (loescht beim Zuruecksetzen den
        // Framebuffer -> Seiteninhalt weg). Stattdessen nur die Statuszeilen-Region im
        // persistenten Framebuffer mit einem weissen Balken loeschen (fillRect), neu beschriften
        // und dann das GANZE Panel voll-refreshen. Der Seiteninhalt unter der Trennlinie bleibt
        // dank PRESERVE_IMAGE erhalten. Balkenhoehe knapp unter der Trennlinie (compact y=17,
        // sonst y=22), damit diese stehen bleibt.
        epaper_display.fastmodeOff();
        epaper_display.fillRect(0, 0, 250, bWpCompactLayout ? 16 : 21, WHITE);
        epaper_display.setFont(WP_FONT9);
        epaper_display.setCursor(3, dzeile[0]);
        epaper_display.print(st);
        wpDrawMsgIdx();                 // Nachrichten-Ziffer oben rechts erhalten
        epaper_display.update();        // Voll-Refresh: Status neu + Seiteninhalt intakt (Panel blitzt kurz)
    }
    else
    {
        // V1.2 (SSD1680): schneller Teil-Refresh nur der obersten 16px - kein Blitzen.
        // Fensterhoehe exakt 16px; Trennlinie (y=22) und erste Textzeile bleiben unberuehrt.
        epaper_display.setWindow(0, 0, 250, 16);
        epaper_display.fastmodeOn();
        epaper_display.clearMemory();
        epaper_display.setFont(WP_FONT9);   // durchgehend 9pt (alle WP-Seiten sind 9pt)
        epaper_display.setCursor(3, dzeile[0]);
        epaper_display.print(st);
        wpDrawMsgIdx();                 // Nachrichten-Ziffer oben rechts erhalten
        epaper_display.update();
        epaper_display.setWindow(0, 0, 250, 122);   // zurueck auf Vollbild (HW-Fenster maskiert den clear)
    }
}

// Zeigt eine im Ringpuffer gespeicherte Nachricht (Slot) an - aufgerufen vom 1x-Klick-Browse
// (singleClick) der Wireless Paper. Liegt bewusst hier, weil onebutton_functions.cpp keinen
// Zugriff auf epaper_display / wpApplyLayout hat.
// WICHTIG gegen den Status->Nachricht-Fehler:
//  - wpApplyLayout(true) erzwingt das KOMPAKTE Layout (WP_FONT9 = 9pt fett). Frueher lief der
//    Render mit iDisplayType=9 (non-compact) -> Statuszeile wurde 12pt "im alten Stil".
//  - fastmodeOff()+update() schiebt einen VOLL-Refresh nach. Der "#N"-Fastmode-Partial alleine
//    liess den zuvor angezeigten Status-Screen durchscheinen (Display "nicht geloescht").
void wpShowStoredMessage(int slot, int idx)
{
    iDisplayType = 0;            // Nachrichtenseite (kompakt)
    wpApplyLayout(true);         // kompaktes Layout -> 9pt fett, enge Zeilen
    bDisplayIsOff = false;

    pageLineAnz = pageLastLineAnz[slot];
    for(int its = 0; its < pageLineAnz; its++)
    {
        pageLine[its][0] = pageLastLine[slot][its][0];
        pageLine[its][1] = pageLastLine[slot][its][1];
        pageLine[its][2] = pageLastLine[slot][its][2];
        memcpy(pageText[its], pageLastText[slot][its], 25);
    }
    // Defensiv (analog sendDisplayText weiter unten): strncpy garantiert KEINE Terminierung,
    // wenn die Quelle die volle Puffergroesse fuellt -> mit sizeof()-1 kopieren und das letzte
    // Byte explizit auf '\0' setzen.
    strncpy(pageTextLong1, pageLastTextLong1[slot], sizeof(pageTextLong1) - 1);
    pageTextLong1[sizeof(pageTextLong1) - 1] = '\0';
    strncpy(pageTextLong2, pageLastTextLong2[slot], sizeof(pageTextLong2) - 1);
    pageTextLong2[sizeof(pageTextLong2) - 1] = '\0';

    sendDisplay1306(false, true, 0, 0, (char*)"#N");

    // Index oben rechts: neueste Meldung = N (max 9), je aelter desto kleiner, bis 1 (aelteste);
    // 0 = Home-Screen. Global merken, damit der 10-s-wpRefreshClock die Ziffer NICHT wegloescht
    // (er zeichnet sie via wpDrawMsgIdx() jedes Mal mit).
    wpMsgIdx = idx;
    wpDrawMsgIdx();                  // VOR dem Voll-Refresh in den Framebuffer

    epaper_display.fastmodeOff();   // Voll-Refresh nachschieben -> Status-Screen physisch weg
    epaper_display.update();
}


// E-Ink beim Deepsleep loeschen (Voll-Clear). Zwei Faelle:
//  - LOW-VOLTAGE-Deepsleep (bWpAkkuLow): "AKKU LOW" + die letzten Spannungs-Rohwerte anzeigen
//    (zur Beobachtung; E-Ink haelt das Bild auch im Schlaf -> bleibt ablesbar).
//  - MANUELLER Button-Deepsleep: nur loeschen (kein Text - das Original kennt keinen).
// Hintergrund: "Display off" ergibt auf E-Ink keinen Sinn (bistabil, zieht statisch keinen Strom);
// ohne Clear bliebe das letzte Bild stehen und der Sleep waere nicht erkennbar. Aufwecken per RESET.
void wpShowDeepSleep()
{
    iDisplayType = 0;
    wpApplyLayout(true);
    epaper_display.fastmodeOff();
    // Nur den Framebuffer leeren (KEIN eigener Panel-Refresh). clear() wuerde intern activate()
    // ausfuehren -> zusammen mit dem update() unten waeren das ZWEI Voll-Refreshes direkt
    // hintereinander. Bei fast leerem Akku reicht die Boost-Spannung dann nicht fuer beide ->
    // das zweite (mit "AKKU LOW" + Werten) wird grau/unvollstaendig. clearMemory() + EIN update()
    // = nur ein Refresh -> halber Stromhunger, Werte bleiben sichtbar.
    epaper_display.clearMemory();
    #if defined(BOARD_WIRELESS_PAPER)
    // WP-spezifische AKKU-LOW-Anzeige (Spannungs-History aus batt_functions). Der E213 nutzt den
    // gemeinsamen Display-Pfad (WP_DISP) mit, hat aber eine andere Akku-Mess-Logik (ADC_CTRL=46) -
    // daher hier kein bWpAkkuLow/wpBattHistory fuer E213.
    if(bWpAkkuLow)
    {
        epaper_display.setFont(WP_FONT9);
        epaper_display.setCursor(3, dzeile[0]);
        epaper_display.print("AKKU LOW");
        float h[WP_VHIST_MAX];
        int n = wpBattHistory(h, WP_VHIST_MAX);   // letzte Werte, neueste zuerst
        char ln[48];
        int row = 1;
        for(int i = 0; i < n && row <= 5; row++)
        {
            ln[0] = '\0';
            for(int k = 0; k < 3 && i < n; k++, i++)
            {
                char one[14];
                snprintf(one, sizeof(one), "%s%.2fV", (k ? "  " : ""), h[i]);
                strncat(ln, one, sizeof(ln) - strlen(ln) - 1);
            }
            epaper_display.setCursor(3, dzeile[row]);
            epaper_display.print(ln);
        }
        bWpAkkuLow = false;
    }
    #endif
    epaper_display.update();                  // Voll-Refresh -> sichtbar (haelt im Schlaf)
}
#endif

void mainStartTimeLoop()
{
    /////////////////////////////////////////////////////////////////////////////////////////////
    // Start-Loop & Time-Loop

    //if(iInitDisplay > 0)
    //    printfdeb("iInitDisplay %i meshcom_settings.node_date_second %i DisplayTimeWait %i\n", iInitDisplay, meshcom_settings.node_date_second, DisplayTimeWait);

    if(iInitDisplay < 4)
    {
        if(meshcom_settings.node_date_second != DisplayTimeWait)
        {
            iInitDisplay++;

            DisplayTimeWait = meshcom_settings.node_date_second;
        }
    }
    else
    if(iInitDisplay < 8)
    {
        if(iInitDisplay == 4)
        {
            bDisplayIsOff = false;

            #if !defined(WP_DISP)
            sendDisplayHead(true);
            #else
            // E-Ink (Wireless Paper): den ERSTEN von zwei Boot-Aufbauten ueberspringen.
            // Das Original zeichnet die Info-Seite bei iInitDisplay==4 UND ==8 - auf E-Ink sind
            // das ZWEI sichtbare Voll-Refreshes (Blitzen/Verschleiss). Wir lassen nur den zweiten
            // (==8) stehen: gleiche End-Zeit, aber nur EIN Refresh - und mit vollstaendigeren
            // Daten (IP/Zeit sind bis dahin eher verfuegbar).
            #endif

            bDisplayIsOff = bDisplayOff;

            DisplayTimeWait=0;
        }

        if(meshcom_settings.node_date_second != DisplayTimeWait)
        {
            iInitDisplay++;

            DisplayTimeWait = meshcom_settings.node_date_second;
        }
    }
    else
        if(iInitDisplay == 8)
        {
            sendDisplayHead(true);

            DisplayTimeWait=0;

            iInitDisplay = 9;
        }
        else
        {
            if (meshcom_settings.node_date_second != DisplayTimeWait)
            {
                if(bBMEON || bBMPON)
                {
                    iDisplayChange++;
                    if(iDisplayChange > 15)
                        iDisplayChange=1;
                }

                #if defined(WP_DISP)
                // E-Ink: Beim Umschalten des Track-Modus den Bildschirm physisch loeschen
                // und sofort die passende Seite neu aufbauen. Sonst (a) schreibt die
                // Track-Seite beim Einschalten ueber den alten Inhalt und (b) bleibt beim
                // Ausschalten die alte Track-Seite stehen (es laeuft nur noch wpRefreshClock
                // fuer die oberste Zeile, der Hauptbereich wird nie neu gezeichnet).
                static int wpLastTrack = -1;
                if(wpLastTrack != (int)bDisplayTrack)
                {
                    if(wpLastTrack != -1)
                    {
                        epaper_display.clear();          // physischer Voll-Clear (weiss)
                        if(bDisplayTrack)
                            bDisplayDirty = true;        // Track-Seite sofort aufbauen (kein Tastendruck)
                        else
                            sendDisplayHead(true);       // normale Info-Seite wiederherstellen
                    }
                    wpLastTrack = (int)bDisplayTrack;
                }

                // E-Ink behaelt sein Bild auch im "aus"-Zustand (anders als OLED). Beim Wechsel
                // auf bDisplayIsOff den Schirm daher physisch loeschen (--display off -> weiss).
                // Das Wieder-Anzeigen bei --display on uebernimmt der Befehl selbst
                // (sendDisplayHead). wpRefreshClock wird im aus-Zustand uebersprungen (s. unten).
                static int wpLastOff = -1;
                if(wpLastOff != (int)bDisplayIsOff)
                {
                    if(wpLastOff != -1)
                    {
                        if(bDisplayIsOff)
                            epaper_display.clear();      // --display off -> Panel physisch weiss
                        else
                            // --display on -> Info-Seite KOMPLETT neu aufbauen. bInit=true umgeht
                            // den pageHold/bSetDisplay-Guard in sendDisplayHead (der sonst nur die
                            // Statuszeile via wpRefreshClock durchkommen liesse).
                            sendDisplayHead(true);
                    }
                    wpLastOff = (int)bDisplayIsOff;
                }
                #endif

                if(bDisplayTrack)
                {
                    #if defined(WP_DISP)
                    // ============================================================================
                    // Konsequente Tracking-Anzeige-Logik fuer die GPS-LOSE Wireless Paper
                    // ----------------------------------------------------------------------------
                    // BEDEUTUNG DES FIX:
                    // Die Track-Seite ist eine POSITIONS-Anzeige (LAT/LON/RATE/NEXT/...). Sie ist
                    // nur dann sinnvoll, wenn tatsaechlich eine neue Position vorliegt. Die WP hat
                    // KEINEN GPS-Empfaenger, d.h. posinfo_fix wird nie true (gps_functions.cpp).
                    //
                    // Das spiegelt EXAKT die bereits vorhandene SENDE-Logik wider: sendPosition()
                    // sendet eine Track-Position ebenfalls nur mit echtem Positionsbezug
                    //   if(bDisplayTrack && posinfo_fix) { via APRS ... }   (s. weiter unten).
                    // Die ANZEIGE-Weiche hatte diese Bedingung bisher NICHT und hat die Track-Seite
                    // bedingungslos alle 15 s per Voll-Refresh erzwungen -> die Nachrichtenseite
                    // verschwand staendig und das E-Ink wurde unnoetig abgenutzt.
                    //
                    // KONSEQUENTE UMSETZUNG (Anzeige = Senden):
                    // Die Track-Seite wird nur (neu) gezeichnet, wenn ein ECHTES Positionsupdate
                    // vorliegt = die eigenen Koordinaten (node_lat/node_lon) haben sich seit dem
                    // letzten Track-Render geaendert. Quelle eines Updates auf der GPS-losen WP:
                    // Phone-App/BLE (phone_commands.cpp), empfangenes Mesh-Pos-Paket bzw. manuelles
                    // --setlat/--setlon (command_functions.cpp) - oder, auf GPS-Modulen, ein Fix.
                    // Die Track-Seite wird beim Einschalten (bDisplayDirty aus dem Track-Transition-
                    // Handler weiter oben) und bei jedem echten Positionsupdate fuer ~10 s gezeigt
                    // und blendet danach AUTOMATISCH zurueck auf die Normalansicht (neueste
                    // Nachricht; ersatzweise Info-/Statusseite). Grund: auf der GPS-losen WP aendern
                    // sich die Koordinaten praktisch nie - eine DAUERHAFTE Track-Seite waere statisch
                    // und sinnlos und wuerde die Nachrichtenansicht verdecken. (Bei GPS-Modulen mit
                    // sekuendlichem RATE/NEXT-Countdown ist die Dauer-Ansicht sinnvoll - daher gilt
                    // diese Rueckblende bewusst nur fuer die WP.)
                    // Solange kein neues Update kommt, bleibt die Normalansicht stehen, nur die Uhr in
                    // der Statuszeile wird (alle 10 s, E-Ink-schonend) aktualisiert. sendDisplayText
                    // kennt keinen Track-Guard -> eingehende Nachrichten erscheinen auch bei Track an.
                    // ============================================================================
                    static double        wpTrackLat     = 0.0;
                    static double        wpTrackLon      = 0.0;
                    static bool          wpTrackInit     = false;
                    static unsigned long wpTrackShownAt  = 0;   // millis() des letzten Track-Aufbaus (0 = aktuell keine Track-Seite sichtbar)

                    bool wpPosUpdated = (!wpTrackInit)
                                     || (meshcom_settings.node_lat != wpTrackLat)
                                     || (meshcom_settings.node_lon != wpTrackLon);

                    if(DisplayOffWait == 0 && (wpPosUpdated || bOneButton || bDisplayDirty))
                    {
                        // echtes Positionsupdate (oder erstmaliger Aufbau): Track-/WX-Seite zeichnen
                        // und den 10s-Rueckblende-Timer (neu) starten.
                        wpTrackLat     = meshcom_settings.node_lat;
                        wpTrackLon     = meshcom_settings.node_lon;
                        wpTrackInit    = true;
                        wpTrackShownAt = millis();
                        bDisplayDirty  = true;   // erzwingt sofortigen Aufbau (umgeht das 15s-Raster in sendDisplayTrack)

                        if(iDisplayChange > 10)
                            sendDisplayWX(); // Show WX
                        else
                            sendDisplayTrack(); // Show Track
                    }
                    else if(wpTrackShownAt != 0 && (millis() - wpTrackShownAt) >= 10000
                            && DisplayOffWait == 0 && !bDisplayIsOff)
                    {
                        // Track-Seite war ~10 s sichtbar und es kam KEIN neues Update -> automatisch
                        // zurueck auf die Normalansicht: neueste gespeicherte Nachricht, ersatzweise
                        // (noch keine Nachricht vorhanden) die Info-/Statusseite.
                        wpTrackShownAt = 0;

                        int wpNewest = pageLastPointer - 1;
                        if(wpNewest < 0) wpNewest += PAGE_MAX;

                        if(pageLastLineAnz[wpNewest] != 0)
                        {
                            // Index oben rechts = N (neueste Meldung): Anzahl belegter Slots
                            int wpRank = 0, s = wpNewest;
                            for(int n = 0; n < PAGE_MAX; n++)
                            {
                                if(pageLastLineAnz[s] == 0) break;
                                wpRank++;
                                s--; if(s < 0) s += PAGE_MAX;
                            }
                            wpShowStoredMessage(wpNewest, wpRank);
                        }
                        else
                            sendDisplayHead(true);
                    }
                    else if(!bDisplayIsOff && meshcom_settings.node_date_second % 10 == 0)
                    {
                        // weder neues Update noch faellige Rueckblende -> Normalansicht stehen lassen,
                        // nur die Uhr in der Statuszeile auffrischen.
                        wpRefreshClock();
                    }
                    #else
                    if(DisplayOffWait == 0)
                    {
                        if(iDisplayChange > 10)
                            sendDisplayWX(); // Show WX
                        else
                            sendDisplayTrack(); // Show Track
                    }
                    #endif
                }
                else
                {
                    #if defined(WP_DISP)
                    // E-Ink schonen: Uhrzeit nur alle 10 s aktualisieren (Teilbereich-Refresh
                    // der Statuszeile), statt sekuendlich. sendDisplayTime() ist fuer E-Paper
                    // ohnehin deaktiviert. Im aus-Zustand (--display off) NICHT refreshen.
                    if(!bDisplayIsOff && meshcom_settings.node_date_second % 10 == 0)
                        wpRefreshClock();
                    #else
                    if(meshcom_settings.node_pingcall[0] == 0x00 || meshcom_settings.node_pingtime == 0 || meshcom_settings.node_pingcount == 0)
                        sendDisplayTime(); // Time only
                    #endif
                }

                #if defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS)
                tdeck_update_time_label();
                #endif

                DisplayTimeWait = meshcom_settings.node_date_second;
            }
            else
            {
                bPosDisplay=true;
            }
        }
    // End Start-Loop & Time-Loop
    /////////////////////////////////////////////////////////////////////////////////////////////
}


void sendDisplayText(struct aprsMessage &aprsmsg, int16_t rssi, int8_t snr)
{
    // Fernwirken
    // {MCP}xA0yaazppppp
    // ppppp ... password (PWLFD)
    // S1 ... A0 switch A0-7 B0-7
    // aa ... ON or OF

    char cset[30];
    char cdur[30];
    char cmsg[30];

    if(mcStartsWith(aprsmsg.msg_payload, "{ping}") > 0)
    {
        return;
    }
    else
    if(mcStartsWith(aprsmsg.msg_payload, "{pong}") > 0)
    {
        // R2-04: war msg_payload.substring(14,17). substring() KLEMMT, wenn die
        // Zeichenkette kuerzer als 14 ist, und liefert "". Ein blankes
        // `msg_payload + 14` tut das nicht -- die Wache oben prueft nur das
        // Praefix "{pong}" (6 Zeichen), eine genau so lange Nutzlast wuerde also
        // hinter dem Terminator weiterlesen. Innerhalb des Feldes, aber
        // uninitialisiert: statt nichts stuende dort Muell. Die Klemmung bleibt.
        const char *cPongId = (strlen(aprsmsg.msg_payload) > 14) ? aprsmsg.msg_payload + 14 : "";

        printfdeb("[PONG] from:%s <%.3s> rssi:%i snr:%i\n", aprsmsg.msg_source_call, cPongId, rssi, snr);

        snprintf(cmsg, sizeof(cmsg), "PONG %.3s", cPongId);
        snprintf(cset, sizeof(cset), "R:%i S:%i", rssi, snr);

        meshcom_settings.node_pingduration = millis() - meshcom_settings.node_pingduration;
        float fdur = meshcom_settings.node_pingduration;
        fdur=fdur/1000;
        snprintf(cdur, sizeof(cdur), "D:%.3f s", fdur);

        DisplayPong((char*)cmsg, (char*)aprsmsg.msg_source_call, (char*)cset, (char*)cdur);

        // text immer meshcom_settings.node_pingtime stehenlassen und Display immer ON
        DisplayOffWait = millis() + (meshcom_settings.node_pingtime * 1000);
        bDisplayIsOff=false;

        return;
    }
    else
    if(mcStartsWith(aprsmsg.msg_payload, "{MCP}") || mcStartsWith(aprsmsg.msg_payload, "{mcp}"))
    {
        memset(cset, 0x00, sizeof(cset));

        // R2-04: Praezision statt blankem %s. Gekuerzt wurde hier immer schon
        // (snprintf ist auf sizeof(cset) begrenzt); mit fester Feldbreite
        // sieht GCC es nun und verlangt, dass es dasteht. Gelesen werden
        // ohnehin nur die Bytes 12..16 (cpasswd unten).
        snprintf(cset, sizeof(cset), "%.*s", (int)sizeof(cset) - 1, aprsmsg.msg_payload);
        char cpasswd[6];
        memcpy(cpasswd, cset+5+2+2+3, 5);

        char clfd[10];
        memset(clfd, 0x00, sizeof(clfd));
        snprintf(clfd, sizeof(clfd), "%03i", (int)(aprsmsg.msg_id & 0x3FF));   // fix: was sizeof(cset)=30 written into clfd[10] (cppcheck bufferAccessOutOfBounds)

        // check pwd
        bool bpass=true;
        for(int ip=0;ip<5;ip++)
        {
            if(cpasswd[ip] != 0x00 && bpass)
            {
                bool bp=false;
                for(int ic=0;ic<15;ic++)
                {
                    if(meshcom_settings.node_passwd[ic] == cpasswd[ip])
                        bp=true;
                }

                bpass = bp;
            }
        }

        if(bpass)
        {
            if(!(cset[5] == clfd[0] && cset[8] == clfd[1] && cset[11] == clfd[2]))
            {
                bpass=false;
                printfdeb("[MCP] wrong lfd:%s\n", clfd);
            }
        }

        if(bpass)
        {
            int iswitch = 0;
            bool bON = false;
            if(cset[6] == 'A' || cset[6] == 'B' || cset[6] == 'a' || cset[6] == 'b')
            {
                iswitch=cset[7]-0x30;
                if(iswitch >= 0 and iswitch < 8)
                {
                    if(memcmp(cset+9, "ON", 2) == 0 || memcmp(cset+9, "on", 2) == 0)
                        bON = true;

                    printfdeb("[MCP] key:%-5.5s command: %c%i %s\n", cpasswd, cset[6], iswitch, (bON?"on":"off"));

                    char cBefehl[30];
                    if(bON)
                        snprintf(cBefehl, sizeof(cBefehl), "--setout %c%i off", cset[6], iswitch);
                    else
                        snprintf(cBefehl, sizeof(cBefehl), "--setout %c%i on", cset[6], iswitch);

                    commandAction(cBefehl, false);
                }
                else
                {
                    printlndeb("[MCP] wrong switch number");
                }
            }
            else
            {
                printlndeb("[MCP] no command recognized");
            }
        }
        else
        {
            printlndeb("[MCP] wrong keyword");
        }

        return;
    }
    else
    if(mcStartsWith(aprsmsg.msg_payload, "{SET}") > 0)
    {
        char cset[30];
        // R2-04: Praezision statt blankem %s. Gekuerzt wurde hier immer schon
        // (snprintf ist auf sizeof(cset) begrenzt); mit fester Feldbreite
        // sieht GCC es nun und verlangt, dass es dasteht. Gelesen werden
        // ohnehin nur die Bytes 12..16 (cpasswd unten).
        snprintf(cset, sizeof(cset), "%.*s", (int)sizeof(cset) - 1, aprsmsg.msg_payload);

        // Ohne Bereichspruefung landete ein Tippfehler wie {SET}44;2; direkt im
        // Hop-Feld der ausgesendeten Pakete. Byte 5 einer ACK fuehrt max_hop in
        // 7 Bit, der Weiterleitungspfad dekrementiert nur und begrenzt nicht
        // nach oben -- ein solcher Knoten wuerde das Netz mit Paketen fluten,
        // die 44 statt 4 Relaissprunge weit laufen.
        //
        // Wie bisher wird jedes Feld einzeln uebernommen, sobald sscanf es
        // gelesen hat ({SET}4; setzt weiterhin nur max_hop_text). Den erlaubten
        // Bereich liefert prod_lock.h: Produktion max_hop_text 1..6 und kein
        // max_hop_pos; INSTRUMENT-Builds 0..MAX_HOP_LIMIT fuer beide Felder.
        // Ausserhalb bleibt der bisherige Wert stehen.
        int iHopText = meshcom_settings.max_hop_text;
        int iHopPos  = meshcom_settings.max_hop_pos;

        int iParsed = sscanf(cset+5, "%d;%d;", &iHopText, &iHopPos);
        const bool bInstr = (INSTRUMENT_ENABLED != 0);

        if(iParsed >= 1)
        {
            const int iNewText = prodLockSetHop(iHopText, meshcom_settings.max_hop_text, bInstr);
            if(iNewText != meshcom_settings.max_hop_text)
            {
                meshcom_settings.max_hop_text = iNewText;
                save_settings();    // max_hop_text is persistent (max_hop_pos is not)
            }
        }

        if(iParsed >= 2 && prodLockSetPosAllowed(bInstr) && iHopPos >= 0 && iHopPos <= MAX_HOP_LIMIT)
            meshcom_settings.max_hop_pos = iHopPos;

        return;
    }
    else
    if(mcStartsWith(aprsmsg.msg_payload, "{CET}") > 0)
    {
        // CET Meldungen nur annehmen wenn nichr GPS, RTC oder Handyverbindung vorhanden ist
        if(!bRTCON && !posinfo_fix && !bNTPDateTimeValid) // !!!! erst aktivieren wenn PHone regelmÄ‚Â¤ssig zeit liefert  && !bPhoneTimeValid)
        {
            uint16_t Year=2000;
            uint16_t Month=1;
            uint16_t Day=1;
            uint16_t Hour=0;
            uint16_t Minute=0;
            uint16_t Second=0;

            // {CET}2025-01-31 07:47:40
            // Trotz des Namens traegt die Nutzlast UTC, keine MEZ/MESZ (Feldbeleg:
            // "{CET}2026-09-26 18:15:14" kam um 20:15:50 MESZ an). Deshalb passt
            // setCurrentTime(node_utcoff, ...) unten.
            Year = (uint16_t)mcSliceToLong(aprsmsg.msg_payload, 5, 9);
            Month = (uint16_t)mcSliceToLong(aprsmsg.msg_payload, 10, 12);
            Day = (uint16_t)mcSliceToLong(aprsmsg.msg_payload, 13, 15);

            Hour = (uint16_t)mcSliceToLong(aprsmsg.msg_payload, 16, 18);
            Minute = (uint16_t)mcSliceToLong(aprsmsg.msg_payload, 19, 21);
            Second = (uint16_t)mcSliceToLong(aprsmsg.msg_payload, 22, 24);

            if(Year > 2023)
            {
                MyClock.setCurrentTime(meshcom_settings.node_utcoff, Year, Month, Day, Hour, Minute, Second);
                snprintf(cTimeSource, sizeof(cTimeSource), (char*)"{CET}");
            }
        }

        return;
    }
    else
    if(strcmp(aprsmsg.msg_destination_call, "100001") == 0 && !bSOFTSERREAD)
    {
        return;
    }
    else
    {
        if(!bDisplayVolt)
            bPosDisplay=false;
    }

    if(bSetDisplay)
        return;

    bSetDisplay=true;

    ///////////////////////////////////////////////////////////
    // text immer 30 sec stehenlassen und Display immer ON
    DisplayOffWait = millis() + (30 * 1000); // 30 seconds
    bDisplayIsOff=false;

    #if defined(WP_DISP)
    wpMsgIdx = 0;       // frisch eintreffende Nachricht -> kein (alter) Browse-Index oben rechts
    #endif
    //
    ///////////////////////////////////////////////////////////
    
    iDisplayType = 0;

    #ifdef BOARD_T5_EPAPER

        int cursor_x;
        int cursor_y;

        if(t5_cursor_y > 850)
        {
            disp_full_clean();

            cursor_x = 20;
            cursor_y = 50;
            disp_next_status("LORA MSG ...", &cursor_x, &cursor_y, true);

            t5_cursor_y = 50;
        }

        // 1. Zeile
        t5_cursor_y+=40;    // large font

        cursor_x = 20;
        cursor_y = t5_cursor_y;
        String strMsgT5=getTimeString()+" "+"<"+aprsmsg.msg_source_call+">"+aprsmsg.msg_destination_call;
        disp_next_status(strMsgT5, &cursor_x, &cursor_y, true);
        

        // 2. Zeile
        t5_cursor_y+=30; // small font

        cursor_x = 20;
        cursor_y = t5_cursor_y;
        strMsgT5=foldForDisplay(aprsmsg.msg_payload, TF_UTF8_LATIN1);   // FiraSans: Latin-1 + punctuation, rest folded
        disp_next_status(strMsgT5, &cursor_x, &cursor_y, false);
        
        bSetDisplay = false;

        return;

    #elif defined (BOARD_T_DECK_PRO)

        String strPath = String("M * <") + aprsmsg.msg_source_call + ">";
        
        // DM
        if(CheckGroup(aprsmsg.msg_destination_call))
        {
            strPath = String("GM ") + aprsmsg.msg_destination_call + " <" + aprsmsg.msg_source_call + ">";
        }
        else
            if(strcmp(aprsmsg.msg_destination_call, "*") != 0)
            {
                strPath = String("DM <") + aprsmsg.msg_source_call + ">";
            }

        String strAscii = foldForDisplay(aprsmsg.msg_payload, TF_ASCII);   // Font_Mono_Bold_14: 0x20-0x7F

        TDeck_pro_lora_disp(strPath, strAscii);

        // bounded copies, truncation intended (the page shows the head of the text)
        size_t n1 = strnlen(msg_text, sizeof(pageLastTextLong1[pagePointer]) - 1);
        memcpy(pageLastTextLong1[pagePointer], msg_text, n1);
        pageLastTextLong1[pagePointer][n1] = '\0';
        size_t n2 = strnlen(strAscii.c_str(), sizeof(pageLastTextLong2[pagePointer]) - 1);
        memcpy(pageLastTextLong2[pagePointer], strAscii.c_str(), n2);
        pageLastTextLong2[pagePointer][n2] = '\0';

        bSetDisplay = false;

        return;

    #elif defined (HAS_EPAPER)

    sendDisplayMainline();

    sendDisplay1306(false, true, 0, dzeile[0], (char*)"#F");    // not fastmode for CET display

    epaper_display.setCursor(0, dzeile[1]);
    epaper_display.setFont(WP_FONT9);

    String strPath = String("M* <") + aprsmsg.msg_source_call + ">";
    // DM
    if(CheckGroup(aprsmsg.msg_destination_call))
    {
        strPath = String("GM") + aprsmsg.msg_destination_call + " <" + aprsmsg.msg_source_call + ">";
    }
    else
        if(strcmp(aprsmsg.msg_destination_call, "*") != 0)
        {
            strPath = String("DM <") + aprsmsg.msg_source_call + ">";
        }

    #ifdef BOARD_T_ECHO
        snprintf(msg_text, sizeof(msg_text), "%s", strPath.c_str());
    #else
    if(strPath.length() < (20-4))
        snprintf(msg_text, sizeof(msg_text), "%s <%i>", strPath.c_str(), rssi);
    else
        snprintf(msg_text, sizeof(msg_text), "%s", strPath.c_str());
    #endif

    msg_text[20]=0x00;
    epaper_display.println(msg_text);

    epaper_display.setCursor(0, dzeile[2]);

    String strAscii = "";//aprsmsg.msg_payload;

    #if defined(BOARD_E290) || defined(WP_DISP)
    {
        // National characters: WP_FONT9 (FreeSans9pt7b / FreeSansBold9pt7b) has the glyphs at 0x80..0x9A,
        // gfx_utf8_to_font() maps UTF-8 to those codes (see gfx_charmap.h). Not listed -> folded via text_fold(TF_ASCII).
        char gfxText[sizeof(aprsmsg.msg_payload) + 1];
        gfx_utf8_to_font(aprsmsg.msg_payload, strnlen(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload)), gfxText, sizeof(gfxText));
        strAscii = String(gfxText);
    }
    #else
    strAscii = foldForDisplay(aprsmsg.msg_payload, TF_ASCII);   // T-Echo: FreeMonoBold, ASCII only
    #endif

    #if defined(WP_DISP)
    // Nachrichtentext mit kompakter Schrift (enger Zeilenabstand 15 statt 22) -> bis zu 160
    // Zeichen passen auf das Panel. Gleicher Font wie beim Durchblaettern -> Browse == Live.
    epaper_display.setFont(wpMsgFont());
    #endif

    epaper_display.println(strAscii);

    strncpy(pageLastTextLong1[pagePointer], msg_text, sizeof(pageLastTextLong1[pagePointer]) - 1);
    pageLastTextLong1[pagePointer][sizeof(pageLastTextLong1[pagePointer]) - 1] = '\0';
    strncpy(pageLastTextLong2[pagePointer], strAscii.c_str(), sizeof(pageLastTextLong2[pagePointer]) - 1);
    pageLastTextLong2[pagePointer][sizeof(pageLastTextLong2[pagePointer]) - 1] = '\0';

    #if defined(WP_DISP)
    // Neue Nachricht per Voll-Refresh aufbauen -> gestochen scharf, tiefschwarz,
    // kein Ghosting. Die schnellen Partial-Updates (Uhrzeit) bleiben unberuehrt.
    epaper_display.fastmodeOff();
    #endif
    #if defined(BOARD_E290)
    bool bE290Full = e290FullRefreshDue();   // E290: partial refresh, full one only now and then
    if(bE290Full)
        epaper_display.fastmodeOff();
    #endif
    epaper_display.update();
    #if defined(BOARD_E290)
    if(bE290Full)
        epaper_display.fastmodeOn();   // back to fastmode ON, see sendDisplay1306
    #endif

    #elif defined (BOARD_T5_EPAPER)
    // extra source
    #elif defined(BOARD_TRACKER) || defined(BOARD_HELTEC_T114)  || defined(BOARD_T_CONNECT_PRO)

    sendDisplayMainline();
    sendDisplay1306(false, true, 0, dzeile[0], (char*)"#F");    // not fastmode for CET display

    String strPath = String("M* <") + aprsmsg.msg_source_call + ">";
    // DM
    if(CheckGroup(aprsmsg.msg_destination_call))
    {
        strPath = String("GM") + aprsmsg.msg_destination_call + " <" + aprsmsg.msg_source_call + ">";
    }
    else
        if(strcmp(aprsmsg.msg_destination_call, "*") != 0)
        {
            strPath = String("DM <") + aprsmsg.msg_source_call + ">";
        }

    #if defined(BOARD_T_CONNECT_PRO)
        snprintf(msg_text, sizeof(msg_text), "%s <%i>", strPath.c_str(), rssi);
    #else
    if(strPath.length() < (20-4))
        snprintf(msg_text, sizeof(msg_text), "%s <%i>", strPath.c_str(), rssi);
    else
        snprintf(msg_text, sizeof(msg_text), "%s", strPath.c_str());
    #endif

    msg_text[20]=0x00;

    String strAscii = "";//aprsmsg.msg_payload;

    // TF_ASCII for now (no setCp437, no bench board); upgrade path for T114: TF_CP437 + setCp437(true)
    strAscii = foldForDisplay(aprsmsg.msg_payload, TF_ASCII);

    strncpy(pageLastTextLong1[pagePointer], strPath.c_str(), sizeof(pageLastTextLong1[pagePointer]) - 1);
    pageLastTextLong1[pagePointer][sizeof(pageLastTextLong1[pagePointer]) - 1] = '\0';
    strncpy(pageLastTextLong2[pagePointer], strAscii.c_str(), sizeof(pageLastTextLong2[pagePointer]) - 1);
    pageLastTextLong2[pagePointer][sizeof(pageLastTextLong2[pagePointer]) - 1] = '\0';

    displayTFT(strPath, strAscii);

    #elif defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS)
    
    tdeck_add_MSG(aprsmsg, true);
    
    #else
    
    sendDisplayMainline();

    int izeile=0;
    unsigned int itxt=0;

    bool bClear=true;

    char line_text[21];
    char words[100][21]={0};
    unsigned int iwords=0;
    int ipos=0;

    String strPath = aprsmsg.msg_source_path;
    // DM
    if(CheckGroup(aprsmsg.msg_destination_call))
    {
        strPath = String("GM") + aprsmsg.msg_destination_call + " <" + aprsmsg.msg_source_call + ">";
    }
    else
        if(strcmp(aprsmsg.msg_destination_call, "*") != 0)
        {
            strPath = String("DM <") + aprsmsg.msg_source_call + ">";
        }

    if(strlen(aprsmsg.msg_source_path) < (20-5))
        snprintf(msg_text, sizeof(msg_text), "%s <%i>", strPath.c_str(), rssi);
    else
        snprintf(msg_text, sizeof(msg_text), "%s", strPath.c_str());

    msg_text[20]=0x00;
    sendDisplay1306(bClear, false, 3, dzeile[izeile], msg_text);

    izeile++;
    bClear=false;

    // CHARS-01: u8g2 _f fonts draw one Latin-1 byte per glyph (drawStr), so fold to Latin-1 first;
    // the byte-based wrap and the 25-byte page cuts below can then no longer split a character.
#if defined(NRF52_SERIES)
    static char oledText[MC_PAYLOAD_LEN];   // N-22: 4-KB loop stack; sendDisplayText runs in one task only
#else
    char oledText[MC_PAYLOAD_LEN];
#endif
    size_t oledLen = text_fold(aprsmsg.msg_payload, strnlen(aprsmsg.msg_payload, MC_PAYLOAD_LEN), oledText, sizeof(oledText), TF_LATIN1);

    for(itxt=0; itxt<oledLen; itxt++)
    {
        words[iwords][ipos]=oledText[itxt];

        if(words[iwords][ipos] == ' ')
        {
            words[iwords][ipos]=0x00;

            if(ipos == 0)
            {
                words[iwords][ipos]=0x20;
                words[iwords][ipos+1]=0x00;
            }
            iwords++;
            if(iwords >= 100)
                iwords=99;
            ipos=0;
        }
        else
        if(ipos > 19)
        {
            words[iwords][20]=0x00;
            iwords++;
            if(iwords >= 100)
                iwords=99;
            words[iwords][0]=oledText[itxt];
            ipos=1;
        }
        else
            ipos++;
    }

    words[iwords][ipos]=0x00;
    iwords++;
    if(iwords >= 100)
    iwords=99;

    memset(line_text, 0x00, 21);
    strncat(line_text, words[0], sizeof(line_text) - strlen(line_text) - 1);

    bool bEnd=false;

    for(itxt=1; itxt<iwords; itxt++)
    {
        if((strlen(line_text) + strlen(words[itxt])) > 19)
        {
            line_text[20]=0x00;
            snprintf(msg_text,sizeof(msg_text), "%s", line_text);

            if(izeile > 5)
                bEnd=true;

            if(bEnd && itxt < iwords)
                snprintf(msg_text, sizeof(msg_text), "%-17.17s...", line_text);

            msg_text[20]=0x00;
            sendDisplay1306(bClear, bEnd, 3, dzeile[izeile], msg_text);

            izeile++;
            
            if(izeile > 5)
            {
                break;
            }

            memset(line_text, 0x00, 21);

            if(itxt+1 == iwords)
                bEnd=true;

            bClear=false;

            strncat(line_text, words[itxt], sizeof(line_text) - strlen(line_text) - 1);

        }
        else
        {
            strncat(line_text, " ", sizeof(line_text) - strlen(line_text) - 1);
            strncat(line_text, words[itxt], sizeof(line_text) - strlen(line_text) - 1);
        }
    }


    bEnd=true;

    line_text[20]=0x00;

    if(izeile > 5)
    {
        izeile=5;
        strcat(msg_text, " >>>>>>>>>>>>>>");
    }
    else
    {
        snprintf(msg_text, sizeof(msg_text), "%s", line_text);
    }

    msg_text[20]=0x00;
    //printfdeb("1306-02:%s len:%i izeile:%i\n", msg_text, strlen(msg_text), izeile);
    sendDisplay1306(bClear, bEnd, 3, dzeile[izeile], msg_text);

    #endif

    bSetDisplay=false;
}

void init_loop_function()
{
    posinfo_last_direction = 0.0;
    posinfo_satcount = 0;
    fposinfo_hdop = 0.0;
    posinfo_fix = false;

    meshcom_settings.node_vbus = 0.0f;
}

// ANALOG
void initAnalogPin()
{
    #if defined (ANALOG_PIN)

    if(bAnalogCheck)
    {
        int ANAGPIO = meshcom_settings.node_analog_pin;
        if(meshcom_settings.node_analog_pin <= 0 || meshcom_settings.node_analog_pin >= 99)
        {
            ANAGPIO = ANALOG_PIN;
            meshcom_settings.node_analog_pin = ANALOG_PIN;
            save_settings();

            printfdeb("%s [ANALOG] GPIO not set, using board default GPIO %i (--analog gpio N to change)\n", getTimeString().c_str(), ANAGPIO);
        }

        pinMode(ANAGPIO, INPUT);

        if(bDEBUG && bDisplayInfo)
        {
            printfdeb("%s [ANALOG]...GPIO%i SET\n", getTimeString().c_str(), ANAGPIO);
        }
    }
    
    #endif
}

void sendDisplayPosition(struct aprsMessage &aprsmsg, int16_t rssi, int8_t snr)
{
    (void)snr;
    //printfdeb("bPosDisplay:%i DisplayOffWait:%i bSetDisplay:%i pageHold:%i bDisplayTrack:%i bDisplayIsOff:%i\n", bPosDisplay, DisplayOffWait, bSetDisplay, pageHold, bDisplayTrack, bDisplayIsOff);

    if(!bPosDisplay)
        return;

    // wenn Textmeldung angezeigt wird dann warten bis Display off
    if(DisplayOffWait > 0)
        return;

    if(bSetDisplay || pageHold > 0 || bDisplayTrack)
        return;

    bSetDisplay=true;

    #ifdef BOARD_T5_EPAPER
        bSetDisplay=false;
        return;
    #endif

    if(bDisplayIsOff)
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, HIGH);   // TFT OFF
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
            ledcAttachPin(SCREEN_BL, 0);
        #endif

        sendDisplay1306(true, true, 0, 0, (char*)"#C");
        bSetDisplay=false;
        return;
    }
    else
    {
        #if defined(BOARD_HELTEC_T114)
        digitalWrite(PIN_TFT_LEDA_CTL, LOW);   // TFT ON
        #endif

        #if defined(BOARD_T_CONNECT_PRO)
            ledcAttachPin(SCREEN_BL, 1);
        #endif
    }


    iDisplayType=1;

    unsigned int ipt=0;

    int izeile=1;

    unsigned int itxt=0;
    int istarttext=0;

    double lat=0.0;
    double lon=0.0;

    int dir_to=0;
    char cdir_to[3];
    int dist_to=0;

    aprsPosition aprspos;

    initAPRSPOS(aprspos);

    decodeAPRSPOS(aprsmsg.msg_payload, aprspos);

    // Display Distance, Direction
    lat = conv_coord_to_dec(aprspos.lat);
    lon = conv_coord_to_dec(aprspos.lon);

    // d_dir_to wird weiter unten im HAS_EPAPER-Block (DrawDirection) genutzt - daher
    // immer deklarieren, nicht nur unter ENABLE_GPS. Sonst bricht ein E-Paper-Board
    // ohne GPS (z.B. Wireless Paper) die Kompilierung.
    float d_dir_to = 0;
    d_dir_to = gps.courseTo(meshcom_settings.node_lat, meshcom_settings.node_lon, lat, lon);
    dir_to = d_dir_to;
    dist_to = gps.distanceBetween(lat, lon, meshcom_settings.node_lat, meshcom_settings.node_lon)/1000.0;

    sendDisplayMainline();

    #ifdef HAS_EPAPER
        sendDisplay1306(false, true, 0, dzeile[0], (char*)"#S");
    #endif

    #if defined(BOARD_T_ECHO)
    snprintf(msg_text, sizeof(msg_text), "%s", aprsmsg.msg_source_call);
    msg_text[20]=0x00;
    sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
    izeile=izeile+1;

    snprintf(msg_text, sizeof(msg_text), " <>%s", aprsmsg.msg_source_last);
    msg_text[20]=0x00;
    sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
    izeile=izeile+1;
    #else
    snprintf(msg_text, sizeof(msg_text), "%s<>%s", aprsmsg.msg_source_call, aprsmsg.msg_source_last);
    msg_text[20]=0x00;
    sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
    izeile=izeile+1;
    #endif

    char scan_text[20];

    memset(scan_text, 0x00, sizeof(scan_text));
    ipt=0;

    for(itxt=0; itxt<strlen(aprsmsg.msg_payload); itxt++)
    {
        if((aprsmsg.msg_payload[itxt] == 'N' || aprsmsg.msg_payload[itxt] == 'S'))
        {
            sscanf(scan_text, "%lf", &lat);

            #if defined(BOARD_T_ECHO)
            snprintf(msg_text, sizeof(msg_text), "LAT: %s%c", scan_text, aprsmsg.msg_payload[itxt]);
            #else
            snprintf(msg_text, sizeof(msg_text), "LAT: %s%c%5ikm", scan_text, aprsmsg.msg_payload[itxt], dist_to);
            #endif
            msg_text[20]=0x00;
            sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);

            istarttext=itxt+2;
            izeile=izeile+1;
            break;
        }
        else
        {
            if(ipt < sizeof(scan_text)-1)
            {
                scan_text[ipt]=aprsmsg.msg_payload[itxt];
                ipt++;
            }
        }
    }

    memset(scan_text, 0x00, sizeof(scan_text));
    ipt=0;

    for(itxt=istarttext; itxt<strlen(aprsmsg.msg_payload); itxt++)
    {
        if((aprsmsg.msg_payload[itxt] == 'W' || aprsmsg.msg_payload[itxt] == 'E'))
        {
            sscanf(scan_text, "%lf", &lon);

            float von_dir_to[10]     = {0.0, 22.5, 67.5, 112.5, 157.5, 202.5, 247.5, 292.5, 337.5, 360.0};
            char von_c_dir_to[10][4] = {"",  "N",  "NE",  "E",  "SE",  "S",   "SW",   "W",   "NW",  "N"} ;

            for(int idir=0; idir<9; idir++)
            {
                if(dir_to >= von_dir_to[idir] && dir_to <= von_dir_to[idir+1])
                    snprintf(cdir_to, sizeof(cdir_to), "%s", von_c_dir_to[idir+1]);
            }

            #if defined(BOARD_T_ECHO)
            snprintf(msg_text, sizeof(msg_text), "LON:%s%c", scan_text, aprsmsg.msg_payload[itxt]);
            #else
            snprintf(msg_text, sizeof(msg_text), "LON:%s%c%5i%s", scan_text, aprsmsg.msg_payload[itxt], dir_to, cdir_to);
            #endif
            msg_text[20]=0x00;
            sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);

            istarttext=itxt+3;
            izeile=izeile+1;
            break;
        }
        else
        {
            if(ipt < sizeof(scan_text)-1)
            {
                scan_text[ipt]=aprsmsg.msg_payload[itxt];
                ipt++;
            }
        }
    }

    int bat = 0;
    int alt = 0;

    memset(scan_text, 0x00, sizeof(scan_text));
    ipt=0;

    // check Batt
    for(itxt=istarttext; itxt<strlen(aprsmsg.msg_payload); itxt++)
    {
        if(aprsmsg.msg_payload[itxt] == '/' && aprsmsg.msg_payload[itxt+1] == 'B' && aprsmsg.msg_payload[itxt+2] == '=')
        {
            for(unsigned int id=itxt+3;id<strlen(aprsmsg.msg_payload);id++)
            {
                // ENDE
                if(aprsmsg.msg_payload[id] == '/' || aprsmsg.msg_payload[id] == ' ' || id == strlen(aprsmsg.msg_payload))
                {
                    sscanf(scan_text, "%d", &bat);
                    break;
                }

                if(ipt < sizeof(scan_text)-1)
                {
                    scan_text[ipt]=aprsmsg.msg_payload[id];
                    ipt++;
                }
            }

            break;
        }
    }

    memset(scan_text, 0x00, sizeof(scan_text));
    ipt=0;

    #if defined(HAS_EPAPER) and not defined(BOARD_T_ECHO)

    // dir_to
    epaper_display.drawCircle(275, 107,
        20,                             // Radius: 10px
        BLACK                           // Color: black
        );

    // dir_to
    epaper_display.drawCircle(275, 107,
        19,                             // Radius: 10px
        BLACK                           // Color: black
        );

    DrawDirection(d_dir_to, 275, 107, 20);
    DrawDirection(d_dir_to, 274, 108, 20);


    #endif

    for(itxt=istarttext; itxt<strlen(aprsmsg.msg_payload); itxt++)
    {
        if(aprsmsg.msg_payload[itxt] == '/' && aprsmsg.msg_payload[itxt+1] == 'A' && aprsmsg.msg_payload[itxt+2] == '=')
        {
            for(unsigned int id=itxt+3;id<strlen(aprsmsg.msg_payload);id++)
            {
                // ENDE
                if(aprsmsg.msg_payload[id] == '/' || aprsmsg.msg_payload[id] == ' ' || id == strlen(aprsmsg.msg_payload))
                {
                    sscanf(scan_text, "%d", &alt);

                    if(aprsmsg.msg_source_fw_version > 13)
                        alt = (int)((float)alt * 0.3048);

                    #if defined(HAS_EPAPER)
                        #if not defined(BOARD_T_ECHO)
                        DrawRssi(3, 117, rssi);
                        #endif

                        snprintf(msg_text, sizeof(msg_text), "ALT:%5i m", alt);
                        msg_text[20]=0x00;
                        sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
                        izeile++;

                        snprintf(msg_text, sizeof(msg_text), "DST:%5i km", dist_to);
                        msg_text[20]=0x00;
                        sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
                        izeile++;

                        snprintf(msg_text, sizeof(msg_text), "DIR:%5i %s", dir_to, cdir_to);
                        msg_text[20]=0x00;
                        sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
                        izeile++;
                    #else
                        snprintf(msg_text, sizeof(msg_text), "ALT :%4im", alt);
                        msg_text[20]=0x00;
                        sendDisplay1306(false, false, 3, dzeile[izeile], msg_text);
                        izeile++;
                    #endif

                    break;
                }

                if(ipt < sizeof(scan_text)-1)
                {
                    scan_text[ipt]=aprsmsg.msg_payload[id];
                    ipt++;
                }
            }

            break;
        }

    }
    
    #if defined(BOARD_T3S3_V13)
    // done above
    #elif defined(BOARD_TRACKER) or defined(BOARD_HELTEC_T114)  or defined(BOARD_T_CONNECT_PRO)
    memset(msg_text, 0x00, sizeof(msg_text));
    sendDisplay1306(false, true, 3, dzeile[izeile], msg_text);
    #else
    snprintf(msg_text, sizeof(msg_text), "RSSI:%4i", rssi);
    sendDisplay1306(false, true, 3, dzeile[izeile], msg_text);
    #endif

    #if defined(WP_DISP)
    // Nach dem partiellen Aufbau einen Voll-Refresh nachschieben: loescht die zuvor
    // angezeigte Nachricht physisch (kein Ueberlagern), die Position erscheint sauber.
    epaper_display.fastmodeOff();
    epaper_display.update();
    #endif

    bSetDisplay=false;

}

#if defined(HAS_EPAPER) and not defined(BOARD_T_ECHO)
void DrawDirection(float angle, int cx, int cy, int radius)
{
    float displacedAngle = angle - 90;
    int x = cx + ((float)cos(degreesToRadians(displacedAngle)) * (radius - 3)); //convert angle to radians for x and y coordinates
    int y = cy + ((float)sin(degreesToRadians(displacedAngle)) * (radius - 3));
    
    epaper_display.drawLine(cx, cy, x, y, BLACK); //draw a line from center point back to the point
}

double degreesToRadians(double degrees)
{
    return (degrees * PI) / 180;
}

void DrawRssi(int cx, int cy, int16_t rssi)
{
    int irssi = (110 + rssi) * 2;
    
    //printfdeb("rssi:%i irssi:%i\n", rssi, irssi);

    epaper_display.fillRect(cx + 60, cy, irssi, 5, BLACK);

    epaper_display.setCursor(cx, cy + 10);
    epaper_display.printf("%i", rssi);
}
#endif

/** @brief Method to print our buffers
 */
void printBuffer(uint8_t *buffer, int len)
{
  for (int i = 0; i < len; i++)
  {
    printfdeb("%02X ", buffer[i]);
  }
  printlndeb("");
}

void printAsciiBuffer(uint8_t *buffer, int len)
{
    if(len < 4)
        return;

    if(buffer[0] != 0x21 && buffer[0] != 0x3A && buffer[0] != 0x40 && buffer[0] != 0x41)
    {
        printfdeb("LoRa starting with 0x%02X and %02X%02X%02X ... no decode\n", buffer[0], buffer[1], buffer[2], buffer[3]);
        return;
    }

    int ulen = len;
    if(ulen > 255)
        ulen = 255;

    for (int i = 0; i < ulen; i++)
    {
        if(buffer[i] < 0x20 || buffer[i] > 0x7e)
            printdeb("#");
        else
            printfdeb("%c", buffer[i]);
    }

    printlndeb("");
}

String getDateString()
{
    char currDate[11] = {0};
    snprintf(currDate, sizeof(currDate), "%04i-%02i-%02i", meshcom_settings.node_date_year, meshcom_settings.node_date_month, meshcom_settings.node_date_day);

    return (String)currDate;
}

String getTimeString()
{
    char currTime[10] = {0};
    snprintf(currTime, sizeof(currTime), "%02i:%02i:%02i", meshcom_settings.node_date_hour, meshcom_settings.node_date_minute, meshcom_settings.node_date_second);

    return (String)currTime;
}

// SL -- `HH:MM:SS [LOG] <body>` ohne die String-Allokation von
// getTimeString(): die RX-Pfade drucken zwei bis vier solcher Zeilen je Frame.
void setlogPrint(const char *body)
{
    char ts[10];
    snprintf(ts, sizeof(ts), "%02i:%02i:%02i", meshcom_settings.node_date_hour,
             meshcom_settings.node_date_minute, meshcom_settings.node_date_second);

    printfdeb("%s [LOG] %s\n", ts, body);
}

// WQ-01 (2026-09-05): queue panel on the rxlog web page -- Kopie des zuletzt
// abgeschlossenen 5-Minuten-STAT-Fensters. setlogFillStat() fuellt und
// leert die Intervallzaehler in jedem Fall auf jedem Tick (siehe unten);
// diese Kopie macht das Ergebnis danach lesbar, ohne den naechsten
// Druckaufruf abzuwarten. stat_last_window_ms == 0 heisst "seit dem Boot
// noch kein Fenster abgeschlossen".
struct setlogStatFields stat_last_window = {0};
uint32_t stat_last_window_ms = 0;

// SL-05 -- Felder der STAT-Zeile fuellen. Die Intervallzaehler werden hier
// geleert (exchange(0)); stat_drop_count[] wird nur gelesen, das Nullen bleibt
// plattformseitig (ESP32 memset, nRF52 unter taskENTER_CRITICAL()).
void setlogFillStat(struct setlogStatFields *f, uint32_t heap)
{
    if(f == NULL)
        return;

    uint32_t rx5 = stat_util_rx_5m.exchange(0);
    uint32_t tx5 = stat_util_tx_5m.exchange(0);
    uint32_t util = 100UL * (rx5 + tx5) / (uint32_t)(PRIO_STAT_INTERVAL_S * 1000UL);
    if(util > 100)
        util = 100;

    f->util_pct       = (uint8_t)util;
    f->rx_ms          = rx5;
    f->tx_ms          = tx5;
    f->newid          = stat_newid.exchange(0);
    f->dup            = stat_dup.exchange(0);
    f->err            = stat_rx_err.exchange(0);
    f->txn            = stat_txn.exchange(0);
    f->txfail         = stat_txfail.exchange(0);
    f->ringmax        = stat_ring_max.exchange(0);
    f->ring_size      = MAX_RING;
    f->drop[0]        = stat_drop_count[1];
    f->drop[1]        = stat_drop_count[2];
    f->drop[2]        = stat_drop_count[3];
    f->drop[3]        = stat_drop_count[4];
    f->drop[4]        = stat_drop_count[5];
    // MeshCom 5 (docs/meshcom5-campaign.md Welle 4): STAT-Zeile ist ein
    // Monitor-Feld (Konsole 2323), kein Funk -- nbrNcnt(), nicht die auf
    // NBR_NCNT_AIR_MAX gekappte Sendefassung.
    f->mh             = (uint16_t)nbrNcnt(nbrMatrix, uptimeMin16());
    f->heap           = heap;
    f->trk_interval_s = trickle_interval_ms / 1000UL;
    f->trk_consistent = trickle_consistent_count;
    f->fw_major       = shortVERSION();
    f->fw_sub         = shortSUBVERSION();
    f->flash          = FLASH_VERSION;
    f->up_s           = millis() / 1000UL;
    f->t_ms           = millis();

    // WQ-01 (2026-09-05): queue panel on the rxlog web page -- Kopie des
    // fertigen Fensters fuer Leser, die nicht selbst drucken (Web-GUI).
    stat_last_window = *f;
    stat_last_window_ms = f->t_ms;

    // 0.4: DM counters/RTT histogram as a second setlog line, same channel
    // (setlogPrint -> printfdeb) and the same bDisplayLog gate as STAT.
    if(bDisplayLog)
    {
        char dmbuf[200];
        dmStatFormat(dmbuf, sizeof(dmbuf));
        setlogPrint(dmbuf);

#if defined(ENABLE_MSGSTORE)
        if(msgstoreMode() != MSGSTORE_OFF)
        {
            msgstoreFormatLine(dmbuf, sizeof(dmbuf));   // S3: MBOX line, same gate
            setlogPrint(dmbuf);
        }
#endif
    }
}

void charBuffer_aprs(struct aprsMessage &aprsmsg)
{
    // R2-04: war UDP_TX_BUF_SIZE (255). Quell- und Zielpfad sind je bis zu
    // MC_PATH_LEN lang, dazu Zeitstempel, Kopfdaten und 60 Byte Nutzlast --
    // zusammen mehr als 255. snprintf() hat das immer sauber gekuerzt, aber
    // die Zeile ist eine DIAGNOSEausgabe: sie soll den Pfad zeigen, nicht ihn
    // abschneiden. Der Puffer waechst auf den tatsaechlichen Groesstfall.
    char internal_message[2 * MC_PATH_LEN + 128];
    
    memset(internal_message, 0x00, sizeof(internal_message));

    int ilpayload=strlen(aprsmsg.msg_payload);
    if(ilpayload > 60)
        ilpayload=60;

    snprintf(internal_message, sizeof(internal_message), "%s :%08X %1u %i%i%i %01X/%1u LH:%02X %s>%s %c%.*s",  getTimeString().c_str(),
        aprsmsg.msg_id, aprsmsg.max_hop,aprsmsg.msg_server, aprsmsg.msg_track, aprsmsg.msg_mesh, (aprsmsg.msg_source_mod>>4), (aprsmsg.msg_source_mod & 0xf), aprsmsg.msg_last_hw,
        //aprsmsg.msg_source_hw, aprsmsg.msg_fcs, aprsmsg.msg_source_fw_version, aprsmsg.msg_source_fw_sub_version, aprsmsg.msg_last_hw,
        aprsmsg.msg_source_path, aprsmsg.msg_destination_path,
        aprsmsg.payload_type, (int)ilpayload, aprsmsg.msg_payload);

    
    internal_message[UDP_TX_BUF_SIZE-1]=0x00;

    // R1-04: Zeiger EINMAL lesen, dann nur die lokale Kopie benutzen. Ist der
    // Puffer nicht angelegt (niemand hat die rxlog-Seite geoeffnet), passiert
    // hier nichts -- der Ringzeiger laeuft trotzdem weiter, damit die Seite
    // nach dem Anlegen dieselbe Reihenfolge zeigt wie vorher.
    rawLogLine_t *raw = ringbufferRAWLoraRX;
    if(raw == NULL)
        return;

    memcpy(raw[RAWLoRaWrite], internal_message, UDP_TX_BUF_SIZE-1);
}

// SL-01: `tail` haengt VOR dem `\n` an die bestehende Zeile an -- leer bei
// jedem Aufrufer ausser der RX-Zeile, die Zeile bleibt damit byteidentisch.
void printBuffer_aprs(char *msgSource, struct aprsMessage &aprsmsg, const char *tail)
{
    printfdeb("%s %s %03i %c x%08X H%02X S%i T%i M%02X %s>%s%c%s HW:%02i MOD:%01X/%01i FCS:%04X FW:%02i:%c LH:%02X%s\n", getTimeString().c_str(), msgSource, aprsmsg.msg_len, aprsmsg.payload_type, aprsmsg.msg_id, aprsmsg.max_hop,
        aprsmsg.msg_server, aprsmsg.msg_track, aprsmsg.msg_mesh, aprsmsg.msg_source_path, aprsmsg.msg_destination_path, aprsmsg.payload_type, aprsmsg.msg_payload,
        aprsmsg.msg_source_hw, (aprsmsg.msg_source_mod>>4), (aprsmsg.msg_source_mod & 0xf), aprsmsg.msg_fcs, aprsmsg.msg_source_fw_version, aprsmsg.msg_source_fw_sub_version, aprsmsg.msg_last_hw, tail);
}

void printBuffer_ack(char *msgSource, uint8_t payload[UDP_TX_BUF_SIZE+10], int16_t size, const char *tail)
{
    if(size == 7)
        printfdeb("%s %s 007 %c x%02X%02X%02X%02X H%02X %02X%s\n", getTimeString().c_str(), msgSource, payload[0], payload[4], payload[3], payload[2], payload[1], payload[5], payload[6], tail);
    else
        printfdeb("%s %s 012 %c x%02X%02X%02X%02X H%02X x%02X%02X%02X%02X %02X %02X%s\n", getTimeString().c_str(), msgSource, payload[0], payload[4], payload[3], payload[2], payload[1], payload[5], payload[9], payload[8], payload[7], payload[6], payload[10], payload[11], tail);
}


///////////////////////////////////////////////////////////////////////////
// APRS Meldungen
void DisplayPong(char line1[20], char line2[20], char line3[20], char line4[20])
{
    #if (defined(BOARD_E290) || defined(BOARD_WIRELESS_PAPER) || defined(BOARD_E213))
    // do nothing
    #elif defined(BOARD_T_ECHO) || defined(BOARD_HELTEC_T114) || defined(BOARD_STICK_V3)
    // do nothing
    #elif defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS) || defined(BOARD_TRACKER) || defined (BOARD_T5_EPAPER) || defined(BOARD_T_DECK_PRO) || defined(BOARD_T_CONNECT_PRO)
    // do nothing
    #else

    if(u8g2 == NULL)
        return;

    u8g2->clearDisplay();
    oledInvalidate();
    u8g2->firstPage();

    do
    {
        
        #if defined (BOARD_TRACKER)
        //TODO
        #elif defined (BOARD_STICK_V3)
            u8g2->setFont(u8g2_font_6x10_tf);
            u8g2->drawStr(36, 42, "MeshCom 4");
            snprintf(cvers, sizeof(cvers), "%s/%s %s", SOURCE_VERSION, SOURCE_VERSION_SUB, getCountry(meshcom_settings.node_country).c_str());
            u8g2->drawStr(36, 52, cvers);
            u8g2->drawStr(36, 62, "icssw.org");
        #else
            u8g2->setFont(u8g2_font_10x20_mf);
            u8g2->drawStr(5, 18, line1);
            u8g2->drawStr(5, 34, line2);
            u8g2->drawStr(5, 50, line3);
            u8g2->setFont(u8g2_font_6x10_mf);
            u8g2->drawStr(5, 60, line4);
        #endif
    } while (u8g2->nextPage());

    #endif
}

// D3-02: shared epilogue for locally originated APRS frames -- advance the
// message-id counter, persist it only at the high-water mark (see
// msgid_counter.h; DO NOT reorder these three calls, the persist-on-step
// scheme depends on this exact order), pick the via-path, then encode into
// msg_buffer. `msg_buffer` must be at least MAX_MSG_LEN_PHONE bytes, and
// `aprsmsg.msg_id` must already be set by the caller before this runs.
//
// Not every call site fits this shape: SendAckMessage() interleaves
// insertOwnTx()/addLoraRxBuffer() between the persist step and checkVia(),
// so it keeps its own inline epilogue rather than being forced through here
// (docs/optimization-audit-20260910.md D3-02).
static void finalizeAndSendAPRS(struct aprsMessage &aprsmsg, uint8_t *msg_buffer)
{
    meshcom_settings.node_msgid = msgIdAdvance(meshcom_settings.node_msgid);

    // Flash rewrite, but only at a high-water mark -- msgid_counter.h
    if(msgIdNeedsPersist(meshcom_settings.node_msgid))
        countersSave();

    checkVia(aprsmsg);

    encodeAPRS(msg_buffer, aprsmsg);
}

PingResult sendPing(char msg_call[10])
{
    // no ping within track mode
    //
    // Vorher kehrte die Funktion hier stumm zurueck: der Aufrufer hatte
    // "[PING]...send Ping" schon ausgegeben und ein Ping-Budget verbraucht,
    // obwohl nie ein Frame den TX-Ring erreichte -- der Operator sah eine
    // Luege auf dem Display. static statt bLORADEBUG/bDisplayInfo, damit die
    // Meldung unabhaengig vom Debug-Level einmal pro Unterdrueckungs-Episode
    // erscheint statt bei jedem Ping-Intervall erneut.
    static bool bPingTrackNoticeShown = false;
    if(bDisplayTrack)
    {
        if(!bPingTrackNoticeShown)
        {
            printfdeb("[PING]...suppressed: TRACK mode active (--track off to ping)\n");
            bPingTrackNoticeShown = true;
        }
        return PING_SUPPRESSED_TRACK;
    }
    bPingTrackNoticeShown = false;

    // Last guard, before the msg_id advances and before any pool write.
    // Group, special target, own call or junk never leaves the node (a group ping
    // only draws gateway ACKs, it can never be answered). Once per episode.
    static bool bPingInvalidNoticeShown = false;
    if(!pingTargetValid(msg_call, meshcom_settings.node_call))
    {
        if(!bPingInvalidNoticeShown)
        {
            printfdeb("[PING]...invalid target %s, ping not sent\n", msg_call);
            bPingInvalidNoticeShown = true;
        }
        return PING_INVALID_TARGET;
    }
    bPingInvalidNoticeShown = false;

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, ':');

    aprsmsg.msg_len = 0;

    // MSG ID zusammen setzen
    // bei Text beginnend mit {ping} und {pong} keine MSB fÄ‚Ä˝r repeat markieren
    // [DK5EN] Passt so: diese Meldung wird gar nicht wiederholt (Ring-Status 0xFF beim
    // [DK5EN] Einreihen), die msg_id bleibt unveraendert. Eine Wiederholungs-id bekommt nur eine
    // [DK5EN] eigene PN (Text an Rufzeichen, endet auf {NNN), in updateRetransmissionStatus().
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);   // MAC-address + 3FF = 1023 max rela only 0-999
    
    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);
    
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), msg_call);
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), msg_call);

    memset(msg_text, 0x00, sizeof(msg_text));
    snprintf(msg_text, sizeof(msg_text), "{ping}");

    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), msg_text);
    
    finalizeAndSendAPRS(aprsmsg, msg_buffer);

    if(bDisplayInfo)
    {
        printBuffer_aprs((char*)"NEW-PING", aprsmsg);
        printfdeb("");
    }

    // store last message to compare later on
    insertOwnTx(aprsmsg.msg_id);

    // Master RingBuffer for transmission
    // local messages send to LoRa TX
    //
    // Rueckgabewert war bisher verworfen: ein voller Ring hat den Ping
    // ebenso stumm verschluckt wie der TRACK-Fall oben, nur dass Display und
    // bPingSend so taten, als sei er unterwegs -- eine Intervall-Laenge
    // spaeter kam dann ein irrefuehrendes "[PONG]...fail". Sofort raus, noch
    // vor DisplayPong/bPingSend, damit kein Zaehler fuer einen nie
    // eingereihten Frame scharf gestellt wird.
    // P15: addTxRingEntryOnce() statt addTxRingEntry(..., RING_STATUS_DONE,
    // ...) -- ein Ping ist eine persoenliche DM und soll als solche
    // (MSG_PRIO_CRITICAL) eingestuft werden, nicht als Relay (siehe dort).
    if(addTxRingEntryOnce(msg_buffer, (uint16_t)aprsmsg.msg_len, "phone_msg") < 0)
    {
        printfdeb("[PING]...not queued: TX ring refused the frame\n");
        return PING_RING_REFUSED;
    }

    if(!bPingSend)
    {
        char cmsg[30];
        snprintf(cmsg, sizeof(cmsg), "%i", aprsmsg.msg_id);
        char cmsg1[30];
        snprintf(cmsg1, sizeof(cmsg1), "PING %c%c%c", cmsg[7], cmsg[8], cmsg[9]);
        DisplayPong((char*)cmsg1, (char*)msg_call, (char*)"SENT", (char*)"");
    }

    // text immer meshcom_settings.node_pingtime stehenlassen und Display immer ON
    DisplayOffWait = millis() + (meshcom_settings.node_pingtime * 1000);
    bDisplayIsOff=false;

    meshcom_settings.node_pingduration = millis();
    bPingSend=true;

    return PING_QUEUED;
}

void PongFail(String msg_call)
{
    DisplayPong((char*)"PONG", (char*)msg_call.c_str(), (char*)"FAILED", (char*)"");

    // text immer meshcom_settings.node_pingtime stehenlassen und Display immer ON
    DisplayOffWait = millis() + (meshcom_settings.node_pingtime * 1000);
    bDisplayIsOff=false;
}

void SendPong(String msg_call, unsigned int msg_id)
{
    // no ping within track mode
    //
    // Gleiches stummes Verhalten wie bei sendPing() -- Marker-only, Signatur
    // bleibt void, static-Flag unabhaengig von der in sendPing().
    static bool bPongTrackNoticeShown = false;
    if(bDisplayTrack)
    {
        if(!bPongTrackNoticeShown)
        {
            printfdeb("[PONG]...suppressed: TRACK mode active\n");
            bPongTrackNoticeShown = true;
        }
        return;
    }
    bPongTrackNoticeShown = false;

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, ':');

    aprsmsg.msg_len = 0;

    // MSG ID zusammen setzen    
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);   // MAC-address + 3FF = 1023 max rela only 0-999
    
    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);
    
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), msg_call.c_str());
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), msg_call.c_str());

    memset(msg_text, 0x00, sizeof(msg_text));
    snprintf(msg_text, sizeof(msg_text), "{pong}{%03i}", msg_id);

    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), msg_text);
    
    finalizeAndSendAPRS(aprsmsg, msg_buffer);

    if(bDisplayInfo)
    {
        printBuffer_aprs((char*)"NEW-PONG", aprsmsg);
        printfdeb("");
    }

    // store last message to compare later on
    insertOwnTx(aprsmsg.msg_id);

    // Master RingBuffer for transmission
    // local messages send to LoRa TX
    // P15: siehe sendPing() oben -- ein Pong ist ebenfalls eine persoenliche DM.
    addTxRingEntryOnce(msg_buffer, (uint16_t)aprsmsg.msg_len, "phone_msg");
}

// ===========================================================================
// BP-01 (BACKLOG) / TM-37 Ă˘â‚¬â€ť back-pressure to the sender, in Q-codes.
//
// Until now sendMessage() threw addTxRingEntry()'s return value away: a user
// could type into a full ring and the message vanished without a word. The
// state machine lives in src/backpressure.h (Arduino-free, unit-tested in
// test/test_backpressure); everything below is only the wiring Ă˘â‚¬â€ť which
// transport gets told, and when.
//
// Two rules the operator set that shape this code:
//   * the notice goes back on the transport the message came from and NEVER
//     over the air Ă˘â‚¬â€ť a notice that is radiated adds to the congestion it
//     reports, so nothing here ever touches addTxRingEntry()/sendMessage().
//   * only locally originated user messages are refused. Relay traffic, ACKs
//     and beacons never pass through sendMessage() and never set an origin,
//     so the node stays a working relay while the flooding user is throttled.
// ===========================================================================

// Thresholds come from MAX_RING, which differs per board (10 / 20, MEM-01,
// configuration_global.h) Ă˘â‚¬â€ť a hardcoded 16 would warn at 160 % on a T-Beam.
static BackPressure bp_state(MAX_RING);

// WQ-01 (2026-09-05): queue panel on the rxlog web page -- read-only getters
// onto bp_state for callers outside this TU (the web GUI). Plain int return
// values keep the enum (BpState, backpressure.h) out of the shared header.
int bpCurrentState(void)
{
    return (int)bp_state.state();
}

int bpRefuseThreshold(void)
{
    return bp_state.refuseThreshold();
}

int bpQrsThreshold(void)
{
    return bp_state.qrsThreshold();
}

int bpQrsForecast(int depth)
{
    return bp_state.qrsForecastDepth(depth);
}

const char* bpStateName(void)
{
    switch(bp_state.state())
    {
        case BP_QUIET: return "QUIET";
        case BP_QRS:   return "QRS";
        case BP_QRT:   return "QRT";
        default:       return "QUIET";
    }
}

// Set by each caller immediately before sendMessage(), cleared right after.
static MsgOrigin bp_origin = ORIGIN_NONE;

// The transport the episode's warnings went to. Needed because the QRV that
// closes an episode is usually emitted from the drain poll, long after
// bp_origin was cleared. "on the same transport the warnings went to".
//
// BP-05 note: a QRS-only episode now closes SILENTLY (enterQuiet() returns
// NONE), so this is no longer cleared on that path -- the stale value is
// harmless as long as every sendMessage() caller tags bp_origin (all eight
// do today; each latching notice overwrites it before any QRV reads it).
// If an untagged sendMessage() caller is ever added, revisit this.
static MsgOrigin bp_episode_origin = ORIGIN_NONE;

// BP-06: the destination of the message currently being handled in
// sendMessage() -- a group, a DM call, or "*". Unlike bp_origin (set by the
// caller before sendMessage(), cleared right after), this is set INSIDE
// sendMessage() itself and simply stands until the next call overwrites it;
// there is no caller-side set/clear pair to mirror, so no reset is needed.
static char bp_origin_dst[12] = "*";

// The destination the episode's warnings went to, latched exactly like
// bp_episode_origin above -- the QRV that closes an episode reads this,
// long after bp_origin_dst may have moved on to a different message.
static char bp_episode_dst[12] = "*";

void setMsgOrigin(MsgOrigin origin)
{
    bp_origin = origin;
}

MsgOrigin getMsgOrigin(void)
{
    return bp_origin;
}

// E5 (2026-09-01, operator finding): msg_id must stay unique across every BP
// frame or the chat app's dedup filter swallows whichever of two notices
// lands in the same millisecond. The BP-08 QTA path (Welle 2) emits two
// frames from a single sendMessage() call -- the latched episode notice and
// the NOT-SENT nack -- both drawing from this same counter via bpDeliver().
// A plain "id = millis()" would very likely hand both the same value.
//
// No rollover problem: the bump is a plain uint32 addition, and a jump past
// millis()'s current reading self-corrects on the next call once the clock
// has genuinely caught back up past it.
//
// Non-static, unlike the rest of this file's BP-01 machinery:
// extudp_functions.cpp (sendExternNotice()) needs it too. Declared in
// loop_functions_extern.h (Welle 3 / BP-09 cleanup -- that header was out of
// scope for BP-07 Welle 1, which is why extudp_functions.cpp used to carry
// its own hand-written extern for this instead).
static uint32_t bp_last_msg_id = 0;

uint32_t bpNextMsgId(void)
{
    uint32_t id = millis();
    if(id <= bp_last_msg_id)
        id = bp_last_msg_id + 1;

    // M8: id == 0 happens exactly once per ~49.7-day millis() rollover --
    // bp_last_msg_id == 0xFFFFFFFF, the +1 above wraps to 0. checkOwnTx()
    // (this file) treats msg_id == 0 as "no id" / never matches, so a BP
    // frame with id 0 would silently fail its own-tx bookkeeping. Skip it.
    if(id == 0)
        id = 1;

    bp_last_msg_id = id;
    return id;
}

/**
 * Put one notice in front of the operator, on their own transport.
 *
 * The raw [BP];notice; line is unconditional and deliberately Serial.printf,
 * not printfdeb/DEBUG_MSG: those compile away with debug off, and the bench
 * has to be able to assert the notice regardless of which transport (or
 * none) carried it.
 */
/**
 * BP notice to phone app / web GUI, framed under the node's own callsign.
 *
 * Not addBLECommandBack(): that frames with source "response", which is not
 * a valid callsign Ă˘â‚¬â€ť McApp files such senders under its spam class (group
 * 9999) and the notice never reaches the operator. Command responses keep
 * the "response" framing; only the back-pressure notices travel as
 * <node_call>>*:<text>. The framing itself lives in bp_notice_frame.h,
 * where the native suite pins it (test/test_bp_notice_frame).
 */
static void bpNoticeToPhone(const char *text, const char *dst)
{
    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    bpNoticeFillFrame(aprsmsg, meshcom_settings.node_call, text, bpNextMsgId(), dst);

    checkVia(aprsmsg);

    encodeAPRS(msg_buffer, aprsmsg);

    addBLEOutBuffer(msg_buffer, aprsmsg.msg_len);
}

// BP-07: the transport switch, split out of bpEmitNotice() so bpEmitNack()
// (below) can share it verbatim -- both a notice and a nack are, at this
// point, just "some already-composed text going to some origin/dst"; only
// the [BP] console marker in front of them differs by message class.
//
// BP-06: dst is the destination of the message that triggered the
// notice/nack (a group, a DM call, or "*") -- forwarded from bp_origin_dst /
// bp_episode_dst by the two callers below. Serial and the T-Deck GUI stay
// plain text and unaddressed (an operator watching the console/screen
// already sees which target they typed into); only the BLE/web and EXTUDP
// paths, which render into a per-destination chat view, need it.
static void bpDeliver(const char *text, MsgOrigin origin, const char *dst)
{
    switch(origin)
    {
        case ORIGIN_SERIAL:
            Serial.printf("\n%s\n", text);
            break;

        case ORIGIN_BLE:
        case ORIGIN_WEB:
            // Both land in BLEtoPhoneBuff via bpNoticeToPhone(): the phone
            // app drains it in sendToPhone(), the web GUI reads the same ring
            // for its message list (web_functions.cpp ~1293). Framed under
            // the node's own callsign (msg_id via bpNextMsgId(), E5;
            // msg_app_offline -> never announced, never retransmitted); see
            // bpNoticeToPhone() for why not addBLECommandBack()'s "response"
            // sender.
            //
            // If the transport dropped off meanwhile, skip rather than queue
            // it Ă˘â‚¬â€ť a notice/nack that arrives with the next connect is
            // noise, not information.
            if((origin == ORIGIN_BLE && g_ble_uart_is_connected) ||
               (origin == ORIGIN_WEB && bWEBSERVER))
            {
                bpNoticeToPhone(text, dst);
            }
            break;

        case ORIGIN_EXTUDP:
            sendExternNotice(text, dst);
            break;

        case ORIGIN_GUI:
            // dst intentionally ignored: the T-Deck screen/console already
            // shows the operator which destination they just typed into.
            #if defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS)
            addMessage(text);
            #elif defined(BOARD_T_DECK_PRO)
            TDeck_pro_lora_disp(String("node"), foldForDisplay(text, TF_ASCII));
            #endif
            break;

        case ORIGIN_NONE:
        default:
            break;
    }
}

static void bpEmitNotice(BpNotice notice, MsgOrigin origin, const char *dst)
{
    if(notice == BP_NOTICE_NONE)
        return;

    Serial.printf("[BP];notice;%s;depth;%d;max;%d;ms;%lu\n",
                  bpNoticeCode(notice), txRingDepth(), (int)MAX_RING,
                  (unsigned long)millis());

    bpDeliver(bpNoticeText(notice), origin, dst);
}

// BP-07 (L1/L2): the per-message counterpart to bpEmitNotice() above --
// "QRT NOT SENT - <text>" / "QTA NOT SENT - <text>", one per lost message,
// never latched (unlike the episode notice). msg_text is the operator's own,
// still-unrefused text (strMsg.c_str() at the refuse call site) -- truncated
// and sanitized by bpNackCompose() (bp_notice_frame.h) before it goes out.
static void bpEmitNack(BpNack n, MsgOrigin origin, const char *dst, const char *msg_text)
{
    if(n == BP_NACK_NONE)
        return;

    // E2: framed exactly like the episode notices (msg_app_offline, msg_id
    // via bpNextMsgId(), never a real one -- BP-01 refuses on purpose to
    // consume none for a message that never went out).
    //
    // H3: composed BEFORE the [BP];nack; marker below and logged instead of
    // the raw msg_text. msg_text is operator content, unsanitized -- a real
    // LF in it (e.g. EXTUDP {"msg":"a\nb"}) used to split the marker line in
    // two and could forge a bogus [MC-DBG] marker inside it, misleading
    // tools/serial_monitor.py and tools/loganalyse.sh. body has already been
    // through bpNackCompose()'s control-byte-to-space rule (rule 2 in
    // bp_notice_frame.h), so it cannot contain a raw LF or any other
    // control byte.
    // M1: on nRF52 the loop stack is 4 KB and this sits on the
    // getExtern -> sendMessage path N-22 measured at watermark 0 (see the
    // msg_text_check / msg_buffer comment above in sendMessage()) -- static
    // moves it to BSS, same pattern as the rest of this file. bpEmitNack()
    // is loop-context only (called from sendMessage(), never from an ISR or
    // another task), so a static buffer here is not shared across contexts.
#if defined(NRF52_SERIES)
    static char body[16 + BP_NACK_TEXT_MAX + 4];   // prefix (<=15) + text (<=120) + "..." (<=3) + NUL
#else
    char body[16 + BP_NACK_TEXT_MAX + 4];
#endif
    bpNackCompose(body, sizeof(body), bpNackPrefix(n), msg_text);

    // [BP];nack; is its own marker, never [BP];notice; -- the Runbook's BP-01
    // bench assertion greps for "notice;" specifically and must stay valid.
    // E6: the message text is operator content and goes out only with
    // bLORADEBUG on; the rest of the line is unconditional, same as every
    // other [BP] marker. txt; is last because body can itself contain
    // semicolons -- a left-to-right parser stays intact either way.
    if(bLORADEBUG)
        Serial.printf("[BP];nack;%s;dst;%s;ms;%lu;txt;%s\n",
                      bpNackCode(n), dst, (unsigned long)millis(), body);
    else
        Serial.printf("[BP];nack;%s;dst;%s;ms;%lu\n",
                      bpNackCode(n), dst, (unsigned long)millis());

    // M4: mirror bpRoute()'s non-QRV latch below -- without this, a sender
    // refused in the middle of an episode a DIFFERENT transport opened gets
    // this loss notice but is never remembered for the closing QRV, so it
    // never hears the all-clear. Same target-resolution and the same
    // "only touch bp_episode_dst when bp_origin is set" guard as bpRoute()
    // (its comment explains why: with bp_origin == ORIGIN_NONE the episode
    // must keep ITS opener's destination, not a future untagged caller's).
    if(bp_origin != ORIGIN_NONE)
    {
        bp_episode_origin = bp_origin;
        snprintf(bp_episode_dst, sizeof(bp_episode_dst), "%s", bp_origin_dst);
    }

    bpDeliver(body, origin, dst);
}

/// Route a notice: to the sender that just spoke, else to the one the episode
/// was opened for. Also remembers the transport and destination for the
/// closing QRV (BP-06: bp_episode_dst mirrors bp_episode_origin exactly).
static void bpRoute(BpNotice notice)
{
    if(notice == BP_NOTICE_NONE)
        return;

    if(notice == BP_NOTICE_QRV)
    {
        // M5: capture into locals and reset the globals BEFORE emitting, not
        // after. bpEmitNotice() -> bpDeliver() can re-enter sendMessage() on
        // a T-Deck: addMessage() (ORIGIN_GUI) spins lv_task_handler() for up
        // to 100 ms and can dispatch the on-screen send button from within
        // that spin, which runs sendMessage() -> bpRoute() again and
        // freshly latches bp_episode_origin/bp_episode_dst for THAT send.
        // Resetting the globals only after this outer call returns would
        // then wipe the nested call's latch right after it set it.
        MsgOrigin origin = bp_episode_origin;
        char dst[sizeof(bp_episode_dst)];
        snprintf(dst, sizeof(dst), "%s", bp_episode_dst);

        bp_episode_origin = ORIGIN_NONE;
        snprintf(bp_episode_dst, sizeof(bp_episode_dst), "*");

        bpEmitNotice(notice, origin, dst);
        return;
    }

    MsgOrigin target = (bp_origin != ORIGIN_NONE) ? bp_origin : bp_episode_origin;
    bp_episode_origin = target;

    // Copy the dst only when the origin side is also being re-latched from
    // the current sender (bp_origin set): with bp_origin == ORIGIN_NONE the
    // episode keeps ITS opener's destination -- a future untagged
    // sendMessage() caller must not clobber where the episode's QRV goes.
    // (Semantic guard, not an aliasing concern -- the buffers are disjoint.)
    if(bp_origin != ORIGIN_NONE)
        snprintf(bp_episode_dst, sizeof(bp_episode_dst), "%s", bp_origin_dst);

    bpEmitNotice(notice, target, bp_episode_dst);
}

void bpPollDrain(void)
{
    bpRoute(bp_state.poll(txRingDepth(), millis()));
}

int sendMessage(char *msg_text, int len, const char *src_override, unsigned int *out_msg_id)
{
    if(memcmp(msg_text, "-", 1) == 0)
    {
        if(bDisplayInfo)
            printfdeb("COMMAND:%s\n", msg_text);

        commandAction(msg_text, false);
        return BP_SEND_OK;
    }

    uint8_t ispos = 0;

    bool bConsoleText = false;

    if(msg_text[0] == ':')
    {
        if(msg_text[1] == ':')
        {
            ispos=2;
            bConsoleText = true;
        }
        else
        {
            ispos=1;    // WEBService only
        }
    }

    // umwandeln %F0%9F%98%80%
    int ii=0;
    int in=0;
    unsigned int ib=0;
    // N-22: der Loop-Task-Stack auf nRF52 ist 4 KB (LOOP_STACK_SZ im
    // Adafruit-Core, nicht per Build-Flag ueberschreibbar). Der Pfad
    // checkSerialCommand() -> sendMessage() -> sendExtern() lief mit
    // Stack-Watermark 0 (auf Hardware gemessen, 2026-08-21) und zerstoerte
    // Nachbar-RAM Ă˘â‚¬â€ť Absturz Sekunden spaeter (SREQ). Grosse Puffer deshalb
    // in BSS; sendMessage() laeuft auf nRF52 ausschliesslich im Loop-Task
    // (Aufrufer: checkSerialCommand, hasMsgFromPhone-Zweig in nrf52loop,
    // getExtern Ă˘â‚¬â€ť alle Loop-Kontext). Gleiches Muster wie Commit 1951aa7d
    // in sendExtern(). Die memset()-Aufrufe direkt darunter initialisieren
    // beide Puffer ohnehin bei jedem Aufruf.
#if defined(NRF52_SERIES)
    static char msg_text_check[200];
    static char msg_text_checked[200];
#else
    char msg_text_check[200];
    char msg_text_checked[200];
#endif
    int len_check=len;
    if(len_check > (int)sizeof(msg_text_check)-1)
        len_check = sizeof(msg_text_check)-1;

    memset(msg_text_checked, 0x00, sizeof(msg_text_checked));
    memset(msg_text_check, 0x00, sizeof(msg_text_check));

    memcpy(msg_text_check, msg_text+ispos, len_check);

    if(bDisplayCont)
    {
        printfdeb("SendMessage in:%s\n", msg_text_check);
    }

    int iulng=0;

    // Loop is driven by ii, the real source-consumption index (advances by
    // up to 12 per multi-byte %-escape), not by a decoupled counter.
    while(ii < len_check)
    {
        // Bound every destination write: never let 'in' reach or pass the
        // last byte of msg_text_checked, which must stay NUL (buffer is
        // used as a C string afterwards).
        if(in >= (int)sizeof(msg_text_checked)-1)
            break;

        if(memcmp(msg_text_check+ii, "%C2", 3) == 0)
            iulng=6;
        if(memcmp(msg_text_check+ii, "%EF", 3) == 0)
            iulng=9;
        if(memcmp(msg_text_check+ii, "%E2", 3) == 0)
            iulng=9;
        if(memcmp(msg_text_check+ii, "%F0", 3) == 0)
            iulng=12;

        if(memcmp(msg_text_check+ii, "%0A", 3) == 0)
        {
            msg_text_checked[in] = ' ';
            in++;

            ii=ii+3;
        }
        else
        if(iulng > 0)
        {
            for(int is=1;is<iulng;is=is+3)
            {
                if(ii+is+1 >= (int)sizeof(msg_text_check))
                    break;

                if(in >= (int)sizeof(msg_text_checked)-1)
                    break;

                if(msg_text_check[ii+is] >= 'A')
                    ib = (msg_text_check[ii+is] - 'A') + 10;
                else
                    ib = msg_text_check[ii+is] - '0';

                if(msg_text_check[ii+is+1] >= 'A')
                    ib = (ib << 4) | ((msg_text_check[ii+is+1] - 'A') + 10);
                else
                    ib = (ib << 4) | (msg_text_check[ii+is+1] - '0');

                msg_text_checked[in] = ib;
                in++;
            }

            ii=ii+iulng;

            iulng=0;
        }
        else
        {
            msg_text_checked[in] = msg_text_check[ii];
            in++;
            ii++;
        }
    }

    if(bDisplayCont)
    {
        printfdeb("SendMessage out:%s\n", msg_text_checked);
    }

    /*
    printlndeb(msg_text_check);
    printlndeb(msg_text_checked);
    for(int iu=0;iu<50;iu++)
    {
        printfdeb("%02X ", msg_text_checked[iu]);
    }
    printlndeb("");
    */

    String strMsg = msg_text_checked;

    String strDestinationCall = "*";
    
    if(strMsg.length() < 1 || strMsg.length() > 160)
    {
        printfdeb("sendMessage wrong text length:%i\n", strMsg.length());
        return BP_SEND_INVALID;
    }

    bool bDM=false;

    if(strMsg.charAt(0) == '{')
    {
        int iCall = strMsg.indexOf('}');
        if(iCall != -1 && iCall < 11)   // {OE1KBC-99}Textmessage or Group-Call {2321}
        {
            strDestinationCall = strMsg.substring(1, iCall);
            strDestinationCall.toUpperCase();
            strDestinationCall.trim();
            strMsg = strMsg.substring(iCall+1);

            if(strMsg.startsWith("{mcp}") || strMsg.startsWith("{MCP}")) // Fernwirken
            {
                char cId[4] = {0};
                snprintf(cId, sizeof(cId), "%03i", meshcom_settings.node_msgid);
                char cnewMsg[64];
                snprintf(cnewMsg, sizeof(cnewMsg), "{mcp}%c%s%c%s%c%s", cId[0], strMsg.substring(5, 7).c_str(), cId[1], strMsg.substring(7, 9).c_str(), cId[2], strMsg.substring(9).c_str());
                strMsg = cnewMsg;
            }
            else
                if(CheckGroup(strDestinationCall) == 0 && strDestinationCall != "*" && strDestinationCall != "WLNK-1" && strDestinationCall != "APRS2SOTA") // no Group Call or WLNK-1 Call
                    bDM=true;
        }

        // check no message to own-call
        if(strDestinationCall.compareTo(meshcom_settings.node_call) == 0)
        {
            printfdeb("[ERROR]...DM to own-all not allowed\n");
            return BP_SEND_INVALID;
        }
    }

    // A manual {ping} only makes sense towards a callsign. After the
    // {ZIEL} parse (a bare {ping} parses as destination PING), before any msg_id.
    if(strMsg.startsWith("{ping}") &&
       !pingTargetValid(strDestinationCall.c_str(), meshcom_settings.node_call))
    {
        printfdeb("[ERROR]...{ping} needs a callsign target\n");
        return BP_SEND_INVALID;
    }

    // BP-11: the node's own back-pressure wording fed back in by a client
    // (see bpIsOwnWording() in backpressure.h). Checked here, after the
    // {ZIEL} parse, because the observed shape is "{*}QRT NOT SENT - ..."
    // -- a client re-sending the nack frame with its dst -- and a check on
    // the raw text would miss it. Before bp_origin_dst, before refusing()
    // and before any msg-id is minted: a blocked echo leaves no trace in
    // the BP state machine and gets NO nack and NO notice back -- a
    // receipt for an echo is what opens the next loop. Unconditional on
    // bp_origin: every sendMessage() caller is a local text input (BLE,
    // serial, web, EXTUDP, T-Deck), relay traffic never comes through here.
    // Marker carries no text, ever (BP-10 H3: a raw text in a [BP] line can
    // forge a marker for tools/serial_monitor.py and loganalyse.sh).
    if(bpIsOwnWording(strMsg.c_str()))
    {
        Serial.printf("[BP];echo;ms;%lu\n", (unsigned long)millis());
        return BP_SEND_INVALID;
    }

    // BP-06: strDestinationCall is authoritative here (fully parsed,
    // upper-cased, trimmed) -- set bp_origin_dst before the refuse check
    // below so a refused message's nack is addressed to the target the
    // sender actually named, not the "*" default.
    // M7 / BP-06/2: an empty or whitespace-only {} target (e.g. "{}Hallo",
    // trim() above already strips the whitespace-only case to "") has
    // nowhere for a notice to land -- fall back to "*", the deliberate rule
    // the deleted bpPeekDst() used to enforce, lost when that second-guess
    // parser was removed (BP-07 comment above). Only bp_origin_dst (the
    // notice/nack destination) gets this fallback -- strDestinationCall
    // itself, and therefore the actual outgoing message's destination, is
    // untouched.
    snprintf(bp_origin_dst, sizeof(bp_origin_dst), "%.11s",
             (strDestinationCall.length() == 0) ? "*" : strDestinationCall.c_str());

    // BP-01/BP-07: refuse a locally originated user message while the ring
    // sits in the QRT band. Grundentscheidung (bp-l1-l4-impl-plan.md): this
    // check used to sit before the %-decode loop and the {ZIEL} parsing
    // above, which is why bp_notice_frame.h used to carry its own
    // second-guess parse of the raw, still-encoded text -- the authoritative
    // parse (strMsg, strDestinationCall) happened only later. Moved to here,
    // the check gets both fully decoded and side-effect free: no
    // node_msgid++, no save_settings(), no insertOwnTx(), no
    // addLoraRxBuffer() has happened yet, so a message that is never
    // enqueued does not consume a message id either, and that second-guess
    // parser is gone -- deleted, not superseded.
    //
    // Two consequences, both intended: an invalid-length message or a DM to
    // the node's own call is now refused by the checks above BEFORE this
    // one runs (the right reason: "buffer full" is the wrong explanation for
    // a malformed message); and a message that IS going to be refused now
    // runs through the decode loop first -- pure CPU, no side effects, BSS
    // buffers on nRF52 (N-22), so the extra work is free.
    //
    // An untagged caller (origin NONE) is never refused; that is what keeps
    // relay/ACK/beacon traffic flowing through a congested node.
    if(bp_origin != ORIGIN_NONE && bp_state.refusing())
    {
        Serial.printf("[BP];refuse;depth;%d;max;%d;ms;%lu\n",
                      txRingDepth(), (int)MAX_RING, (unsigned long)millis());

        bpEmitNack(bp_state.onRefuse(), bp_origin, bp_origin_dst, strMsg.c_str());
        return BP_SEND_REFUSED;
    }

    // P15: ein {ping} wird nie wiederholt -- die Gegenstelle antwortet mit
    // {pong}, nie mit ACK, also stoppte nichts die Wiederholung. Hier benannt
    // (strMsg ist schon ohne {ZIEL}-Teil); sperrt dmstat_sent. Das Einreihen
    // ueber addTxRingEntryOnce() entscheidet dmTextSendOnce() weiter unten.
    const bool bPingMsg = strMsg.startsWith("{ping}");

    // N-22: siehe Kommentar bei msg_text_check oben Ă˘â‚¬â€ť auf nRF52 in BSS,
    // encodeAPRS() beschreibt den Puffer bei jedem Aufruf vollstaendig.
#if defined(NRF52_SERIES)
    static uint8_t msg_buffer[MAX_MSG_LEN_PHONE];
#else
    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];
#endif

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, ':');

    aprsmsg.msg_len = 0;

    // MSG ID zusammen setzen
    // bei Text beginnend mit {ping} und {pong} keine MSB fÄ‚Ä˝r repeat markiereb 
    // [DK5EN] Passt so: die msg_id bleibt hier unveraendert. Ob wiederholt wird, entscheidet
    // [DK5EN] erst updateRetransmissionStatus() -- nur eine eigene PN (Text an Rufzeichen, endet auf {NNN)
    // [DK5EN] bekommt eine Wiederholungs-id (src/pn_retry.h), alles andere geht 1:1 wie heute raus.
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);   // MAC-address + 3FF = 1023 max in real only 0-999

    // MSG-ID fÄ‚Ä˝r repeat Bits frei machen
    // NSB start with 00 .. repeater 1 = 01 .. repeater 2 = 10 .. repeater 3 = 11
    //discussion ongoing aprsmsg.msg_id  = aprsmsg.msg_id & 0x3FFFFFFF;
    // [DK5EN] Die Erstsendung bleibt byte-gleich, es muss nichts frei gemacht werden: die Wiederholung k
    // [DK5EN] kippt msg_id Bit 10-11 (= Knotenkennung Bit 0-1) per XOR mit k (src/pn_retry.h). Bei ESP32
    // [DK5EN] sind diese Bits schon 00, dort gilt 00/01/10/11 woertlich; XOR deckt nRF52 mit ab.
    
    // src_override: a KISS client's own source call (handleInboundAx25()), else our own
    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path),
          (src_override && src_override[0]) ? src_override : meshcom_settings.node_call);
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), strDestinationCall.c_str());  //Later FW insert PATH from HEY! collecting
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), strDestinationCall.c_str());  //Later FW insert PATH from HEY! collecting

    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), strMsg.c_str());

    // ACK add request only DM Calls
    if(bDM)
    {
        // A '{' inside the user text breaks the receiver's NNN parse
        // (indexOf("{", 1) finds the first brace, not the ack tag); escape it
        // at the sender (plan risk list, advisor m4).
        //
        // P14/P15: ausser bei einem fuehrenden {ping}/{SET}-Tag -- das ist
        // kein Fliesstext, sondern das Tag selbst (siehe dm_text_escape.h).
        // Ein '{' NACH dem Tag bricht weiterhin den NNN-Parse und wird
        // escaped.
        size_t escFrom = dmTextEscapeFrom(strMsg.c_str());
        for(size_t i = escFrom; i < (size_t)strMsg.length(); i++)
        {
            if(strMsg[i] == '{')
                strMsg.setCharAt(i, '(');
        }

        // W0c / wave 3a: an RM1 frame (command or reply) carries no "{NNN" (the
        // receiver sends no ACK) and no DM statistics entry (it would stay
        // sent-never-acked), see dmTextIsRm1Frame(). The escaped text is the
        // payload as is. A reply goes out once (dmTextSendOnce()); a command is
        // enqueued like a PN and repeats on the 40 s ladder until the RM layer
        // stops it (pnFrameIsOwnRm1Cmd(), findAndStopRingSlot()).
        if(dmTextIsRm1Frame(strMsg.c_str()))
            mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), strMsg.c_str());
        else
        {
        char cAckId[4] = {0};
        snprintf(cAckId, sizeof(cAckId), "%03i", meshcom_settings.node_msgid);
        snprintf(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), "%s{%s", strMsg.c_str(), cAckId);

        // 0.4: DM outcome counters (docs/dm-transport-impl-plan-20260913.md).
        // nnn is the same node_msgid value just written into cAckId, before
        // the increment below.
        //
        // P14/P15: nicht fuer ein {ping} -- die Gegenstelle antwortet mit
        // {pong}, nie mit einem ACK, also stuende es fuer immer als
        // sent-nie-acked in der DM-Statistik.
        if(!bPingMsg)
        {
            dmstat_sent.fetch_add(1);
            dmStatNoteSent((uint16_t)meshcom_settings.node_msgid, millis());
        }
        }
    }

    finalizeAndSendAPRS(aprsmsg, msg_buffer);

    if(bDisplayInfo)
    {
        printBuffer_aprs((char*)"NEW-TXT", aprsmsg);
        printfdeb("");
    }

    // Master RingBuffer for transmission
    // local messages send to LoRa TX
    // ETH-03 (docs/BACKLOG.md 3.8at): this used to test `iWrite == iRead`,
    // which is ALSO the empty ring -- so a node with nothing queued printed
    // "[RING] overflow" on every user message and sent a whole investigation
    // after a full ring that was not there. Occupancy is txRingDepth(). Since
    // the slot pool (TXP W1b) the TX buffer holds MAX_RING entries, so
    // MAX_RING occupied slots is "full" (it used to be MAX_RING-1 with the
    // iRead/iWrite ring). The eviction itself (which slot, why) is decided and
    // logged inside addTxRingEntry() below; this line is only a heads-up.
    if (txRingDepth() >= MAX_RING) {   // pool full: addTxRingEntry() will evict or refuse
        Serial.printf("[RING] full, depth %d of %d\n", txRingDepth(), (int)MAX_RING);
    }
    // Status vorab aus msg_buffer bestimmen (statt aus dem Ring zu lesen): der
    // Slot wird erst im Einreihen unter Lock gewaehlt/beschrieben.
    uint8_t user_msg_status = 0x00;
    // RCA 2026-10-10: Texte, die genau einmal in die Luft gehen ({ping},
    // {CET}/{MCP}/{SET}, RM1-Antwort; dmTextSendOnce() in dm_text_escape.h), laufen
    // ueber addTxRingEntryOnce(): klassifiziert READY (eigene DM/Gruppe),
    // gespeichert DONE (keine Wiederholung), beides atomar. Ein VORAB auf DONE
    // (0xFF) gesetzter Text gilt in getMessagePriority() als Relay (NORMAL,
    // 4500 ms) und kollidiert mit den Relays der Nachbarn; Hintergrund siehe
    // addTxRingEntryOnce()-Doku in txring_functions.cpp.
    bool bUseOnce = false;
    if (msg_buffer[0] == 0x3A) // only Messages
    {
        if(dmTextSendOnce(aprsmsg.msg_payload, bDM))
            bUseOnce = true;
        else
            user_msg_status = 0x00; // retransmission active (PN, RM1 command: 40 s ladder)
    }
    else
    {
        user_msg_status = 0xFF; // non-text frames: no retransmission (unchanged)
    }

    int w = bUseOnce ? addTxRingEntryOnce(msg_buffer, (uint16_t)aprsmsg.msg_len, "user_msg", 0)
                      : addTxRingEntry(msg_buffer, (uint16_t)aprsmsg.msg_len, user_msg_status, "user_msg", 0);

    if(bDisplayRetx && w >= 0)
    {
        unsigned int ring_msg_id = (ringBuffer[w][6]<<24) | (ringBuffer[w][5]<<16) | (ringBuffer[w][4]<<8) | ringBuffer[w][3];
        printfdeb("einfÄ‚Ä˝gen retid:%i status:%02X lng;%02X msg-id: %c-%08X\n", w, ringBuffer[w][1], ringBuffer[w][0], ringBuffer[w][2], ring_msg_id);
    }

    if(w < 0)
    {
        // H2: addTxRingEntry() returns -1 for three different reasons, only
        // one of which is back-pressure -- (1) an unconfigured callsign
        // (txring_functions.cpp:401, TX-01), (2) a length-invariant
        // violation (len == 0 || len > UDP_TX_BUF_SIZE,
        // txring_functions.cpp:423), (3) the ring's overflow logic found no
        // lower-priority entry to evict (genuine back-pressure). Treating
        // every -1 as (3) forced BP_QRT on an EMPTY ring for a
        // factory-fresh node (reason 1) and printed "TX buffer full" for a
        // message that was never even ring-eligible -- a wrong state
        // transition with a wrong explanation, once per typed message.
        // Distinguish (3) from (1)/(2) by depth: the ring is only actually
        // under pressure once txRingDepth() has reached
        // bp_state.refuseThreshold() (the same threshold onSend() itself
        // gates its QRT/QRS decision on); (1) and (2) fire regardless of
        // depth and typically on an empty or low ring.
        // QRT Finding 5: RING_ENQUEUE_FULL (-2) is the no-evict overflow and
        // always gets the QTA nack, also below the threshold (index-span
        // "full" with holes: 11 of 19 drops in the capture at depth <= 11).
        if(sendMessageNeedsQtaNack(w, txRingDepth(), bp_state.refuseThreshold()))
        {
            // Symmetrie (Operatorentscheidung 2026-09-01, E4): was nicht auf HF geht,
            // geht auch nicht ins Backbone. Kein Echo, kein UDP-Uplink, kein
            // EXTUDP-Spiegel, keine Eigen-TX-/Dedup-Buchung -- nur die Rueckmeldung
            // an den Absender. Die Nachricht ist vollstaendig nicht passiert.
            bpRoute(bp_state.onSend(txRingDepth(), true, millis()));   // Episoden-QTA
            bpEmitNack(BP_NACK_QTA, bp_origin, bp_origin_dst, strMsg.c_str());
            return BP_SEND_DROPPED;
        }

        // Reason (1) or (2): the ring is not under pressure, so this is not
        // a back-pressure event -- no bp_state.onSend() call (no state
        // transition), no nack (nothing to apologize for congestion-wise).
        // Own marker, distinct from [BP];refuse;/[BP];nack;, so the
        // bench/console can still tell "operator typed something the ring
        // can never accept" apart from a real refuse/drop cycle.
        Serial.printf("[BP];invalid;depth;%d;max;%d;ms;%lu\n",
                      txRingDepth(), (int)MAX_RING, (unsigned long)millis());
        return BP_SEND_INVALID;
    }

    // An APP als Anzeige retour senden
    // UDP-05: EXTUDP sends are echoed too, so they show in the WebUI chat
    // (and a connected app); the ack frame below stays phone/WebUI-only.
    // Console "::" sends are echoed further down (bConsoleText).
    if(phoneEchoWanted(hasMsgFromPhone, bp_origin))
        addBLEOutBuffer(msg_buffer, aprsmsg.msg_len);

    if(hasMsgFromPhone)
    {
        if(bGATEWAY && meshcom_settings.node_hasIPaddress)
        {
            // set Info message send and Server reached, not on DM
            if(!bDM && (strcmp(aprsmsg.msg_destination_call, "*") == 0 || CheckGroup(strDestinationCall)))
            {
                uint8_t ack_buff[ACK_PHONE_MAX_LEN];
                uint16_t plen = buildAckPhoneFrame(ack_buff, aprsmsg.msg_id, 0x01, meshcom_settings.node_call);

                addBLEOutBuffer(ack_buff, plen);
            }
        }

    }

    #if defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS)
    tdeck_add_MSG(aprsmsg, false);
    #endif

    #if defined(BOARD_T_DECK_PRO)
    String strCall=String("<")+aprsmsg.msg_source_call+"> "+aprsmsg.msg_destination_call;
    TDeck_pro_lora_disp(strCall, foldForDisplay(aprsmsg.msg_payload, TF_ASCII));
    #endif

    // store last message to compare later on
    insertOwnTx(aprsmsg.msg_id);
    ownMsgStatusRegister(aprsmsg.msg_id);   // durable status row for the web GUI ticks

    if(bGATEWAY && meshcom_settings.node_hasIPaddress)
        addLoraRxBuffer(aprsmsg.msg_id, true);
    else
        addLoraRxBuffer(aprsmsg.msg_id, false);

    // BP-01/BP-08: the ring accepted the frame above (w < 0 already returned
    // early), so this call always signals success -- the new depth after
    // enqueuing decides between silence, QRS and QRT.
    bpRoute(bp_state.onSend(txRingDepth(), false, millis()));


    if(bGATEWAY && meshcom_settings.node_hasIPaddress)
    {
	    // UDP out
		addNodeData(msg_buffer, aprsmsg.msg_len, 0, 0);
    }

    // Extern Server
    if(bEXTUDP)
        sendExtern(true, (char*)"node", msg_buffer, aprsmsg.msg_len, 0, 0);

    // KISS interface: mirror the ext-udp "node" echo above, but only for a
    // locally originated send (phone/web/console -- src_override unset). A
    // KISS-client-injected send (src_override set, from handleInboundAx25())
    // would otherwise be echoed straight back at the very client that just
    // sent it -- it already gets its own confirmation via the 0xF0 TX-result
    // frame, so skip it here.
    #if defined(ESP32) && !defined(DISABLE_KISS_TCP)
    if (bKISS && (!src_override || !src_override[0]))
        queueKiss(msg_buffer, aprsmsg.msg_len, 99, 0);
    #endif

    // wenn text via Console kommt auch an BLE bzw. WEBService senden
    if(bConsoleText)
        addBLEOutBuffer(msg_buffer, aprsmsg.msg_len);

    // Client RM1 command (McApp, phone, serial, web): the node holds no key, so the target's reply
    // cannot be verified here; remember dst + ctr + msg_id so that reply stops the repeats
    // (rm_client_cmd.h, rm_runtime.cpp handleReply()). Only after the ring accepted the frame. A command of
    // the node's own sender (--rm) is forgotten again by bookAndSend(). Not for a KISS client's frame
    // (src_override): its source is not ours, the ladder never repeats it and the reply is not for us.
    if(bDM && !(src_override && src_override[0]) && dmTextIsRm1Command(strMsg.c_str()))
    {
        uint32_t rmCtr = 0;
        if(rmClientParseCtr(strMsg.c_str(), rmCtr))
        {
            // as bookAndSend(): a stale "RM1 stopped" entry with this id core must not cut the new repeats
            rm1StoppedForget((uint32_t)aprsmsg.msg_id);
            rmClientCmdArm(strDestinationCall.c_str(), rmCtr, (uint32_t)aprsmsg.msg_id, millis());
        }
    }

    // KISS interface needs the assigned id for the TX-result frame / ack map.
    if(out_msg_id)
        *out_msg_id = aprsmsg.msg_id;

    return BP_SEND_OK;
}

// Inject an APRS position (received over the KISS interface) into the mesh
// under a foreign source callsign. Mirrors the ring-insertion sequence of
// SendAckMessage()/sendMessage(); the caller (kiss_functions) has already
// verified that srcCall's base matches this node's call.
unsigned int sendInjectedPosition(const char *srcCall, const char *posData)
{
    if(!srcCall || !srcCall[0] || !posData || strlen(posData) < 4)
        return 0;

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, '!');

    aprsmsg.msg_len = 0;

    // bei Positionen keine MSB fÄ‚Ä˝r repeat markiereb 
    // [DK5EN] Passt so: diese Meldung wird gar nicht wiederholt (Ring-Status 0xFF beim
    // [DK5EN] Einreihen), die msg_id bleibt unveraendert. Eine Wiederholungs-id bekommt nur eine
    // [DK5EN] eigene PN (Text an Rufzeichen, endet auf {NNN), in updateRetransmissionStatus().
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);

    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), srcCall);
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "*");
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), "*");
    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), posData);

    // Same inline epilogue as SendAckMessage() (insertOwnTx()/addLoraRxBuffer()
    // sit between the persist step and checkVia(), so finalizeAndSendAPRS()
    // does not fit). Upstream advanced by hand and ran save_settings() on every
    // injected position; msgid_counter.h persists only at the high-water mark.
    meshcom_settings.node_msgid = msgIdAdvance(meshcom_settings.node_msgid);

    // Flash rewrite, but only at a high-water mark -- msgid_counter.h
    if(msgIdNeedsPersist(meshcom_settings.node_msgid))
        countersSave();

    insertOwnTx(aprsmsg.msg_id);
    if(bGATEWAY && meshcom_settings.node_hasIPaddress)
        addLoraRxBuffer(aprsmsg.msg_id, true);
    else
        addLoraRxBuffer(aprsmsg.msg_id, false);
    checkVia(aprsmsg);

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];
    encodeAPRS(msg_buffer, aprsmsg);

    if(bDisplayInfo)
    {
        printBuffer_aprs((char*)"KISS-POS", aprsmsg);
        printfdeb("");
    }

    addTxRingEntry(msg_buffer, (uint16_t)aprsmsg.msg_len, 0xFF, "kiss_pos");   // position: no retransmission

    if(bGATEWAY && meshcom_settings.node_hasIPaddress)
        addNodeData(msg_buffer, aprsmsg.msg_len, 0, 0);

    if(bEXTUDP)
        sendExtern(true, (char*)"node", msg_buffer, aprsmsg.msg_len, 0, 0);

    return aprsmsg.msg_id;
}

String PositionToAPRS(bool bConvPos, bool bSsendTele, bool bFuss, double plat, char lat_c, double plon, char lon_c, int alt,  float press, float hum, float temp, float temp2, float gasres, float co2, int qfe, float qnh)
{
    double lat=abs(plat);
    double lon=abs(plon);


    if(lat >= 0.0 && lat <= 2.0 && lon >= 0.0 && lon <= 2.0)
    {
        printfdeb("[APRS] Error PositionToAPRS\n");
        return "";
    }

    char msg_start[250] = {0};

    // :|0x11223344|0x05|OE1KBC|>*:Hallo Mike, ich versuche eine APRS Meldung\0x00
    // 09:30:28 RX-LoRa: 105 ! xAE48E347 05 1 0 9V1LH-1,OE1KBC-12>*!0122.64N/10356.51E#/B=005/A=000272/P=1005.1/H=42.5/T=29.4/Q=1005.7/R=232;2321; HW:04 MOD:03 FCS:15DC FW:17 LH:09

	double slat = 100.0;
    slat = lat*slat;
	double slon = 100.0;
    slon=lon*slon;
	
    if(bConvPos)
    {
        double slatr=60.0;
        double slonr=60.0;
        
        slat = (int)lat;
        slatr = (lat - slat) * slatr;
        slat = (slat * 100.) + slatr;
        
        slon = (int)lon;
        slonr = (lon - slon) * slonr;
        slon = (slon * 100.) + slonr;
    }

    if(lon_c != 'W' && lon_c != 'E')
        lon_c = 'E';

    if(lat_c != 'N' && lat_c != 'S')
        lat_c = 'N';

    char cversion[5]={0};

    char catxt[50]={0};
    char cname[50]={0};
    char cbatt[15]={0};
    char calt[15]={0};
    char cpress[15]={0};
    char chum[15]={0};
    char ctemp[15]={0};
    char ctemp2[15]={0};
    char cqfe[15]={0};
    char cqnh[15]={0};
    char cgasres[15]={0};
    char cco2[15]={0};
    char cgrc[50]={0};
    char cncnt[5]={0};

    char csfpegel[15]={0};
    char csfpegel2[15]={0};
    char csftemp[15]={0};
    char csfbatt[15]={0};

    char cinaU[15]={0};
    char cinaI[15]={0};

    char cdigital[15]={0};

    char ctele[15]={0};

    if(strcmp(meshcom_settings.node_atxt, "none") != 0 && meshcom_settings.node_atxt[0] != 0x00)
    {
        // CHR-02: strip APRS structure separators and truncate on a UTF-8
        // boundary at the same 25-byte cap decodeAPRSPOS() applies on
        // receive (aprs_functions.cpp:632) -- otherwise a receiver's
        // byte-counting parser can inherit a split multi-byte sequence.
        char catxt_src[sizeof(meshcom_settings.node_atxt)];
        snprintf(catxt_src, sizeof(catxt_src), "%s", meshcom_settings.node_atxt);
        size_t iatxt = charset_filter_apply(catxt_src, strlen(catxt_src), CHARSET_FILTER_STRIP_SEPARATORS);
        iatxt = charset_utf8_safe_truncate(catxt_src, iatxt, 25);
        catxt_src[iatxt] = 0x00;

        snprintf(catxt,  sizeof(catxt), "%s", catxt_src);
    }

    if(strcmp(meshcom_settings.node_name, "none") != 0 && meshcom_settings.node_name[0] != 0x00)
    {
        snprintf(cname,  sizeof(cname), "#%s", meshcom_settings.node_name);
    }

    if(bSsendTele)
    {
        snprintf(ctele, sizeof(ctele), "/Y=1");
    }

    // send INA226 Werte abwechselnd zu normal Pos
    //////////
    // TEST
    //bINA226ON=true;
    //meshcom_settings.node_vbus=meshcom_settings.node_vbus+1.0;
    //meshcom_settings.node_vcurrent=meshcom_settings.node_vcurrent+1.0;
    //////////

    if(strlen(meshcom_settings.node_parm) != 0 && strcmp(meshcom_settings.node_parm, "none") != 0)
    {
        // keine automatischen Werte
    }
    else
    if(bINA226ON)
    {
        snprintf(cversion, sizeof(cversion), "%s", "/V=5");
        if(alt > 0)
        {
            // auf Fuss umrechnen
            if(bFuss)
                snprintf(calt, sizeof(calt), "/A=%06i", conv_fuss(alt));
            else
                snprintf(calt, sizeof(calt), "/A=%05i", alt);
        }
        // /B= immer senden wenn Batterie-Hardware vorhanden ist, auch bei 0 Prozent
        // (leerer Tag wuerde sonst "kein Akku bestueckt" bedeuten statt "leer")
        if(battHardwarePresent())
        {
            snprintf(cbatt, sizeof(cbatt), "/B=%03d", global_proz);
        }
        snprintf(cinaU, sizeof(cinaU), "/U=%.2f", meshcom_settings.node_vbus);
        snprintf(cinaI, sizeof(cinaI), "/I=%.1f", meshcom_settings.node_vcurrent);

        //////////
        // TEST
        //bINA226ON=false;
        //////////
    }
    else
    {
        // /B= immer senden wenn Batterie-Hardware vorhanden ist, auch bei 0 Prozent
        // (leerer Tag wuerde sonst "kein Akku bestueckt" bedeuten statt "leer")
        if(battHardwarePresent())
        {
            snprintf(cbatt, sizeof(cbatt), "/B=%03d", global_proz);
        }

        if(alt > 0)
        {
            // auf Fuss umrechnen
            if(bFuss)
                snprintf(calt, sizeof(calt), "/A=%06i", conv_fuss(alt));
            else
                snprintf(calt, sizeof(calt), "/A=%05i", alt);
        }

        if(press > 0)
        {
            snprintf(cpress, sizeof(cpress), "/P=%.1f", press);
            if(posTagIsNan(cpress))
                return "";
        }

        if(hum > 0)
        {
            snprintf(chum, sizeof(chum), "/H=%.1f", hum);
            if(posTagIsNan(chum))
                return "";
        }

        if(temp != 0)
        {
            snprintf(ctemp, sizeof(ctemp), "/T=%.1f", temp);
            if(posTagIsNan(ctemp))
                return "";
        }

        if(temp2 != 0)
        {
            snprintf(ctemp2, sizeof(ctemp2), "/O=%.1f", temp2);
            if(posTagIsNan(ctemp2))
                return "";
        }

        if(qfe > 0)
        {
            snprintf(cqfe, sizeof(cqfe), "/F=%i", qfe);
            if(posTagIsNan(cqfe))
                return "";
        }

        if(qnh > 0 && !bMCU811ON && !bBME680ON)
        {
            snprintf(cqnh, sizeof(cqnh), "/Q=%.1f", qnh);
            if(posTagIsNan(cqnh))
                return "";
        }

        if(gasres > 0 && bBME680ON)
        {
            snprintf(cversion, sizeof(cversion), "%s", "/V=3");

            snprintf(cgasres, sizeof(cgasres), "/G=%.1f", gasres);
            if(posTagIsNan(cgasres))
                return "";
        }

        if(co2 > 0 && bMCU811ON)
        {
            snprintf(cversion, sizeof(cversion),  "%s", "/V=2");

            snprintf(cco2, sizeof(cco2), "/C=%.0f", co2);
            if(posTagIsNan(cco2))
                return "";
        }

        // MeshCom 5 (docs/meshcom5-campaign.md Welle 4, Konzept 4.8): /N geht
        // auf die Luft -- nbrNcntAir() kappt schon auf NBR_NCNT_AIR_MAX; der
        // Deckel hier bleibt trotzdem stehen (belt-and-suspenders, benannt
        // statt der alten 99 als Literal) -- ohne ihn kann GCC cncnt's feste
        // Breite nicht aus dem Rueckgabewert einer Funktion herleiten
        // (-Werror=format-truncation).
        int incnt = nbrNcntAir(nbrMatrix, uptimeMin16());
        if(incnt > 0)
        {
            if(incnt > NBR_NCNT_AIR_MAX)
                incnt = NBR_NCNT_AIR_MAX;

            snprintf(cncnt, sizeof(cncnt), "/N%i", incnt);
        }
    }

    // /D= MCP23017 port A inputs (issue 1076 companion): GPA0 first,
    // output pins read '0'. Only when the chip answered at boot.
    if(bMCP23017)
    {
        char cbits[MCP17_BITS_LEN + 1];
        mcp17PortABits(meshcom_settings.node_mcp17in, meshcom_settings.node_mcp17io, cbits);
        snprintf(cdigital, sizeof(cdigital), "/D=%s", cbits);
    }

    /////////////////////////////////////////////////////////////////
    // send Group-Call settings zu MesCom-Server
    String strGRC="";

    char cGC[8];
    for(int igrc=0;igrc<6;igrc++)
    {
        if(meshcom_settings.node_gcb[igrc] > 0 && meshcom_settings.node_gcb[igrc] < 100000)
        {
            snprintf(cGC, sizeof(cGC), "%i;", meshcom_settings.node_gcb[igrc]);
            strGRC.concat(cGC);
        }
    }

    if(strGRC.length() > 0)
    {
        snprintf(cgrc, sizeof(cgrc), "/R=%s", strGRC.c_str());
    }
    //
    /////////////////////////////////////////////////////////////////

    //strcpy(strconcat, catxt);
    //strcat(strconcat, cname);

    char strconcat[100]={0};
    // C02: strncat(dst, src, sizeof(dst)-1) bounds the source, not the remaining room;
    // the worst-case tag set (~111 B) overran strconcat[100]. Bound by the room left.
    snprintf(strconcat, sizeof(strconcat), "%s", cbatt);
    strncat(strconcat, calt, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cncnt, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cpress, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, chum, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, ctemp, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, ctemp2, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cqfe, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cqnh, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cgasres, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cco2, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cgrc, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, csfpegel, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, csfpegel2, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, csftemp, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, csfbatt, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cversion, sizeof(strconcat) - strlen(strconcat) - 1);    
    strncat(strconcat, cinaU, sizeof(strconcat) - strlen(strconcat) - 1);   
    strncat(strconcat, cinaI, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, cdigital, sizeof(strconcat) - strlen(strconcat) - 1);
    strncat(strconcat, ctele, sizeof(strconcat) - strlen(strconcat) - 1);

    // wenn die concatenation zu lang ist, dann catxt und cname lÄ‚Â¶schen
    if((strlen(strconcat) + strlen(catxt) + strlen(cname)) > 100)
    {
        catxt[0]=0x00;
    }

    // wenn die concatenation zu lang ist, dann catxt und cname lÄ‚Â¶schen
    if((strlen(strconcat) + strlen(catxt) + strlen(cname)) > 100)
    {
        cname[0]=0x00;
    }
    
    snprintf(msg_start, sizeof(msg_start), "%07.2lf%c%c%08.2lf%c%c%s%s%s", slat, lat_c, meshcom_settings.node_symid, slon, lon_c, meshcom_settings.node_symcd, catxt, cname, strconcat);

    return String(msg_start);
}

void sendPosition(unsigned long uintervall, double lat, char lat_c, double lon, char lon_c, int alt, float press, float hum, float temp, float temp2, float gasres, float co2, int qfe, float qnh)
{
    // position 0.0/0.0 no message sent
    if(lat == 0.0 && lon == 0.0)
        return;

    // Mindestabstand fuer den Sofort-Pfad (0x9999: --sendpos, User-Button,
    // EXTUDP-Telemetrie). Begruendung und Feldbefund: src/beacon_rate.h.
    // Der periodische Pfad (uintervall == posinfo_interval) und die
    // Track-/WX-Pfade (0xEEEE/0xFFFF) bleiben unberuehrt, sie tragen ihre
    // eigene Kadenz.
    if(uintervall == 0x9999 &&
       !beaconShotAllowed(millis(), lastOwnPosTx, bHaveOwnPosTx, BEACON_SHOT_MIN_MS))
    {
        // Roher Serial.printf statt printfdeb: der Marker muss auch bei
        // --debug off sichtbar sein, und ';' darf nicht gefiltert werden.
        // Nur die ERSTE Unterdrueckung je Sperrfenster wird gemeldet -- unter
        // einem Ausloeser-Sturm waeren es sonst 20 Zeilen/s (TM-21).
        if(iShotSuppressed == 0)
            Serial.printf("[POS];shot;suppressed;since_ms;%lu;min_ms;%lu\n",
                          (unsigned long)(millis() - lastOwnPosTx),
                          (unsigned long)BEACON_SHOT_MIN_MS);
        iShotSuppressed++;
        return;
    }

    if(uintervall == 0x9999 && iShotSuppressed > 0)
    {
        Serial.printf("[POS];shot;resumed;suppressed;%lu\n", (unsigned long)iShotSuppressed);
        iShotSuppressed = 0;
    }

    lastOwnPosTx = millis();
    bHaveOwnPosTx = true;

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    bool bSendViaAPRS = false;
    bool bSendViaMesh = true;

    // TRACk only allowed on receivind GPS singnals with having fix
    if(bDisplayTrack && posinfo_fix)
    {
        bSendViaAPRS = bDisplayTrack;
        bSendViaMesh = !bDisplayTrack;
    }

    unsigned long intervall = uintervall;

    bool bGateway_done = false;

    bool bsendTele = false;
    if(intervall == 0xEEEE)
    {
        intervall = 0;
        bsendTele = true;
        bSendViaMesh=true;  // only via MeshCom
        bSendViaAPRS=false;
    }

    if(intervall == 0xFFFF)
    {
        intervall = 0;
        bsendTele = false;
        bSendViaMesh=false;  // only via LoRa-APRS
        bSendViaAPRS=true;
    }

    if((uint32_t)(millis() - lastHeardTime) >= 15000 && (intervall == POSINFO_INTERVAL || intervall == 0x9999)) // wenn die letzte gehÄ‚Â¶rte LoRa-Nachricht < 5sec dann auch via MeshCom
    {
        bSendViaMesh = true;

        // Zeitmessung
        posfixinterall = millis();
    }

    if((uint32_t)(millis() - posfixinterall) >= (POSINFO_INTERVAL * 1000))
    {
        bSendViaMesh = true;

        // Zeitmessung
        posfixinterall = millis();
    }

    #ifdef BOARD_TLORA_OLV216
        bSendViaAPRS = false;
    #endif

    // set default
    // Symbol Table / \ 0-9 A-Z  (compressed a-z)
    bool bSymbolTable = false;
    if(meshcom_settings.node_symid == '/' || meshcom_settings.node_symid == '\\')
        bSymbolTable = true;
    else
    if(meshcom_settings.node_symid >= '0' && meshcom_settings.node_symid <= '9')
        bSymbolTable = true;
    else
    if(meshcom_settings.node_symid >= 'A' && meshcom_settings.node_symid <= 'Z')
        bSymbolTable = true;

    bool bSymbolCode = false;
    if(meshcom_settings.node_symcd >= '!' && meshcom_settings.node_symcd <= '}')
        bSymbolCode = true;

    if(!bSymbolTable || !bSymbolCode)   // set default
    {
        meshcom_settings.node_symid = '/';
        meshcom_settings.node_symcd = '#';

        save_settings();
    }

    if(bSendViaAPRS)
    {
        //int ilng = encodeLoRaAPRS(msg_buffer, meshcom_settings.node_call, lat, lat_c, lon, lon_c, alt);
        int ilng = encodeLoRaAPRScompressed(msg_buffer, meshcom_settings.node_call, lat, lat_c, lon, lon_c, alt);

        if(ilng == 0)
            return;

        if(bDisplayInfo)
        {
            printfdeb("%s [LO-APRS]...%c%02X%02X%s\n", getTimeString().c_str(), msg_buffer[0], msg_buffer[1], msg_buffer[2], msg_buffer+3);
        }

        // local LoRa-APRS position-messages send to LoRa TX
        addTxRingEntry(msg_buffer, (uint16_t)ilng, 0xFF, "user_pos"); // 0xFF no retransmission

        // BOARD_T5_EPAPER gehoert in diese Kaskade, weil ihr #else-Zweig u8g2
        // benutzt und u8g2 auf diesem Board gar nicht existiert (:364 schliesst
        // es aus). Es fehlte hier -- das ist die VIERTE, abweichend
        // geschriebene Kopie derselben Aussage "dieses Board treibt ein
        // U8g2-OLED", und die einzige, die nicht mitgepflegt wurde. Gemerkt hat
        // das niemand, weil env:t5_epaper mangels configuration.h noch nie
        // uebersetzt hat; der erste Build ueberhaupt starb hier mit
        // "'u8g2' was not declared in this scope". Zusammenfuehrung der
        // Kopien: BACKLOG GRD-01, faellig mit R4-02/03.
        // GRD-01: hier stand eine neunarmige Kaskade, die jedes Board ohne
        // U8g2 einzeln aufzaehlte, damit der letzte #else-Zweig u8g2 benutzen
        // durfte. Eine Aufzaehlung garantiert das nicht, sie behauptet es nur
        // -- und diese hier lief auseinander: BOARD_T5_EPAPER fehlte, der
        // erste Build jener Umgebung starb an "'u8g2' was not declared".
        //
        // Jetzt entscheidet MC_HAS_U8G2 (configuration_global.h), und der
        // u8g2-Zweig ist STRUKTURELL unerreichbar, wo es kein u8g2 gibt. Die
        // sieben Boards, die hier einzeln standen (HAS_TFT -> tracker,
        // HAS_EPAPER -> t_echo/e213/e290/wireless-paper, T_ECHO, TRACKER,
        // HELTEC_T114, T_CONNECT_PRO, T5_EPAPER), schliesst MC_HAS_U8G2 alle
        // schon aus; ihre Zweige waren reine Wiederholung.
        //
        // BOARD_STICK_V3 bleibt als eigener Zweig stehen: das Board HAT ein
        // U8g2-Display, bekommt auf seinem 0,49"-Panel aber keine Track-Seite.
        // Das ist eine andere Aussage als "kein OLED" und darf nicht mit ihr
        // zusammenfallen.
        #if defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS) || defined(BOARD_T_DECK_PRO)
            tdeck_send_track_view();
        #elif defined(BOARD_STICK_V3)
        // none -- hat u8g2, aber keine Track-Seite
        #elif MC_HAS_U8G2
            if(u8g2 != NULL)
            {
                char cvers[20];

                u8g2->clearDisplay();
                oledInvalidate();
                u8g2->firstPage();

                do
                {
                    u8g2->setFont(u8g2_font_10x20_mf);
                    u8g2->drawStr(5, 16, "MeshCom 4.0");
                    u8g2->setFont(u8g2_font_6x10_mf);
                    u8g2->drawStr(5, 30, (char*)"");
                    u8g2->drawStr(5, 40, (char*)"       TRACK");
                    u8g2->drawStr(5, 50, (char*)"   POSITION SENT");
                    snprintf(cvers, sizeof(cvers), " %.4lf%c %.4lf%c", lat, lat_c, lon, lon_c);
                    u8g2->drawStr(5, 60, cvers);
                } while (u8g2->nextPage());
            }
        #endif

        // An APP als Anzeige retour senden
        if(isPhoneReady == 1 || bGATEWAY)
        {
            struct aprsMessage aprsmsg;

            initAPRS(aprsmsg, '!');

            aprsmsg.msg_len = 0;

            // MSG ID not used in APP

            if(intervall != POSINFO_INTERVAL)
                aprsmsg.msg_track=true;

            mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);
            
            if(strlen(meshcom_settings.node_lora_call) != 0 && strcmp(meshcom_settings.node_lora_call, "none") != 0)
            {
                mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_lora_call);
            }

            mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "*");
            mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), "*");
            mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), PositionToAPRS(true, false, true, lat, lat_c, lon, lon_c, alt, press, hum, temp, temp2, gasres, co2, qfe, qnh).c_str());
            
            if(aprsmsg.msg_payload[0] == 0)
                return;

            checkVia(aprsmsg);

            encodeAPRS(msg_buffer, aprsmsg);
            
            if(isPhoneReady == 1)
            {
                addBLEOutBuffer(msg_buffer, aprsmsg.msg_len);
            }

            // Sonderfall fÄ‚Ä˝r langstrecken track - LoRa-Track mit Sonderrufzeichen bringt auch MeshCom-Track via Gateway
            if(bGATEWAY)
            {
                if(bDisplayInfo)
                {
                    printfdeb("%s [NEW-UDP]...%s\n", getTimeString().c_str(), msg_buffer+3);
                }

                bGateway_done = true;

                // UDP out
                addNodeData(msg_buffer, aprsmsg.msg_len, 0, 0);
            }
        }

    }
    
    if(bSendViaMesh)
    {
        struct aprsMessage aprsmsg;

        initAPRS(aprsmsg, '!');

        aprsmsg.msg_len = 0;

        // MSG ID zusammen setzen
        // bei Postionen keine MSB fÄ‚Ä˝r repeat markiereb 
        // [DK5EN] Passt so: diese Meldung wird gar nicht wiederholt (Ring-Status 0xFF beim
        // [DK5EN] Einreihen), die msg_id bleibt unveraendert. Eine Wiederholungs-id bekommt nur eine
        // [DK5EN] eigene PN (Text an Rufzeichen, endet auf {NNN), in updateRetransmissionStatus().
        aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);

        if(intervall != POSINFO_INTERVAL)
            aprsmsg.msg_track=true;

        mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);
        mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "*");
        mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), "*");
        mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), PositionToAPRS(true, bsendTele, true, lat, lat_c, lon, lon_c, alt, press, hum, temp, temp2, gasres, co2, qfe, qnh).c_str());
        
        if(aprsmsg.msg_payload[0] == 0)
            return;

        finalizeAndSendAPRS(aprsmsg, msg_buffer);

        if(bDisplayInfo)
        {
            printBuffer_aprs((char*)"NEW-POS", aprsmsg);
            printfdeb("");
        }

        // local position-messages send to LoRa TX
        addTxRingEntry(msg_buffer, (uint16_t)aprsmsg.msg_len, 0xFF, "user_wx"); // 0xFF no retransmission

        #if defined(BOARD_T_DECK) || defined(BOARD_T_DECK_PLUS) || defined(BOARD_T_DECK_PRO)
            tdeck_send_track_view();
        #endif

        // already sent
        if(bGATEWAY && !bGateway_done)
        {
            if(bDisplayInfo)
            {
                printfdeb("%s [NEW-UDP]...%s\n", getTimeString().c_str(), msg_buffer+3);
            }
            
            // UDP out
            addNodeData(msg_buffer, aprsmsg.msg_len, 0, 0);
        }
        
        // store last message to compare later on
        memcpy(own_msg_id[iWriteOwn], msg_buffer+1, 4);
        own_msg_id[iWriteOwn][4]=0x00;
        iWriteOwn++;
        if(iWriteOwn >= MAX_RING)
            iWriteOwn=0;

        // W3b (docs/meshcom5-campaign.md Welle 3, Konzept 4.11): eigener '!'-
        // Positionsrahmen -- fuer die Echo-Tabelle, nicht fuer Relays/Text/
        // den HN-Bericht (die haben eigene Aufrufstellen bzw. gar keine).
        nbrNoteOwnTx(nbrMatrix, (uint32_t)aprsmsg.msg_id, aprsmsg.payload_type,
                     uptimeMin16());

        // An APP als Anzeige retour senden
        if(isPhoneReady == 1)
        {
            addBLEOutBuffer(msg_buffer, aprsmsg.msg_len);
        }

        // Extern Server
        if(bEXTUDP)
            sendExtern(true, (char*)"node", msg_buffer, aprsmsg.msg_len, 0, 0);

        // KISS interface: mirror the ext-udp "node" echo above -- this is the
        // node's own periodic position beacon, always locally originated
        // (unlike sendMessage(), there is no src_override / client-injection
        // path here to guard against self-echo).
        #if defined(ESP32) && !defined(DISABLE_KISS_TCP)
        if (bKISS)
            queueKiss(msg_buffer, aprsmsg.msg_len, 99, 0);
        #endif
    }

}

void sendAPPPosition(double lat, char lat_c, double lon, char lon_c, float temp2)
{
    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, '!');

    aprsmsg.msg_len = 0;

    // MSG ID zusammen setzen
    // bei Postionen keine MSB fÄ‚Ä˝r repeat markiereb 
    // [DK5EN] Passt so: diese Meldung wird gar nicht wiederholt (Ring-Status 0xFF beim
    // [DK5EN] Einreihen), die msg_id bleibt unveraendert. Eine Wiederholungs-id bekommt nur eine
    // [DK5EN] eigene PN (Text an Rufzeichen, endet auf {NNN), in updateRetransmissionStatus().
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);

    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "*");
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), "*");
    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), PositionToAPRS(true, false, true, lat, lat_c, lon, lon_c, 0, 0, 0, 0, temp2, 0, 0, 0, 0).c_str());
    
    if(aprsmsg.msg_payload[0] == 0)
        return;

    finalizeAndSendAPRS(aprsmsg, msg_buffer);

    if(bDisplayInfo)
    {
        printBuffer_aprs((char*)"NEW-POS", aprsmsg);
        printfdeb("");
    }

    // local position-messages send to LoRa TX
    addTxRingEntry(msg_buffer, (uint16_t)aprsmsg.msg_len, 0xFF, "user_hey"); // 0xFF no retransmission


    if(bGATEWAY)
    {
        // UDP out
        addNodeData(msg_buffer, aprsmsg.msg_len, 0, 0);
    }
    
    // store last message to compare later on
    memcpy(own_msg_id[iWriteOwn], msg_buffer+1, 4);
    own_msg_id[iWriteOwn][4]=0x00;
    iWriteOwn++;
    if(iWriteOwn >= MAX_RING)
        iWriteOwn=0;

    // W3b (docs/meshcom5-campaign.md Welle 3, Konzept 4.11): eigener '!'-
    // Positionsrahmen (vom Telefon ausgeloest), gleiche Aufrufstelle wie
    // sendPosition()'s Mesh-Zweig oben.
    nbrNoteOwnTx(nbrMatrix, (uint32_t)aprsmsg.msg_id, aprsmsg.payload_type,
                 uptimeMin16());
}

unsigned int SendAckMessage(String dest_call, unsigned int iAckId, const char *src_override)
{
    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, ':');

    aprsmsg.msg_len = 0;

    // MSG ID zusammen setzen
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);   // MAC-address + 3FF = 1023 max in real only 0-999

    // MSG-ID fÄ‚Ä˝r repeat Bits frei machen
    // NSB start with 00 .. repeater 1 = 01 .. repeater 2 = 10 .. repeater 3 = 11
    // discussion ongoing aprsmsg.msg_id  = aprsmsg.msg_id & 0x3FFFFFFF;
    // [DK5EN] Gilt hier nicht: ein :ackNNN ist keine PN und wird nie wiederholt (Slot direkt
    // [DK5EN] nach dem Einreihen 0xFF). Die Maske ist auch hier ueberfluessig, die msg_id
    // [DK5EN] bleibt unveraendert.

    // own Call, or a foreign source when relaying a KISS client's APRS ack
    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path),
          (src_override && src_override[0]) ? src_override : meshcom_settings.node_call);
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), dest_call.c_str());
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), dest_call.c_str());

    char cackmsg[20];
    if(strcmp(dest_call.c_str(), "WLNK-1") == 0)
        snprintf(cackmsg, sizeof(cackmsg), "ack%04i", iAckId);
    else
        snprintf(cackmsg, sizeof(cackmsg), "%-9.9s:ack%03i", dest_call.c_str(), iAckId);
    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), cackmsg);

    meshcom_settings.node_msgid = msgIdAdvance(meshcom_settings.node_msgid);

    // Flash rewrite, but only at a high-water mark -- msgid_counter.h
    if(msgIdNeedsPersist(meshcom_settings.node_msgid))
        countersSave();

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];
    
    // store last message to compare later on
    insertOwnTx(aprsmsg.msg_id);

    if(bGATEWAY && meshcom_settings.node_hasIPaddress)
        addLoraRxBuffer(aprsmsg.msg_id, true);
    else
        addLoraRxBuffer(aprsmsg.msg_id, false);

    checkVia(aprsmsg);

    encodeAPRS(msg_buffer, aprsmsg);

    // ACK-Message send to LoRa TX
    if(bDisplayInfo)
    {
        printBuffer_aprs((char*)"NEW-ACK", aprsmsg);
        printfdeb("");
    }

    // P15: klassifiziert als eigene Ziel-Message (MSG_PRIO_CRITICAL), aber
    // mit Status DONE gespeichert (keine Wiederholung) -- beides atomar unter
    // einem Lock, siehe addTxRingEntryOnce()/addTxRingEntryCore() in
    // txring_functions.cpp fuer den Hintergrund (frueher hier ein
    // Status-Nachtrag ausserhalb des Locks, siehe dort). Rueckgabewert
    // ungenutzt, wie schon bisher (kein Nachtrag mehr noetig).
    addTxRingEntryOnce(msg_buffer, (uint16_t)aprsmsg.msg_len, "beacon");

    
    if(bGATEWAY && meshcom_settings.node_hasIPaddress)
    {
		// UDP out
        if(strcmp(aprsmsg.msg_destination_call, meshcom_settings.node_call) != 0)
        {
            addNodeData(msg_buffer, aprsmsg.msg_len, 0, 0);
        }
    }

    return aprsmsg.msg_id;
}

// F6: last own HEY sent by sendHey() -- see heyTrickleSuppress().
static uint32_t hey_own_last_ms = 0;
static bool hey_own_have = false;

// F6: trickle suppression decision for esp32_main.cpp / nrf52_main.cpp. A gateway
// is not suppressed once its own last HEY is >= TRICKLE_IMAX_S old (hey_policy.h).
bool heyTrickleSuppress(int consistent)
{
    return heyShouldSuppress(consistent, TRICKLE_K, bGATEWAY,
                             heySinceLastOwn((uint32_t)millis(), hey_own_last_ms, hey_own_have),
                             (uint32_t)TRICKLE_IMAX_S * 1000UL);
}

// F6: --gateway on/off changed the HG/H flag other nodes learn from our HEY.
// Restart the trickle at Imin and announce the new state now; sendHeyShot()
// applies the 30 s floor of the FL-02 path.
void heyGatewayChanged()
{
    trickle_interval_ms = TRICKLE_IMIN_S * 1000UL;
    trickle_consistent_count = 0;
    heyinfo_timer = millis();
    sendHeyShot();
}

// Send Hey-Message
void sendHey()
{
    if(meshcom_settings.node_call[0] != 0x00 && meshcom_settings.node_pingtime > 0)
        return;

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, '@');

    aprsmsg.msg_len = 0;

    // MSG ID zusammen setzen
    // bei Hey keine MSB fÄ‚Ä˝r repeat markiereb 
    // [DK5EN] Passt so: diese Meldung wird gar nicht wiederholt (Ring-Status 0xFF beim
    // [DK5EN] Einreihen), die msg_id bleibt unveraendert. Eine Wiederholungs-id bekommt nur eine
    // [DK5EN] eigene PN (Text an Rufzeichen, endet auf {NNN), in updateRetransmissionStatus().
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);   // MAC-address + 3FF = 1023 max rela only 0-999
    
    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);
    
    if(bGATEWAY)
        mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "HG");
    else
        mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "H");

    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), aprsmsg.msg_destination_path);

    // MeshCom 5 (docs/meshcom5-campaign.md Welle 4, Konzept 4.8): R<n> im HEY
    // geht auf die Luft -- nbrNcntAir(), auf NBR_NCNT_AIR_MAX gekappt.
    snprintf(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), "R%d;",
             nbrNcntAir(nbrMatrix, uptimeMin16()));
   
    finalizeAndSendAPRS(aprsmsg, msg_buffer);

    if(bDisplayInfo)
    {
        printBuffer_aprs((char*)"NEW-HEY", aprsmsg);
        printfdeb("");
    }

    // F6: time of the last own HEY (trickle path AND shot path), for
    // heyTrickleSuppress(). Separate from lastOwnHeyTx, which only gates the
    // --sendhey shot and must keep that meaning.
    hey_own_last_ms = millis();
    hey_own_have = true;

    // store last message to compare later on
    insertOwnTx(aprsmsg.msg_id);

    // W3b (docs/meshcom5-campaign.md Welle 3, Konzept 4.11): eigener '@'-HEY-
    // Rahmen -- fuer die Echo-Tabelle, nicht fuer sendNbrReport()'s HN-Bericht
    // (eigene, ausgeschlossene Aufrufstelle: der HN-Bericht wird nie relayt
    // und ist keine im 2-Hop-Fenster sichtbare Echo-Kette).
    nbrNoteOwnTx(nbrMatrix, (uint32_t)aprsmsg.msg_id, aprsmsg.payload_type,
                 uptimeMin16());

    // GW-01: no gateway self-upload of the own '@' HEY. The bare copy
    // (rssi/snr 0, no signal report) always reached the server seconds before
    // the neighbours' enriched copies of the same msg_id and could win over
    // them there; with --gateway off the enriched copies alone carry the
    // link data. Measured 2026-08-31, see docs/BACKLOG.md 3.8i.

    // to LoRa
    {
        // Master RingBuffer for transmission
        // local messages send to LoRa TX
        addTxRingEntry(msg_buffer, (uint16_t)aprsmsg.msg_len, 0xFF, "auto_pos"); // 0xFF no retransmission

    }
}

// HN-Bericht (Nachbarschaftsmatrix Stufe 3, --nbrreport off|auto|on): periodischer
// HEY-artiger Bericht "wen ich direkt mit welchem SNR hoere" (Nachbau von
// sendHey() oben) an das eigene Ziel "HN", max_hop 0 explizit gesetzt --
// dieser Bericht wird NIE weiterrelayt (siehe OnRxDone-Abfangpunkt in
// lora_functions.cpp, der ihn ausschliesslich in die eigene Matrix fuettert
// und aus jedem anderen Pfad heraushaelt). Der Aufrufer (Timer in
// esp32_main.cpp/nrf52_main.cpp) entscheidet Takt und ob der --nbrreport-Modus
// ueberhaupt senden soll; diese Funktion prueft den Modus nicht noch einmal.
//
// Wie sendHey() (GW-01) geht der Bericht NUR ueber addTxRingEntry() auf die
// LoRa-TX-Seite: finalizeAndSendAPRS() ruft weder addNodeData() (Server-
// Upload) noch sendExternNotice()/queueExtern() (EXTUDP) noch addBLE*Buffer()
// (Telefon) auf, und diese Funktion selbst auch nicht -- der eigene HN-
// Bericht bleibt reines LoRa.
void sendNbrReport()
{
    // Wie sendHey(): im Ping-Testbetrieb (node_pingtime > 0) bleibt der
    // Knoten auch fuer die HN-Meldung still (Advisor R4).
    if(meshcom_settings.node_call[0] != 0x00 && meshcom_settings.node_pingtime > 0)
        return;

    uint16_t now_min = uptimeMin16();

    char nbr_payload[128];
    // MeshCom 5 (docs/meshcom5-campaign.md Welle 4, Konzept 4.8): R<heard> im
    // HN-Bericht geht auf die Luft -- nbrNcntAir(), auf NBR_NCNT_AIR_MAX gekappt.
    int nbr_plen = nbrBuildReport(nbrMatrix, now_min, nbrNcntAir(nbrMatrix, now_min), nbr_payload, sizeof(nbr_payload));

    if(nbr_plen < 0)
    {
        // Kein Bericht baubar (leere Matrix o.ae.) -- nichts senden. Feldzahl
        // wie eine normale RPTTX-Zeile (docs/nbr-logformat.md), nur mit
        // leerem Payload-Feld, damit ein Auswerter, der immer vier Felder
        // hinter "RPTTX" erwartet, nicht auf einer fehlenden Spalte stolpert.
        if(bNBRDEBUG && nbrLog != NULL)
        {
            char nbr_line[32];
            snprintf(nbr_line, sizeof(nbr_line), "[NBR]|RPTTX|%u|-1|", (unsigned)now_min);
            nbrLog(nbr_line);
        }
        return;
    }

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, '@');

    aprsmsg.msg_len = 0;
    aprsmsg.max_hop = 0;   // HN-Bericht wird nie weiterrelayt

    // MSG ID zusammen setzen (gleiches Muster wie sendHey())
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);

    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);

    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "HN");
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), "HN");

    mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), nbr_payload);

    finalizeAndSendAPRS(aprsmsg, msg_buffer);

    if(bNBRDEBUG && nbrLog != NULL)
    {
        char nbr_line[160];
        snprintf(nbr_line, sizeof(nbr_line), "[NBR]|RPTTX|%u|%d|%s", (unsigned)now_min, nbr_plen, nbr_payload);
        nbrLog(nbr_line);
    }

    // store last message to compare later on
    insertOwnTx(aprsmsg.msg_id);

    // to LoRa
    addTxRingEntry(msg_buffer, (uint16_t)aprsmsg.msg_len, 0xFF, "nbr_report"); // 0xFF no retransmission
}

// Takt fuer sendNbrReport() (Stufe 3): laeuft UNABHAENGIG vom Trickle-
// Intervall und wird NIE unterdrueckt -- der Zeitpunkt der naechsten Pruefung
// ruckt immer weiter, auch bei --nbrreport off, damit ein spaeteres Umschalten
// auf auto/on nicht sofort einen aufgestauten Bericht nachholt. Nur der
// SEND-Entscheid haengt am Modus (siehe unten).
static unsigned long nbrreport_timer = 0;
static unsigned long nbrreport_due_ms = (unsigned long)NBR_REPORT_FIRST_S * 1000UL;

void nbrReportTick()
{
    if((uint32_t)(millis() - nbrreport_timer) < nbrreport_due_ms)
        return;

    // off (bNBRRPTOFF) nie, on (bNBRRPTON) immer, sonst auto: nur wenn weder
    // Mesh-Relay noch Gateway-Betrieb an sind -- ein Gateway hoert die
    // eigentliche Information laengst aus dem Server, ein Mesh-Relay flutet
    // ohnehin schon.
    bool bSend;
    if(bNBRRPTON)
        bSend = true;
    else if(bNBRRPTOFF)
        bSend = false;
    else
        bSend = (!bMESH && !bGATEWAY);

    if(bSend)
        sendNbrReport();

    nbrreport_due_ms = (unsigned long)NBR_REPORT_INTERVAL_S * 1000UL
                        + (unsigned long)random(0, (long)(NBR_REPORT_JITTER_S * 1000L) + 1);
    nbrreport_timer = millis();
}

// Sofort-Pfad fuer sendHey() (FL-02): --sendhey ruft diese Funktion statt
// sendHey() direkt auf, damit derselbe Mindestabstand gilt wie beim
// Positions-Sofort-Pfad (siehe beacon_rate.h). Der periodische Trickle-
// Scheduler (esp32_main.cpp/nrf52_main.cpp) ruft weiterhin sendHey() direkt
// auf und bleibt unberuehrt -- sonst waere er doppelt gegated.
bool sendHeyShot()
{
    if(!beaconShotAllowed(millis(), lastOwnHeyTx, bHaveOwnHeyTx, BEACON_SHOT_MIN_MS))
    {
        // Roher Serial.printf statt printfdeb: der Marker muss auch bei
        // --debug off sichtbar sein, und ';' darf nicht gefiltert werden.
        // Nur die ERSTE Unterdrueckung je Sperrfenster wird gemeldet -- unter
        // einem Ausloeser-Sturm waeren es sonst 20 Zeilen/s (TM-21).
        if(iHeyShotSuppressed == 0)
            Serial.printf("[HEY];shot;suppressed;since_ms;%lu;min_ms;%lu\n",
                          (unsigned long)(millis() - lastOwnHeyTx),
                          (unsigned long)BEACON_SHOT_MIN_MS);
        iHeyShotSuppressed++;
        return false;
    }

    if(iHeyShotSuppressed > 0)
    {
        Serial.printf("[HEY];shot;resumed;suppressed;%lu\n", (unsigned long)iHeyShotSuppressed);
        iHeyShotSuppressed = 0;
    }

    lastOwnHeyTx = millis();
    bHaveOwnHeyTx = true;

    sendHey();
    return true;
}

// Telemetry with own Parameters
#if defined(ENABLE_LTR390) || defined(ENABLE_WIND)
#include "wx_telemetry.h"
#endif

void sendTelemetry(int ID)
{
    String stationCall = meshcom_settings.node_call;

    if(ID == 1)
    {
        if(strlen(meshcom_settings.node_parm_1) == 0 || strcmp(meshcom_settings.node_parm_1, "none") == 0)
            return;
    
        int iipos=0;
        iipos = strSOFTSERAPP_ID.length() - 9;
        if(iipos < 0)
            iipos=0;
        stationCall = strSOFTSERAPP_ID.substring(iipos);    // APRS max. 9 chars
    }
    else
    {
        if(strlen(meshcom_settings.node_parm) == 0 || strcmp(meshcom_settings.node_parm, "none") == 0)
            return;
    }

    if(strlen(meshcom_settings.node_unit) == 0 || strcmp(meshcom_settings.node_unit, "none") == 0)
        return;

    if(strlen(meshcom_settings.node_values) == 0 || strcmp(meshcom_settings.node_values, "none") == 0)
        return;

    uint8_t msg_buffer[MAX_MSG_LEN_PHONE];

    struct aprsMessage aprsmsg;

    initAPRS(aprsmsg, ':');

    aprsmsg.msg_len = 0;

    // MSG ID zusammen setzen
    // bei Text mit msg_destination_call 100001 keine MSB fÄ‚Ä˝r repeat markiereb 
    // [DK5EN] Passt so: diese Meldung wird gar nicht wiederholt (Ring-Status 0xFF beim
    // [DK5EN] Einreihen), die msg_id bleibt unveraendert. Eine Wiederholungs-id bekommt nur eine
    // [DK5EN] eigene PN (Text an Rufzeichen, endet auf {NNN), in updateRetransmissionStatus().
    aprsmsg.msg_id = ((_GW_ID & 0x3FFFFF) << 10) | (meshcom_settings.node_msgid & 0x3FF);   // MAC-address + 3FF = 1023 max rela only 0-999
    
    mcSet(aprsmsg.msg_source_path, sizeof(aprsmsg.msg_source_path), meshcom_settings.node_call);
    
    mcSet(aprsmsg.msg_destination_call, sizeof(aprsmsg.msg_destination_call), "100001");
    mcSet(aprsmsg.msg_destination_path, sizeof(aprsmsg.msg_destination_path), "100001");

    if(iNextTelemetry == 0)
    {
        if(ID == 1)
            snprintf(msg_text, sizeof(msg_text), "%-9.9s:PARM.%s", stationCall.c_str(), meshcom_settings.node_parm_1);
        else
            snprintf(msg_text, sizeof(msg_text), "%-9.9s:PARM.%s", stationCall.c_str(), meshcom_settings.node_parm);

        iNextTelemetry=1;
    }
    else
    if(iNextTelemetry == 1)
    {
        if(strlen(meshcom_settings.node_unit) == 0 || strcmp(meshcom_settings.node_unit, "none") == 0)
            return;

        snprintf(msg_text, sizeof(msg_text), "%-9.9s:UNIT.%s", stationCall.c_str(), meshcom_settings.node_unit);

        iNextTelemetry=2;
    }
    else
    if(iNextTelemetry == 2)
    {
        if(strlen(meshcom_settings.node_eqns) == 0 || strcmp(meshcom_settings.node_eqns, "none") == 0)
            strTelemetry = "0,1,0,0,1,0,0,1,0,0,1,0,0,1,0";
        else
            strTelemetry=meshcom_settings.node_eqns;
        
        if(count_char(strTelemetry, ',') != 14)
            strTelemetry = "0,1,0,0,1,0,0,1,0,0,1,0,0,1,0";

        snprintf(msg_text, sizeof(msg_text), "%-9.9s:EQNS.%s", stationCall.c_str(), strTelemetry.c_str());

        iNextTelemetry=3;
    }
    else
    if(iNextTelemetry == 3)
    {
        memset(msg_text, 0x00, sizeof(msg_text));

        if(strSOFTSERAPP_NAME.length() > 0 && ID == 1)
        {
            snprintf(msg_text, sizeof(msg_text), "%-9.9s:BITS.00000000%s", stationCall.c_str(), strSOFTSERAPP_NAME.c_str());
        }

        iNextTelemetry=4;
    }
    else
    // Values to APRS.FI
    if(iNextTelemetry >= 4)
    {
        // digital slot (issue 1076): MCP23017 port A inputs, GPA0 first.
        // Stays "00000000" -- byte-identical to today -- on boards without
        // the chip (bMCP23017 false).
        char cbits[MCP17_BITS_LEN + 1] = "00000000";
        if(bMCP23017)
            mcp17PortABits(meshcom_settings.node_mcp17in, meshcom_settings.node_mcp17io, cbits);

        char cv[20];
        snprintf(cv, sizeof(cv), "%-9.9s:T#%03i", stationCall.c_str(), meshcom_settings.node_msgid);

        strTelemetry = cv;

        String strValue="";
        int ivcount=0;

        if(memcmp(meshcom_settings.node_values, "T:", 2) == 0)
        {
            strValue = meshcom_settings.node_values;

            String strRealValues = strValue.substring(2);

            strTelemetry.concat(",");
            strTelemetry.concat(strRealValues);

            // pad with zero-values up to the standard 5 APRS TLM analog slots
            // (was hardcoded to always add exactly 2 zeros, assuming exactly
            // 3 real values - now counts the real values so it stays backward
            // compatible with that case while supporting fewer/more values)
            int realCount = 1;
            for(unsigned int ci = 0; ci < strRealValues.length(); ci++)
                if(strRealValues[ci] == ',')
                    realCount++;

            for(int pad = realCount; pad < 5; pad++)
                strTelemetry.concat(",0");

            strTelemetry.concat(",");
            strTelemetry.concat(cbits);
            strTelemetry.concat(",");
            strTelemetry.concat(meshcom_settings.node_parm_t);
            strTelemetry.concat(",");
            strTelemetry.concat(meshcom_settings.node_parm_id);

            memset(meshcom_settings.node_parm_1, 0x00, sizeof(meshcom_settings.node_parm_1));
            memset(meshcom_settings.node_unit, 0x00, sizeof(meshcom_settings.node_unit));
            memset(meshcom_settings.node_values, 0x00, sizeof(meshcom_settings.node_values));
            memset(meshcom_settings.node_parm_t, 0x00, sizeof(meshcom_settings.node_parm_t));
            memset(meshcom_settings.node_parm_id, 0x00, sizeof(meshcom_settings.node_parm_id));

        }
        else
        {
            for(int ival=0;ival<=(int)strlen(meshcom_settings.node_values); ival++)
            {
                if(meshcom_settings.node_values[ival] == ',' || meshcom_settings.node_values[ival] == 0x00)
                {
                    // max. 5 values
                    ivcount++;
                    if(ivcount > 5)
                        break;

                    strTelemetry.concat(",");

                    strValue.trim();

                    if(strValue == "press")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_press);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "hum")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_hum);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "temp")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_temp);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "onewire")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_temp2);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "gasres")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_gas_res);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "co2")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_co2);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "batt")
                    {
                        snprintf(cv, sizeof(cv), "%.2f", global_batt/1000.);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "proz")
                    {
                        snprintf(cv, sizeof(cv), "%i", global_proz);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "vbus")
                    {
                        snprintf(cv, sizeof(cv), "%.2f", meshcom_settings.node_vbus);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "vcurrent")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_vcurrent);
                        strTelemetry.concat(cv);
                    }
                    else
                    if(strValue == "qnh")
                    {
                        snprintf(cv, sizeof(cv), "%.1f", meshcom_settings.node_press_asl);
                        strTelemetry.concat(cv);
                    }
#if defined(ENABLE_LTR390) || defined(ENABLE_WIND)
                    // WX-01 (upstream #999): window means; empty slot without a value
                    else
                    if(strValue == "uvindex" || strValue == "wind" || strValue == "gust")
                    {
                        if(wxTelemetryValue(strValue.c_str(), &wx_uv_mean, &wx_wind_mean, &wx_wind_gust, cv, sizeof(cv)))
                            strTelemetry.concat(cv);
                    }
#endif

                    strValue="";
                }
                else
                {
                    snprintf(cv, sizeof(cv), "%c", meshcom_settings.node_values[ival]);

                    strValue.concat(cv);
                }
            }

            // digital slot (issue 1076): this path sent none before -- only
            // append it when the chip actually answered at boot, so nodes
            // without an MCP23017 keep a byte-identical frame. APRS puts the
            // digital byte in slot 6, so pad the analog slots to five first
            // (ivcount == values emitted, capped at 5 by the break above) or
            // a three-value node would ship its bits as analog value 4.
            if(bMCP23017)
            {
                for(int pad = ivcount; pad < 5; pad++)
                    strTelemetry.concat(",0");

                strTelemetry.concat(",");
                strTelemetry.concat(cbits);
            }

#if defined(ENABLE_LTR390) || defined(ENABLE_WIND)
            // WX-01 (upstream #999): this frame carried the value slots (not PARM/UNIT/EQNS/BITS):
            // log the window and start the next one
            if(bWXDEBUG)
            {
                char cwx[96];
                wxTelemetryDebugLine(&wx_uv_mean, &wx_wind_mean, &wx_wind_gust, cwx, sizeof(cwx));
                Serial.println(cwx);
            }
            wxMeanReset(&wx_uv_mean);
            wxMeanReset(&wx_wind_mean);
            wxGustReset(&wx_wind_gust);
#endif
        }


        snprintf(msg_text, sizeof(msg_text), "%s", strTelemetry.c_str());

        iNextTelemetry++;
        // Alle 20 Werte - PARM, UNIT. EQNS. BITS. neuerlich senden
        if(iNextTelemetry > 23)
            iNextTelemetry=0;
    }

    if(strlen(msg_text) > 0)
    {
        mcSet(aprsmsg.msg_payload, sizeof(aprsmsg.msg_payload), msg_text);
        
        finalizeAndSendAPRS(aprsmsg, msg_buffer);

        if(bDisplayInfo)
        {
            printBuffer_aprs((char*)"NEW-TMY", aprsmsg);
            printfdeb("");
        }

        // store last message to compare later on
        insertOwnTx(aprsmsg.msg_id);

        // if GATEWAY only to Server
        if(bGATEWAY)
        {
            // UDP out
            addNodeData(msg_buffer, aprsmsg.msg_len, 0, 0);
        }
        else
        {
            // Master RingBuffer for transmission
            // local messages send to LoRa TX
            if(!bDisplayTrack)
                addTxRingEntry(msg_buffer, (uint16_t)aprsmsg.msg_len, 0xFF, "phone_msg"); // 0xFF no retransmission
        }

        // send value messages to Lora-APRS
        if(bDisplayTrack && !bGATEWAY)
        {
            uint16_t tlng=0;

            tlng = encodeLoRaAPRSText(msg_buffer, meshcom_settings.node_call, msg_text+10);

            // Master RingBuffer for transmission
            // local messages send to LoRa TX
            addTxRingEntry(msg_buffer, tlng, 0xFF, "phone_raw"); // 0xFF no retransmission
        }
    }
}

int GetHeadingDifference(int heading1, int heading2)
{   
    int  difference = heading1 - heading2;
    if(difference < 0)
        difference = difference * -1;
        
    if (difference > 180)
        return 360 - difference;
    
    return difference;
}

unsigned int setSMartBeaconing(double dlat, double dlon)
{
    // check TRACK Mode on
    if(!bDisplayTrack)
    {
        if(iGPSDEBUG > 0)
            printfdeb("%s [POSINFO]...Stationary -> Suppressing drift (Rate: %is)\n", getTimeString().c_str(), POSINFO_INTERVAL);
        
        return POSINFO_INTERVAL;
    }

    unsigned int gps_send_rate = posinfo_last_rate;  // seconds

    posinfo_lat = dlat;
    posinfo_lon = dlon;

    if(posinfo_last_lat == 0.0 && posinfo_last_lon == 0.0)
    {
        posinfo_last_lat = dlat;
        posinfo_last_lon = dlon;
    }

    double distance = 0.;
    
    distance = gps.distanceBetween(posinfo_last_lat, posinfo_last_lon, dlat, dlon);    // meters
    
    //posinfo_distance += distance;
    posinfo_distance = distance; // KBC 25.11.14

    if(posinfo_prev_lat == 0.0 && posinfo_prev_lon == 0.0)
    {
        posinfo_prev_lat = dlat;
        posinfo_prev_lon = dlon;

        posinfo_direction = 0.0;
    }
    else
    {
        posinfo_direction = gps.courseTo(posinfo_prev_lat, posinfo_prev_lon, dlat, dlon);    // Grad
    }

    // Use GPS speed if available (more accurate than distance/interval)
    double speed_mps = 0.0;

    if(gps.speed.isValid())
        speed_mps = gps.speed.mps();
    else
        speed_mps = distance / gps_refresh_intervall; // Fallback

    // Stationary / Drift suppression
    // If speed is very low (< 1.0 m/s), we assume stationary.
    // We only send if distance is LARGE (> 100m) to handle drift or slow creep.
    if (speed_mps < 1.0)
    {
        if(distance < 100)
        {
            posinfo_last_rate = POSINFO_INTERVAL;

            if(iGPSDEBUG > 0)
                printfdeb("%s [POSINFO]...STATIONARY (Speed %.1f, Dist %.0f) --> RATE:%i\n", getTimeString().c_str(), speed_mps, distance, (int)posinfo_last_rate);

            return posinfo_last_rate;
        }
    }

    if(iGPSDEBUG > 0)
        printfdeb("%s [POSINFO]...dir:%.1lfĂ‚Â° dist:%.1lf speed:%.1lf intervall:%.1lf\n", getTimeString().c_str(), posinfo_direction, distance, speed_mps, gps_refresh_intervall);

    // Moving Logic & Symbol Switching with Hysteresis
    static unsigned long last_car_speed_ts = 0;
    static unsigned long last_bike_speed_ts = 0;

    // Update timestamps based on current speed
    if (speed_mps > 7.0) // > 25 km/h -> Car range
    {
        last_car_speed_ts = millis();
        last_bike_speed_ts = millis(); // Also implies bike speed threshold passed
    }
    else if (speed_mps > 1.4) // > 5 km/h -> Bike range
    {
        last_bike_speed_ts = millis();
    }

    // Determine Symbol based on history (2 minutes hysteresis)
    char target_symbol = 0;

    // use APRS Symbol switching
    if(bGPSAutosymbol)
    {
        if (meshcom_settings.node_symid == '/') // Only auto-switch if using primary table
        {
            // Check if we are currently using one of the auto-switchable symbols
            if (meshcom_settings.node_symcd == '[' || meshcom_settings.node_symcd == 'b' || meshcom_settings.node_symcd == '>')
            {
                if ((millis() - last_car_speed_ts) < 120000) // Car speed seen in last 2 mins
                {
                    target_symbol = '>';
                }
                else if ((millis() - last_bike_speed_ts) < 120000) // Bike speed seen in last 2 mins
                {
                    target_symbol = 'b';
                }
                else
                {
                    target_symbol = '['; // Runner/Hiker default
                }

                if (target_symbol != 0 && meshcom_settings.node_symcd != target_symbol)
                {
                    meshcom_settings.node_symcd = target_symbol;

                    if(iGPSDEBUG > 0)
                        printfdeb("Auto-Symbol switch to '%c'\n", target_symbol);
                }
            }
        }
    }
    // WiFi Stationary Check
    // If connected to WiFi AND speed is low, we assume we are indoors/stationary to prevent GPS drift
    // But if moving (e.g. in car with hotspot), we still want updates.
    #if defined(ESP32)
    if(WiFi.status() == WL_CONNECTED && speed_mps < 1.0)
    {
        // Relax update rate significantly if on WiFi and not moving
        gps_send_rate = POSINFO_INTERVAL; // 30 minutes
        
        // Also suppress distance triggers unless very large (e.g. moving to another building)
        if(distance < 200.0) 
        {
            if(iGPSDEBUG > 0) printfdeb("%s [POSINFO]...WiFi connected & Stationary -> Suppressing drift (Rate: %i)\n", getTimeString().c_str(), POSINFO_INTERVAL);
            return POSINFO_INTERVAL;
        }
    }
    #endif

    // Set Update Rate based on current speed (immediate reaction for tracking accuracy)
    if(speed_mps < 4.0)             // Walking / Slow cycling (< 14 km/h)
    {
        gps_send_rate = 20;         // 20s
    }
    else if(speed_mps < 14.0)       // Cycling / City (< 50 km/h)
    {
        gps_send_rate = 15;         // 15s
    }
    else if(speed_mps < 22.0)       // Fast driving (< 80 km/h)
    {
        gps_send_rate = 12;         // 12s
    }
    else                            // Highway (> 80 km/h)
    {
        gps_send_rate = 10;         // 10s
    }

    if(iGPSDEBUG > 0)
        printfdeb("%s [POSINFO]...speed:%.1lf -> fast rate:%i\n", getTimeString().c_str(), speed_mps, (int)gps_send_rate);

    // Distance Trigger: Force send if distance threshold exceeded
    double dist_threshold = 500.0;
    if (speed_mps < 4.0) dist_threshold = 50.0;      // Walking: 50m
    else if (speed_mps < 22.0) dist_threshold = 200.0; // City/Cycling: 200m
    
    if (distance > dist_threshold)
    {
        posinfo_shot = true;
        if(iGPSDEBUG > 0)
            printfdeb("%s [POSINFO]...one-shot set - distance > %.0fm (%.1lf)\n", getTimeString().c_str(), dist_threshold, distance);
    }

    if(gps_send_rate < 200)  // seit letzter position
    {
        int direction_diff=0;

        if((int)posinfo_last_direction > 0 && (int)posinfo_direction > 0)  // seit letzter gemeldeter position
        {
            direction_diff=GetHeadingDifference((int)posinfo_last_direction, (int)posinfo_direction);

            // Variable turn threshold based on speed (SmartCornering)
            // Slow: Needs large turn (25Ă‚Â°) to trigger (avoid wobble)
            // Fast: Needs small turn (10Ă‚Â°) to trigger (highway curves)
            int turn_threshold = 25; 
            if (speed_mps > 15.0) turn_threshold = 10;      // > 54 km/h
            else if (speed_mps > 5.0) turn_threshold = 15;  // > 18 km/h

            if(direction_diff > turn_threshold)
            {
                posinfo_shot=true;

                if(iGPSDEBUG > 0)
                    printfdeb("%s [POSINFO]...one-shot set - direction_diff:%i (thresh:%i) last_lat:%.1lf last_lon:%.1lf\n", getTimeString().c_str(), direction_diff, turn_threshold, posinfo_prev_lat, posinfo_prev_lon);
            }
        }
    }
    else
    {
        posinfo_prev_lat = posinfo_lat;
        posinfo_prev_lon = posinfo_lon;
    }

    posinfo_last_rate = gps_send_rate;

    if(iGPSDEBUG > 0)
        printfdeb("%s [POSINFO]...RATE:%i\n", getTimeString().c_str(), (int)posinfo_last_rate);

    return posinfo_last_rate;
}

String convertCallToShort(char callsign[10])
{
    String sVar = "XXX";

    for(int its=0; its<10; its++)
    {
        if(callsign[its] == '-' || callsign[its] == 0x00)    // SSID Trennung oder ohne SSID
        {
            sVar.setCharAt(0, callsign[its-3]);
            sVar.setCharAt(1, callsign[its-2]);
            sVar.setCharAt(2, callsign[its-1]);
            sVar = sVar + "40";
            break;
        }
    }

    sVar.toUpperCase();

    return sVar;
}

double cround4(double dvar)
{
    char cvar[20];
    snprintf(cvar, sizeof(cvar), "%.4lf", dvar);
    double rvar;
    sscanf(cvar, "%lf", &rvar);

    return rvar;
}

double cround4abs(double dvar)
{
    char cvar[20];
    snprintf(cvar, sizeof(cvar), "%.4lf", dvar);
    double rvar;
    sscanf(cvar, "%lf", &rvar);

    rvar = abs(rvar);

    return rvar;
}

int conv_fuss(int alt_meter)
{
    double fuss = alt_meter * 10;
    fuss = fuss * 3.28084;
    int ifuss = fuss + 5;
    return ifuss / 10;
}

int conv_meter(int alt_fuss)
{
    return (int)((float)alt_fuss * 0.3048);
}

String getTimeZone()
{
    // TZ-01: with a TZ rule, the current abbreviation (CET/CEST/...)
    const char *abbrev = tzActiveAbbrev();
    if(abbrev != NULL)
        return String(abbrev);

    if(meshcom_settings.node_utcoff == 0)
        return "UTC";

    return "LT";
}

int count_char(String s, char c)
{
    int count = 0;
  
    for (int i = 0; i < (int)s.length(); i++)
      if (s.charAt(i) == c) count++;
  
    return count;
}

// add RING Pointer
void addRingPointer(volatile int &pWrite, volatile int &pRead, int iMAX, const char* bufName)
{
    pWrite++;
    if (pWrite >= iMAX) // if the buffer is full we start at index 0 -> take care of overwriting!
        pWrite = 0;

    // if alle ring-elemets are full move read-pointer
    //if(bnextread)
    {
        if(pRead == pWrite)
        {
            pRead = pWrite+1;

            if (pRead >= iMAX) // if the buffer is full we start at index 0 -> take care of overwriting!
                pRead = 0;

            // DR-21 (Sichtbarkeitsklausel, 2026-09-12 entschieden): "udp" faellt
            // aus der Ausnahmeliste. Der Ausgangsring war der EINZIGE, dessen
            // Ueberlauf stumm blieb -- und genau er laeuft jetzt voll, wenn die
            // neue Fruehruecknahme bei udp_dest_addr == 0 den Drain gar nicht
            // mehr laufen laesst. Ohne diese Zeile waere die Verdraengung
            // unbeobachtbar.
            if(bLORADEBUG && strcmp(bufName, "raw_rx") != 0 && strcmp(bufName, "phone") != 0)
            {
                printfdeb("[MC-DBG] RING_OVERFLOW buf=%s\n", bufName);
            }
        }
    }

    bnextread=false;
}

// allgemeine Funktionen
bool is_equ(const char* buf1, const char* buf2)
{
    size_t len = strlen(buf1);

    if(len != strlen(buf2))
        return false;

    if(memcmp(buf1, buf2, len) == 0)
        return true;

    return false;
}

int is_pos(const char* buf, const char* comp_buf)
{
    size_t buf_len = strlen(buf);
    size_t comp_len = strlen(comp_buf);

    // buf ist kleinerf als comp_buf
    if(buf_len < comp_len)
        return -1;

    for(int ipos=0; ipos<(int)(buf_len-comp_len); ipos++)
    {
        if(buf[ipos] == comp_buf[0])
        {
            bool bEqual=true;

            for(int icomp=0; icomp<(int)comp_len; icomp++)
            {
                if(buf[ipos+icomp] != comp_buf[icomp])
                {
                    bEqual = false;
                    break;
                }
            }

            if(bEqual)
            {
                return ipos;
            }
        }
    }

    return -1;
}