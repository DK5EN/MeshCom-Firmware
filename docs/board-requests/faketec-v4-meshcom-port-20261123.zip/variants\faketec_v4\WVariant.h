/*
  Copyright (c) 2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.
*/

#pragma once

#include <stdint.h>
#include <stdbool.h>
#include <nrf.h>
#include <nrf_soc.h>
#include <nrf_sdm.h>
#include <nrf_gpio.h>

#ifdef __cplusplus
extern "C" {
#endif

extern const uint32_t g_ADigitalPinMap[];

#ifdef __cplusplus
} // extern "C"
#endif