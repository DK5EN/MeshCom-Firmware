/*
definitions for FakeTec v4 (nRF52840 + SX1262 HT-RA62)
*/

#pragma once

#include <Arduino.h>
#include <configuration_global.h>

#define MODUL_HARDWARE RAK4631
#define RF_FREQUENCY 433175000
#define LORA_APRS_FREQUENCY 433775000
#define TX_POWER_MIN 2
#define ENABLE_SHT21_DISABLED

#define OLED
#define USE_RAK4630

#ifndef BUTTON_PIN
#define BUTTON_PIN 32       // P1.00 (UBTN)
#endif

#define ENABLE_RAK_GPS
#define ENABLE_GPS_DISABLED

// Parametry LoRa
#define LORA_APRS_BANDWIDTH 0
#define LORA_APRS_SPREADING_FACTOR 12
#define LORA_APRS_CODINGRATE 1
#define LORA_APRS_PREAMBLE_LENGTH 8

#define LORA_BANDWIDTH 1
#define LORA_CR 2

#define LORA_SYMBOL_TIMEOUT 0
#define LORA_FIX_LENGTH_PAYLOAD_ON false
#define LORA_IQ_INVERSION_ON false
#define RX_TIMEOUT_VALUE 0
#define TX_TIMEOUT_VALUE 3000

#define ETH_CS SS
#define MAX_DEVICE_ID 0xfFfFfFfFfFfF

#include <configuration_default.h>